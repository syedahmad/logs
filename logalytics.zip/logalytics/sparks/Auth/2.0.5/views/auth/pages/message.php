<h2>Message</h2>

<p><?php echo $message; ?></p>