<h2>Dashboard</h2>

<p>Welcome <?php echo username(); ?>.</p>