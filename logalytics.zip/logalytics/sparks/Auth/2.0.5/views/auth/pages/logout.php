<div id="login">
	<h2>Logout</h2>
	
	<div class="box">
			You have been successfully logged out!
	</div>
</div>