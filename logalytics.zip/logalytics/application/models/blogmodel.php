<?php 
class Blogmodel extends CI_Model {

    var $title   = '';
    var $content = '';
    //var $date    = '';

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function get_last_ten_entries()
    {
        $query = $this->db->get('App1', 10);
        return $query->result();
    }

    function insert_entry_f($a,$b)
    {
        $this->title   = (string)$a; // please read the below note
        $this->content = serialize($b);
       // $this->date    = time();

        $this->db->insert('App1', $this);
    }
    function insert_entry_go($a,$b)
    {
        $this->title   = (string)$a; // please read the below note
        $this->content = serialize($b);
       // $this->date    = time();

        $this->db->insert('App2', $this);
    }
    function insert_entry_gi($a,$b)
    {
        $this->title   = (string)$a; // please read the below note
        $this->content = serialize($b);
       // $this->date    = time();

        $this->db->insert('App3', $this);
    }

    function update_entry()
    {
        $this->title   = $_POST['title'];
        $this->content = $_POST['content'];
        //$this->date    = time();

        $this->db->update('App', $this, array('id' => $_POST['id']));
    }

}
?>
