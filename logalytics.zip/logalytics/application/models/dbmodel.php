<?php
	Class Dbmodel extends CI_Model
	{
	 public function get($db_name,$collection_name,$document=array())
	 {
	 	$m = new MongoClient();
		$db = $m->$db_name;
		$collection = $db->$collection_name;
		return $collection->find($document);
    } 
    public function count($db_name,$collection_name)
	 {
	 	$m = new MongoClient();
		$db = $m->$db_name;
		$collection = $db->$collection_name;
		return $collection->count();
    } 
    public function create_collection($db_name,$collection_name)
	 {
	 	$m = new MongoClient();
		$db = $m->$db_name;
		$collection = $db->createCollection($collection_name);
	 }
    public function insert($db_name,$collection_name,$document)
	 {
	 	$m = new MongoClient();
		$db = $m->$db_name;
		$collection = $db->$collection_name;
		return $collection->insert($document);
	 }
	 public function get_one($db_name,$collection_name,$document=array())
	 {
	 	$m = new MongoClient();
		$db = $m->$db_name;
		$collection = $db->$collection_name;
		return $collection->findOne($document);       
    } 
	 public function update($db_name,$collection_name,$document1,$document2)
	 {
	 	$m = new MongoClient();
		$db = $m->$db_name;
		$collection = $db->$collection_name;
		$collection->update($document1,$document2);
	 }
	 public function remove_app($user_id,$app_name)
	 {
	 	$m = new MongoClient();
		$db = $m->$user_id;
		$App_Collection = $db->Apps;

		$cursor = $App_Collection->findOne(array("App_Name"=>$app_name));
		$App_Id = $cursor['App_Id'];
		$File_Collection_Name = $App_Id."_Files";
		$File_Collection = $db->$File_Collection_Name;
		$Log_Collection_Name = $App_Id."_Logs";
		$Log_Collection = $db->$Log_Collection_Name;
		$Tag_Collection_Name = $App_Id."_Tags";
		$Tag_Collection = $db->$Tag_Collection_Name;

		$File_Collection->drop();
		$Log_Collection->drop();
		$Tag_Collection->drop();
		
		$App_Collection->remove(array("App_Name"=>$app_name));
	 }
	 public function session_add($document)
	 {
	 	$this->session->set_userdata($document);
	 }
	 public function session_get($value)
	 {
	 	return $this->session->userdata($value);
	 }
	 public function session_unset($document)
	 {
	 	$this->session->unset_userdata($document);
	 }
	}
	?>
