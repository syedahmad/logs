<?php
	Class User_model extends CI_Model
	{
	 function login($username, $password)
	 {
	 	//echo "12372138778";
	   //load the mongodb library
	 
      $this->load->library('mongo_db');

       //connect to mongodb collection named as 'category' using our mongodb library
       $collection = $this->mongo_db->db->selectCollection('Admin_Info');
//echo "UM1";
       $userQuery = array('Admin_Login' => $username,'Admin_Pass' =>md5($password));//md5($password));
		//print_r($userQuery);
//echo "UM2";
	   $result = $collection->findOne($userQuery);
	   //echo "UM3";
	   
	   if($result)
	   { //echo "UM4-1";
		
		return $result;
	   }
	   else
	   {//echo "UM4-2";
	     return false;
	   }

       
    } 
	 	
	}
	?>
