$config['twitter']['key']='twitter consumer key';
$config['twitter']['secret']='twitter secret';


$config['tumblr']['key']='tumblr consumer key';
$config['tumblr']['secret']='tumblr secret';


$config['facebook']['key']='facebook key ';
$config['facebook']['secret']='facebook secret'; 
