<?php
$config['fb']['id'] = '1483560861876637';
$config['fb']['secret'] = '84cb188d105ef8c6fa4bc3f28f8c3150';
$config['google']['id'] = '494574875993-vq9jvvl8ng8192hboj22bef6hhf0mlt9.apps.googleusercontent.com';
$config['google']['secret'] = 'D7DsWysGIB-r2KZLhYbKZxI2';
$config['git']['id'] = '46ff95f56db739c467e3';
$config['git']['secret'] = 'aadf58f233f546e5d288953e7702ce48231c620d';
$config['S3']['awsAccessKey']='AKIAJSPMO7EFJKZGK4DQ';
$config['S3']['awsSecretKey']='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';
?>
