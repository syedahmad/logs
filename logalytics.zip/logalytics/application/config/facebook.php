<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '1483560861876637';
$config['secret']  = '84cb188d105ef8c6fa4bc3f28f8c3150';

?>
