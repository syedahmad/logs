<?php
//mongodb host
$config['default']['mongo_hostbase'] = 'localhost';
//mongodb name
$config['default']['mongo_database'] = 'Admin_DB';
//mongodb username - by default, it is empty
$config['default']['mongo_username'] = '';
//mongodb password - by default, it is empty
$config['default']['mongo_password'] = '';
?>
