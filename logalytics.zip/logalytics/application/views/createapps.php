<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Logalytics: User Aplications</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>style.css">

  </head>
  <body>
    <h1>&nbsp;&nbsp;Create an app</h1>
    <div class="container-fluid">
     <br>
   <form role="form" action="<?php echo Base_url();?>index.php/apps" method="POST">
   
   <input type="text" class="form-control" id="AppName" name="AppName" placeholder="Enter AppName"><br><button type="submit" class="btn btn-default" name="button2" href="<?php echo base_url();?>/apps">Create App</button>
   
   
   </form>
   </div>
  </body>
  </html>