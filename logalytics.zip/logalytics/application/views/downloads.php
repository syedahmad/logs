    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Logalytics: User Applications</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo base_url();?>style.css">

    <script type="text/javascript">
    
    </script>
    </head>
    <body>

    <div class="container">

    <div class="row">

    <div class="navbar navbar-default navbar-inner navbar-fixed-top" role="navigation">

    <div class="navbar-header">

    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">



    <span class="sr-only">Toggle navigation</span>



    <span class="icon-bar"></span>



    <span class="icon-bar"></span>



    <span class="icon-bar"></span>



    </button>



    <a class="navbar-brand" rel="home" href="<?php echo Base_url();?>" title="Buy Sell Rent Everyting">Logalytics</a>
    <ul class="nav navbar-nav">

    <li><a href="<?php echo Site_url();?>/products">Pricing</a></li>
    <li><a href="<?php echo Site_url();?>/apps">DashBoard</a></li>
    <li><a href="#">QuickStart</a></li>
    <li><a href="#">Tutorials</a></li>
    <li><a href="#">Downloads</a></li>


              

    <li><a href="#">Help</a></li>
            
    </ul>



    </div>



    <div class="collapse navbar-collapse navbar-ex1-collapse">


    <ul class="nav navbar-nav navbar-right">



    <li class="dropdown">



    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi <?php echo $username;?><b class="caret"></b></a>



                        <ul class="dropdown-menu">
                         


                          <li><a href="#">Account</a></li>



                          <li class="divider"></li>



                          <li><a href="<?=$logout;?>">Logout</a></li>



                       </ul>



                        </li>
          
            </ul>
            </div>
        </div>        
    </div>  
 </div>
   
<div class="container my-container">
  <br><br><br><br>
<div class="alert alert-success" role="alert"><a href="<?php echo base_url();?>logalytics.jar" download>Click here</a> to download the sample android .jar project to post an http request to the endpoint</div>
<div class="alert alert-success" role="alert"><a href="<?php echo base_url();?>push.jar" download>Click here</a> to download the sample android .jar project to post an http request to the endpoint on receiving a push notification</div>
<div class="alert alert-success" role="alert"><a href="<?php echo base_url();?>loganalytics.jar" download>Click here</a> to download the supporting .jar library for android project </div>
<div class="alert alert-success" role="alert"><a href="<?php echo base_url();?>php_post.php" download>Click here</a> to download the sample PHP http post script for the endpoint</div>
<div class="alert alert-success" role="alert"><a href="<?php echo base_url();?>ruby_post.zip" download>Click here</a> to download the sample Ruby http post script for the endpoint</div>
<div class="alert alert-success" role="alert"><a href="<?php echo base_url();?>logalytics.zip" download>Click here</a> to download the log watcher with supervisor code.</div>
</div>

<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

  </body>
  </html>
