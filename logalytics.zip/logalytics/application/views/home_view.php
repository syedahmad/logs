<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap 101 Template</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>style.css">

  </head>
  <body>

  	<div class="container">

		<div class="row">

			<div class="navbar navbar-default navbar-inner navbar-fixed-top" role="navigation">



					<div class="navbar-header">



				        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">



				        <span class="sr-only">Toggle navigation</span>



				        <span class="icon-bar"></span>



				        <span class="icon-bar"></span>



				        <span class="icon-bar"></span>



				        </button>



				        <a class="navbar-brand" rel="home" href="<?=$base_url;?>" title="Buy Sell Rent Everyting">Logalitics</a>



				    </div>



				    <div class="collapse navbar-collapse navbar-ex1-collapse">


						<ul class="nav navbar-nav navbar-right">



							<li class="dropdown">



				                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi <?php echo $username;?><b class="caret"></b></a>



				                <ul class="dropdown-menu">
				                 


				                  <li><a href="#">Account</a></li>



				                  <li class="divider"></li>



				                  <li><a href="<?= $logout?>">Logout</a></li>



				                </ul>



				            </li>



							<li class="dropdown">



				                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Package<b class="caret"></b></a>



				                <ul class="dropdown-menu">



				                  <li><a href="<?= $add ?>">Add Package</a></li>
				             


				                </ul>



				            </li>



						</ul>



				    </div>



				</div>				


		</div>	

	</div>
 	

	<div class="container navbar navbar-default navbar-info" style="padding-top:0.0.10px !important; padding-bottom:0.05px !important; min-height: 10px !important; margin-bottom: 10px; background-color: #4A70E9; margin-top: 50px;" >

      	<ul class="nav nav-pills nav-justified">
			
		</ul>

	</div>
	<div class="container my-container">
		<form role="form" action="<?php echo Site_url();?>/push_notification" method="POST">

      	<button type="submit" class="btn btn-primary" name="push" href='#'>Send push notification</button>
      </form>
   		<br>
    </div>
<div class="container my-container">
<div class="row">	
	<?php foreach ($package as $item):?>

	    <div class="col-lg-4 col-md-4 data-b">

	          <center>

	          <h2><?php echo $item['Package_Name'];?></h2></center>

	          <p>Specs:</p>

	          <ul>

	          	<li>Num_Apps_Allowed&nbsp; :&nbsp;<?php echo $item['Num_Apps_Allowed'];?></li>

	          	<li>Log_Retention_Period &nbsp;:&nbsp;<?php echo $item['Log_Retention_Period'];?></li>

	          	<li>Max_Storage_Allowed &nbsp;:&nbsp;<?php echo $item['Max_Storage_Allowed'];?></li>
	    
	          </ul>

	          <p>₹ <?php echo $item['Package_Cost'];?> /-</p>

	          <center><p><form action="" method="post">
 				 <button class="btn btn-info btn-lg" href="#" type="submit" value="<?= $item['Package_Id'];?>" name="product"> <?= $item['Package_State'];?></button>
  
				</form></p></center>

	    </div><!-- /.col-lg-4 -->
		<?php endforeach;?>
</div>

</div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
     <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
  </body>
</html>

