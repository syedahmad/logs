<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Logalytics: User Aplications</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>style.css">

<script type="text/javascript">
    
</script>
  </head>
  <body>
<div class="modal show" id="createAppModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Application Keys</h4>
      </div>
      <div class="modal-body">

       <div align="center">
    <h3><?php echo $App_Name;?></h3>
  </div>
  <br>
  <div align="center">
  Are you sure you want to delte this app, all the associated logs will be deleted permanently!
</div>
 
      </div>
      <div class="modal-footer">
       <form role="form" action="<?php echo Base_url();?>index.php/apps" method="POST">
     
   <button type="submit" class="btn btn-primary" name="return_app_view" href="<?php echo base_url();?>/apps">Close</button>
   <button type="submit" class="btn btn-primary" name="delete_confirmation" >Delete</button>
 </div>
 </form>
      </div>
    </div>
  </div>
</div>

<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>

<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>


  </body>
  </html>









