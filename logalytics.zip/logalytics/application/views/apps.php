    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Logalytics: User Applications</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>
   
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?php echo base_url();?>style.css">

    <script type="text/javascript">
    
    </script>
    </head>
    <body>

    <div class="container">

    <div class="row">

    <div class="navbar navbar-default navbar-inner navbar-fixed-top" role="navigation">

    <div class="navbar-header">

    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">



    <span class="sr-only">Toggle navigation</span>



    <span class="icon-bar"></span>



    <span class="icon-bar"></span>



    <span class="icon-bar"></span>



    </button>



    <a class="navbar-brand" rel="home" href="<?php echo Base_url();?>" title="Buy Sell Rent Everyting">Logalytics</a>
    <ul class="nav navbar-nav">

    <li><a href="<?php echo Site_url();?>/products">Pricing</a></li>
    <li><a href="#">DashBoard</a></li>
    <li><a href="#">QuickStart</a></li>
    <li><a href="#">Tutorials</a></li>
    <li><a href="<?php echo Site_url();?>/apps/downloads">Downloads</a></li>


              

    <li><a href="#">Help</a></li>
            
    </ul>



    </div>



    <div class="collapse navbar-collapse navbar-ex1-collapse">


    <ul class="nav navbar-nav navbar-right">



    <li class="dropdown">



    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi <?php echo $this->session->userdata('username');?><b class="caret"></b></a>



                        <ul class="dropdown-menu">
                         


                          <li><a href="#">Account</a></li>



                          <li><a href="#">Settings</a></li>



                          <li class="divider"></li>



                          <li><a href="#">Reviews</a></li>



                          <li class="divider"></li>



                          <li><a href="<?=$logout;?>">Logout</a></li>



                       </ul>



                        </li>
          
            </ul>
            </div>
        </div>        
    </div>  
 </div>
   
    <div class="container my-container">
      <br><br><br><br>

      <?php
      if ($remaining_apps != 0)
      echo '<span style="float:right"><button type="button" class="btn btn-primary" name="create_app" href="#" data-toggle="modal" data-target="#createAppModal">Create App</button></span>';
      else
      {
       echo '<span style="float:right"><button type="button" class="btn btn-primary" name="create_app" href="#" data-toggle="modal" data-target="#createLimitExceededModal">Create App</button></span>'; 
      }
      ?>

   <br>
      
      <h3>Existing User Apps: <?php echo $num_apps;?> </h3>
      <div class="row">
        <?php
        
        foreach ($Application_Names as $app)
        {
          //$name_string = $app."_count";
          echo "<div class=\"col-lg-4 col-md-4 data-b\"><center><h2>".str_replace("_7_7_"," ",$app)."</h2></center>
          <br>
          no. of events: ".$Application_Events[$app]."
          <br><br><form role=\"form\" action=\"".Base_url()."index.php/apps\" method=\"POST\">
           <center><button type=\"submit\" name=\"".$app."_Data_Viewer\" 
           class=\"btn btn-primary\"  href=\"#\">Data Viewer</button>
          <button type=\"button\" name=\"".$app."_Settings\" class=\"btn btn-success\" data-toggle=\"modal\" data-target=\"#AppSettingsModal_".$app."\" href=\"#\">Settings</button>
          <button type=\"button\" name=\"".$app."_Delete\" class=\"btn btn-danger\" data-toggle=\"modal\" data-target=\"#deleteAppModal_".$app."\" href=\"#\">Delete</button></center></form></div>";
          
        }
        
        ?>
    </div>
    </div>

<div class="modal fade" id="createAppModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"></h4>
      </div>
      <div class="modal-body">
        <h1>&nbsp;&nbsp;Create an app</h1>
    <div class="container-fluid">
     <br>
   <form role="form" action="<?php echo Base_url();?>index.php/apps" method="POST">
   
   <input type="text" class="form-control" id="AppName" name="AppName" placeholder="Enter AppName"><br>
 
   <button type="submit" class="btn btn-primary" name="save_changes" href='#' data-toggle="modal" data-target="#createAppModal">Create App</button>
    
      
   </form>
    
   </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
  </div>
</div>
</div>

<div class="modal fade" id="createLimitExceededModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"></h4>
      </div>
      <div class="modal-body">
        <h1>App create limit exceeded!</h1>
        Sorry! You can't create more apps with the current package you own. To upgrade to a new package go to the pricing page.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <a  class="btn btn-default" href="<?php echo Site_url();?>/products">Pricing</a>

    </div>
  </div>
</div>
</div>


<?php
foreach ($Application_Names as $app)
{
  echo '
<div class="modal fade" id="deleteAppModal_'.$app.'" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            <h4 class="modal-title" id="myModalLabel">&nbsp;&nbsp;Delete</h4>
            </div>
            <div class="modal-body">
            <div align="center">
            <h2>'.str_replace("_7_7_"," ",$app).'</h2><br>
            </div>
              <div align="center">
              <h4>Are you sure you want to delete this app? All the associated logs will be deleted permanently!</h4>
            </div>
            <br><br>
            
            </div>
            <div class="modal-footer">
                <form role="form" action="'. Base_url().'index.php/apps" method="POST">
                 <button type="submit" class="btn btn-primary" href="#" name="delete_confirmation_'.$app.'">Delete</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </form>
                 
        </div>
    </div>
  </div>
</div>';
}


foreach ($Application_Names as $app)
{
  echo '
<div class="modal fade" id="AppSettingsModal_'.$app.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Application Keys</h4>
      </div>
      <div class="modal-body">

       <div align="center">
    <h3>'.str_replace("_7_7_"," ",$app).'</h3>
  </div>
  <br>
  <div align="center">
  User ID: '.$user_id.' <br>
  App ID: '.$Application_Keys[$app][5].' <br>
  Rest Key: '.$Application_Keys[$app][0].' <br>
  JS Key: '.$Application_Keys[$app][1].' <br>
  Client Key: '.$Application_Keys[$app][2].' <br>
  Python Key: '.$Application_Keys[$app][3].' <br>
  JS Key: '.$Application_Keys[$app][4].' <br> 
</div>
  
      </div>
      <div class="modal-footer">
       
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   
 </div>

      </div>
    </div>
  </div>
</div>';
}



?>


<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<script>

$(document).ready(function(){
      
      $("#create_app_confirm").on("click", function(){ $("#deleteAllAppsModal").modal();});

    });
</script>

  </body>
  </html>
