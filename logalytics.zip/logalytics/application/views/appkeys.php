<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Logalytics: User Aplications</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>style.css">

<script type="text/javascript">
    
</script>
  </head>
  <body>
<div class="modal show" id="createAppModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Application Keys</h4>
      </div>
      <div class="modal-body">

       <div align="center">
    <h3><?php echo str_replace("_7_7_"," ",$App_Name);?></h3>
  </div>
  <br>
  <div align="center">
    UserId: <?php echo $user_id;?> <br>
    AppID: <?php echo $App_Id;?> <br>
  AppKey: <?php echo $App_Key;?> <br>
  RestKey: <?php echo $Rest_Key;?> <br>
  ClientKey: <?php echo $Client_Key;?> <br>
  PythonKey: <?php echo $Python_Key;?> <br>
  JSKey: <?php echo $JS_Key;?> 
</div>
  <!--Active Applications: <?php var_dump($Application_Names);?> -->
      </div>
      <div class="modal-footer">
       <form role="form" action="<?php echo Base_url();?>index.php/apps" method="POST">
     
   <button type="submit" class="btn btn-primary" name="return_app_view" href="<?php echo base_url();?>/apps">Close</button>
 </div>
 </form>
      </div>
    </div>
  </div>
</div>

<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>


  </body>
  </html>









