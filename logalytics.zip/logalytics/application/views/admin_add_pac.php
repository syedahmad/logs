<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Package Addition</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>style.css">
  </head>
  <body>

  	<div class="container">

		<div class="row">

			<div class="navbar navbar-default navbar-inner navbar-fixed-top" role="navigation">



					<div class="navbar-header">



				        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">



				        <span class="sr-only">Toggle navigation</span>



				        <span class="icon-bar"></span>



				        <span class="icon-bar"></span>



				        <span class="icon-bar"></span>



				        </button>



				        <a class="navbar-brand" rel="home" href="<?=$base_url;?>" title="Buy Sell Rent Everyting">Logalitics</a>



				    </div>



				    <div class="collapse navbar-collapse navbar-ex1-collapse">


						<ul class="nav navbar-nav navbar-right">



							<li class="dropdown">



				                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi <?php echo $username;?><b class="caret"></b></a>



				                <ul class="dropdown-menu">
				                 


				                  <li><a href="#">Account</a></li>



				                  <li class="divider"></li>



				                  <li><a href="<?= $logout ?>">Logout</a></li>



				                </ul>



				            </li>



							<li class="dropdown">



				                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Packages<b class="caret"></b></a>



				                <ul class="dropdown-menu">

									<?php foreach ($package as $item):?>

	        							  <li><a href="#"><?php echo $item['Package_Name'];?></a></li>
	          
									<?php endforeach;?>				                  
				                 
				                </ul>



				            </li>



						</ul>



				    </div>



				</div>				


		</div>	

	</div>
 	

	<div class="container navbar navbar-default navbar-info" style="padding-top:0.0.10px !important; padding-bottom:0.05px !important; min-height: 10px !important; margin-bottom: 10px; background-color: #4A70E9; margin-top: 50px;" >

      	<ul class="nav nav-pills nav-justified">
			
		</ul>

	</div>
<div class="container">
	<?php if($error) echo '<center><div class="alert alert-danger">Please Add Valid Data</div></center>'; ?>
<div class="row">	
	<form class="form-horizontal" role="form" method="post" id="myform">

				  <div class="form-group">

				    <label for="Num_Apps_Allowed" class="col-sm-2 control-label">Num_Apps_Allowed</label>

				    <div class="col-sm-5">

				      <input type="text" class="form-control" id="inputNAA" placeholder="Enter Num_Apps_Allowed..." name="inputNAA">

				    </div>

				  </div>

				  <div class="form-group">

				    <label for="Log_Retention_Period" class="col-sm-2 control-label">Log_Retention_Period </label>

				    <div class="col-sm-5">

				      <input type="text" class="form-control" id="inputLRP" placeholder="Enter Log_Retention_Period ..." name="inputLRP">

				    </div>

				  </div>

				  <div class="form-group">

				    <label for="Max_Storage_Allowed" class="col-sm-2 control-label">Max_Storage_Allowed</label>

				    <div class="col-sm-5">

				      <input type="text" class="form-control" id="inputMSA" placeholder="Enter Max_Storage_Allowed..." name="inputMSA">

				    </div>

				  </div>

				  <div class="form-group">

				    <label for="inputPN" class="col-sm-2 control-label">Package_Name</label>

				    <div class="col-sm-5">

				      <input type="text" class="form-control" id="inputPN" placeholder="Package_Name..." name="inputPN">

				    </div>				    

				    </div>
				    <div class="form-group">

				    <label for="Package_Cost" class="col-sm-2 control-label">Package_Cost</label>

				    <div class="col-sm-5">

				      <input type="text" class="form-control" id="inputPC" placeholder="Package_Cost..." name="inputPC">

				  </div>
				</div>

	</form>
</div>
<center><button type="submit" class="btn btn-primary" form="myform" name="add_pac" value='1'>ADD PACKAGE</button></center>

</div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
     <script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
  </body>
</html>

