<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	 <head>
	   <title>Logalytics <?php echo $title  ?></title>
	   <meta name = "viewport" content = "width=device-width, initial-scale= 1.0">
		 <link rel="stylesheet" type="text/css"  href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css"/> 
		 <link href="<?php echo Base_url(); ?>css/styles.css" rel="stylesheet" type="text/css"> 
	 </head>
	 <body>
		<div class="navbar navbar-inverse navbar-static-top">
			<div class="container">
				<button class = "navbar-toggle" data-toggle = "collapse" data-target = ".navbar-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span> 

				</button>

				<a href="<?php echo Base_url(); ?>" class="navbar-brand">Logalytics</a>
				
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right">
						<li class="active"><a href = "<?php echo Base_url(); ?>index.php/user">Login</a></li>						
						<li><a href = "#"> Register</a></li>
						

					</ul>
				</div>
				
			</div>
		</div>	
		<?php if($this->session->userdata('logged_in'))
				   {$loggedin = 1; }
				   else{$loggedin = 0;}
				   ?>
		<div class="container">
		
				   
		   <h1><?php if($loggedin){echo "Already Logged in";}
		   else {echo "LogIn to Admin Panel";}
		?></h1>
		   <?php echo validation_errors(); ?>
		   <?php if(isset($message))echo $message; ?>
		   <?php if($loggedin)
				   {
					  redirect("home");
			
				   } 
			

			?>
		   <?php //echo form_open('index.php/verifylogin'); ?>
			 <form name="form1" action="<?php echo site_url();?>/verifylogin" method="POST">
			<table class= "table">	
				<tr><td><label for="username">Username:</label></td><td>
				 <input type="text" size="20" id="username" name="username" <?php if($loggedin)
					   { echo "disabled";} ?> /> </td></tr>
				 
				 <tr><td><label for="password">Password:</label></td><td>
				 <input type="password" size="20" id="passowrd" name="password" <?php if($loggedin)
					   { echo "disabled";} ?>/></td></tr>
				 
				 
			</table> 
			<input type="submit" value="Login"/>
		   </form>
		</div>
		
	   	<!-- <script src="<?php echo Base_url();?>js/bootstrap.min.js"></script>
		<script src="<?php echo Base_url();?>js/jquery-1.11.0.min.js"></script> -->

		
		<!-- Footer Footer Footer Footer Footer Footer Footer Footer Footer Footer Footer Footer -->
			
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
		<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
	 </body>
	</html>
