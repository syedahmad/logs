<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-social/4.2.1/bootstrap-social.css">
    <link rel="stylesheet" href="<?php echo base_url();?>style.css">
</head>
<body>        

        <div class="container">

			<div class="row">

				<div class="navbar navbar-default navbar-inner navbar-fixed-top" role="navigation">

					<div class="navbar-header">

				        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">

				        <span class="sr-only">Toggle navigation</span>

				        <span class="icon-bar"></span>

				        <span class="icon-bar"></span>

				        <span class="icon-bar"></span>

				        </button>

				        <a class="navbar-brand" rel="home" href=" <?=$base_url;  ?>" title="Buy Sell Rent Everyting">Logalitics</a>

				    </div>  
				    <div class="collapse navbar-collapse navbar-ex1-collapse"> 				       
						<ul class="nav navbar-nav">

							<li><a href="<?= $product_url; ?>">Pricing</a></li>

							<li><a href="#">Docs</a></li>

							<li><a href="#">Help</a></li>
						
						</ul>

						<ul class="nav pager navbar-right">

							<li><a data-toggle="modal" href="#login" data-target="#signup">Login</a></li>

							<li><a data-toggle="modal" href="#signup" data-target="#signup">Sign Up</a></li>
												
						</ul>
					</div>					 

				</div>				

			</div>	

		</div>
        <div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

	<div class="modal-dialog modal-vertical-centered">

		<div class="modal-content">

		    <div class="modal-header">

		        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

		        <center><h4 class="modal-title" id="myModalLabel">SignUp</h4></center>

		    </div>

		    <div class="modal-body">

		        <form class="form-horizontal" role="form" method="post" id="myform">

				  <div class="form-group">				    

				    <div class="col-sm-10">

				      <a href="<?= $fb_url ?>" class="btn btn-block btn-social btn-facebook" role="button"><i class="fa fa-facebook"></i>Login with Facebook</a>	

				    </div>

				  </div>

				  <div class="form-group">
				    
				    <div class="col-sm-10">

				     <a href="<?= $google_url ?>" class="btn btn-block btn-social btn-google-plus" role="button"><i class="fa fa-google-plus"></i>Login with Google</a>	

				    </div>

				  </div>

				  <div class="form-group">
				    
				    <div class="col-sm-10">

				        <a href="<?= $git_url ?>" class="btn btn-block btn-social btn-github" role="button"><i class="fa fa-github"></i>Login with Git Hub</a></center>

				    </div>

				  </div>				  

				</form>

		    </div>

		    <div class="modal-footer">

		        <center><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></center>
		        
		    </div>

		</div>

    </div>

        </div>
		<div class="container navbar navbar-default navbar-info" style="padding-top:0.0.5px !important; padding-bottom:0.05px !important; min-height: 30px !important; margin-bottom: 10px; background-color: #4A70E9; margin-top: 50px;" >

      		<ul class="nav nav-pills nav-justified">
			
			</ul>

		</div>

		<div class="container">
			<?php if($git_error) echo '<center><div class="alert alert-danger">Please Fill your Profile-Info and then re-login</div></center>'; ?>
    <div class="row">
       <div class="col-md-2 col-md-offset-3"><iframe width="500" height="400" src="http://www.youtube.com/embed/MY__5O1i2a0" frameborder="4" allowfullscreen></iframe></div>
    </div>

		</div>

		<br/>
		<br/>


		<div class="container">
    <div class="row">
        <div class="span6 offset3">                  
                <p style="line-height: 70px; text-align: center;"><button class="btn btn-primary">Try For Free</button></p>            
        </div>
    </div>

		</div>



		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    	<script type="text/javascript" src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
</body>
</html>
