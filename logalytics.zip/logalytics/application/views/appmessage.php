
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Logalytics: User Aplications</title>

    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">

    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>

   
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>style.css">

<script type="text/javascript">
    
</script>
  </head>
  <body>

   
<div class="modal show" id="createAppModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Congrats!!</h4>
      </div>
      <div class="modal-body">
        <div align="center"
        <p> <h5>Your app <?php echo "'";echo  str_replace("_7_7_"," ",$New_App_Name);echo "'";?> has been successfully created! <br><br> Have a look at your keys. Please do not share these with anyone.</h5></p><br>
        </div>
  <div align="center">
    <h2>Keys</h2>
  </div>
  <div align="center">
  <p>
  User-Id: <?php echo $user_id;?> <br>
  App-Id: <?php echo $New_App_Id;?> <br>
  PythonKey: <?php echo $New_Python_Key;?> <br>
  RestKey: <?php echo $New_Rest_Key;?> <br>
  ClientKey: <?php echo $New_Client_Key;?> <br>
  APIKey: <?php echo $New_API_Key;?><br>
  JSKey: <?php echo $New_JS_Key;?><br>
</p></div>

     </div>
      <div class="modal-footer">
          <div class="container-fluid" align ="center">
      
   <form role="form" action="<?php echo Base_url();?>index.php/apps" method="POST">
   <input type = "hidden" name="App_Name" value="<?php echo $New_App_Name;?>">
   <input type = "hidden" name="App_Id" value="<?php echo $New_App_Id;?>">
  <input type = "hidden" name="App_Key" value="<?php echo $New_API_Key;?>">
    <input type = "hidden" name="Client_Key" value="<?php echo $New_Client_Key;?>">
    <input type = "hidden" name="Rest_Key" value="<?php echo $New_Rest_Key;?>">
       <input type = "hidden" name="Python_Key" value="<?php echo $New_Python_Key;?>">
        <input type = "hidden" name="JS_Key" value="<?php echo $New_JS_Key;?>">
        <input type = "hidden" name="Application_Names" value="<?php print_r($Application_Names);?>">
    <div class='row'>
   <button type="submit" class="btn btn-primary" name="view_keys" >View All Keys</button>
  
   <button type="submit" class="btn btn-primary" name="data_browser" >Data Browser</button>
   <button type="submit" class="btn btn-primary" name="app_message_button" href="#">Quick Start Guide</button>
   
   <button width="20%" type="submit" class="btn btn-primary" name="return_app_view" href="<?php echo base_url();?>/apps">Close</button>
 </div>
 </form>
</div>
 
       
      </div>
    </div>
  </div>
</div>


<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>

<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>


  </body>
  </html>


