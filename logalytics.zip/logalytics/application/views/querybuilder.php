<!DOCTYPE html>
<html lang="en">
<head>

    <style>

		#overlay { 
  			display:none; 
 			background:#fff; 
		}

	</style>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Logalytics: User Applications</title>
    
    <!-- _______________________________________________ -->
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link href="http://fonts.googleapis.com/css?family=Lato:400,700" rel="stylesheet" type="text/css">
    <link href='http://fonts.googleapis.com/css?family=Denk+One' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
	<link rel="stylesheet" href="style.css">
    
    <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    </head>

    <body>
    	
    <div class="container">
	<div class="row">
	<div class="navbar navbar-default navbar-inner navbar-fixed-top" role="navigation">
	
	<div class="navbar-header">
	
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
		
		<span class="sr-only">Toggle navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>

	    </button>

	    <a class="navbar-brand" rel="home" href="<?php echo Base_url();?>" title="Logalytics">Logalytics</a>
	    
	    <ul class="nav navbar-nav">

	    <li><a href="<?php echo Site_url();?>/products">Pricing</a></li>
	    <li><a href="<?php echo Site_url();?>/apps">DashBoard</a></li>
	    <li><a href="#">QuickStart</a></li>
	    <li><a href="#">Tutorials</a></li>
	    <li><a href="<?php echo Site_url();?>/apps/downloads">Downloads</a></li>
		<li><a href="#">Help</a></li>
	            
	    </ul>

    </div>

    <div class="collapse navbar-collapse navbar-ex1-collapse">

		<ul class="nav navbar-nav navbar-right">
	    <li class="dropdown">
	    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Hi <?php echo $this->session->userdata('username');?><b class="caret"></b></a>

	                        <ul class="dropdown-menu">
	                       
	                          <li><a href="#">Account</a></li>

	                          <li><a href="#">Settings</a></li>

	                          <li class="divider"></li>

	                          <li><a href="#">Reviews</a></li>

	                          <li class="divider"></li>

	                          <li><a href="<?php echo Site_url();?>/auth/logout">Logout</a></li>

	                        </ul>

	    </li>
	          
	    </ul>
    </div>
    </div>        
    </div>  
 	</div>

	<br><br><br>  
  
<p>Enter the query in the field, then click "Submit" to submit the form:</p>

<div class="btn-group">

	<form id="query_form" action = "#" method="POST">
		
		<button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" value = "7" id = "time_dropdown"> Time <span class="caret"></span>
	    </button>

	  	<ul class="dropdown-menu" role="menu" >
		    <li value = "1" class = 'time_op'><a href="#">Last 15 minutes</a></li>
		    <li value = "2" class = 'time_op'><a href="#">Last 30 minutes</a></li>
		    <li value = "3" class = 'time_op'><a href="#">Last 60 minutes</a></li>
		    <li value = "4" class = 'time_op'><a href="#">Last 24 hours</a></li>
		    <li value = "5" class = 'time_op'><a href="#">Last 7 days</a></li>
		    <li value = "6" class = 'time_op'><a href="#">Last 30 days</a></li>
		    <li value = "7" class = 'time_op'><a href="#">All time</a></li>
		    <button type="button" class="btn btn-default" name="custom_time" href='#' data-toggle="modal" data-target="#customTimeModal">Custom</button>
	  	</ul>

	 	<input type="textbox" name="query" id = "query" size="100">
		<input type="button" class="btn btn-default" value="Submit" id="query_submit">

	</form>

</div>

<div class="btn-group">

	<button type="button" class="btn btn-default btn-sm dropdown-toggle" value = "8" data-toggle="dropdown" id = "type_dropdown">
    Log Type <span class="caret"></span>
  	</button>

  <ul class="dropdown-menu" role="menu" >

    <li value = "1" class = 'type_op'><a href="#">JSON</a></li>
    <li value = "2" class = 'type_op'><a href="#">XML</a></li>
    <li value = "3" class = 'type_op'><a href="#">Access Logs</a></li>
    <li value = "4" class = 'type_op'><a href="#">Error Logs</a></li>
    <li value = "5" class = 'type_op'><a href="#">IIS Logs</a></li>
    <li value = "6" class = 'type_op'><a href="#">W3C Extended Format</a></li>
    <li value = "7" class = 'type_op'><a href="#">NCSA Common Log File</a></li>
    <li value = "8" class = 'type_op'><a href="#">ALL</a></li>
      
  </ul>

</div>

<?php 

		$App_Names = array();

	    $m = new MongoClient();							//establishing connection with a mongo db
  		
   		$User_DB = $m->$User_Id;						//user_id is passed here by the controller
   		
   		$App_Collection = $User_DB->Apps;				
   		
   		$cursor = $App_Collection->find();

   		$m = 0;

   		foreach($cursor as $row)						//collecting all the created app names in an array
   		{
   			$App_Names[$m] = $row['App_Name'];
   			$m++;
   		}

   		$m = 0;											// for future use
   		
   		$Tags_Collection_Name = $App_Id."_Tags";
   		
		$Tags_Collection = $User_DB->$Tags_Collection_Name;

		$Tags = array();

		//Finding all tags of the current app from the App_Id_Tags collection for future display purposes

		$Json_cursor = $Tags_Collection->findOne(array("tags_Json" => array('$exists' => true)));
		$Xml_cursor = $Tags_Collection->findOne(array("tags_Xml" => array('$exists' => true)));
		$Access_Log_cursor = $Tags_Collection->findOne(array("tags_Access_Log" => array('$exists' => true)));
		$Error_Log_cursor = $Tags_Collection->findOne(array("tags_Error_Log" => array('$exists' => true)));
		$IIS_Log_File_Format_cursor = $Tags_Collection->findOne(array("tags_IIS_Log_File_Format" => array('$exists' => true)));
		$W3C_Extended_Log_Format_cursor = $Tags_Collection->findOne(array("tags_W3C_Extended_Log_Format" => array('$exists' => true)));
		$NCSA_Common_Log_Format_cursor = $Tags_Collection->findOne(array("tags_NCSA_Common_Log_Format" => array('$exists' => true)));	
		$All_cursor = $Tags_Collection->findOne(array("tags" => array('$exists' => true)));
		
		$Tags_Json = $Json_cursor['tags_Json'];
		$Tags_Xml = $Xml_cursor['tags_Xml'];
		$Tags_Access_Logs = $Access_Log_cursor['tags_Access_Log'];
		$Tags_Error_Log = $Error_Log_cursor['tags_Error_Log'];
		$Tags_IIS_Log_File_Format = $IIS_Log_File_Format_cursor['tags_IIS_Log_File_Format'];
		$Tags_W3C_Extended_Log_Format = $W3C_Extended_Log_Format_cursor['tags_W3C_Extended_Log_Format'];
		$Tags_NCSA_Common_Log_Format = $NCSA_Common_Log_Format_cursor['tags_NCSA_Common_Log_Format'];
		$Tags = $All_cursor['tags'];
		
?>

		<div class="btn-group">
		<button type="button" class="btn btn-default btn-sm dropdown-toggle" value = "1" data-toggle="dropdown" id = "app_dropdown">
    		Select An App<span class="caret"></span>
  		</button>

		<ul class="dropdown-menu" role="menu" >
		  	
		  	<?php 

		  	//This is the app dropdown, the str_replace is used as app 
		  	//with spaces in their names cause problems in button names, 
		  	//so spaces are first replaced by "_7_7" and then worked on
		  	//But for display purposes this is restored.

		  	while ($m<sizeof($App_Names))
		  	{	
		  		
		  		$i = $m+1;
		  		echo '<li value = "'.$i.'" class = "app_op"><a href="#">'.str_replace("_7_7_"," ",$App_Names[$m]).'</a></li>';
		    	$m++;

			}

			$i=0;$m=0;

		    ?>
		</ul>


		</div>

		<br><br>

		<h1>APP TAGS</h1>
	
		<!--Following are the log fields / tags of all types
		 	of logs, only the chosen log type's tags
		  	are shown, rest are hidden
		-->

		<span id="tags_output">

			<span class="Logs" id ="1">

				    <table class="table auto-width" style = "width:100%"><tr> 
				    	<?php
							$n=1;
							foreach ($Tags_Json as $tag) 
							{

								if ($tag!= "Log_Type" && $tag!= "_id" && $tag!= "Time_Of_Arrival")
								{
									echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
								}

								if($n==11)
								{
									echo "</tr><tr>";
									$n=0;
								}

								$n=$n+1;
						
							}
						?>
					</tr>
					</table>

			</span>

			<span class="Logs" id ="2">

			    <table class="table auto-width" style = "width:100%"><tr> 

			    	<?php

						$n=1;
						foreach ($Tags_Xml as $tag) 

						{

						if ($tag!= "Log_Type" && $tag!= "_id" )
						{

							echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
						}

						if($n==11)
						{
							echo "</tr><tr>";
							$n=0;
						}

						$n=$n+1;
					
						}
					?>
				</tr>
				</table>

			</span>

			<span class="Logs" id ="3">
			    
			    <table class="table auto-width" style = "width:100%"><tr> 
			    	
			    	<?php

						$n=1;
						foreach ($Tags_Access_Logs as $tag) 

						{

							if ($tag!= "Log_Type" && $tag!= "_id")
							{
								echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
						
							}
							if($n==11)
							{
								echo "</tr><tr>";
								$n=0;
							}
							$n=$n+1;
						
						}
					?>
				</tr>
				</table>

			</span>

			<span class="Logs" id ="4">
			    
			    <table class="table auto-width" style = "width:100%"><tr> 

				    <?php

						$n=1;

						foreach ($Tags_Error_Log as $tag) 

						{

							if ($tag!= "Log_Type" && $tag!= "_id" )
							{

								echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
							
							}

							if($n==11)
							{
								echo "</tr><tr>";$n=0;}
								$n=$n+1;
							}
					?>
				
				</tr>
				</table>

			</span>
			
			<span class="Logs" id ="5">

			    <table class="table auto-width" style = "width:100%"><tr> 

			    <?php
					
					$n=1;

					foreach ($Tags_IIS_Log_File_Format as $tag) 
					{

						if ($tag!= "Log_Type" && $tag!= "_id" )
						{
							echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
						
						}

						if($n==11)
						{
							echo "</tr><tr>";$n=0;
						}

						$n=$n+1;
						
					}
				?>

				</tr>
				</table>

			</span>

			<span class="Logs" id ="6">

			    <table class="table auto-width" style = "width:100%"><tr> 
			    <?php
					
					$n=1;
					foreach ($Tags_W3C_Extended_Log_Format as $tag)
					
					{

						if ($tag!= "Log_Type" && $tag!= "_id" )
						{
							echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
						
						}
						if($n==11)
							{
								echo "</tr><tr>";
								$n=0;
							}
						$n=$n+1;
						
					}
				?>
				</tr>
				</table>
			</span>

			<span class="Logs" id ="7">
			    <table class="table auto-width" style = "width:100%"><tr> 
			    <?php
					$n=1;
					foreach ($Tags_NCSA_Common_Log_Format as $tag) 
					{

						if ($tag!= "Log_Type" && $tag!= "_id" )
							echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
						if($n==11)
						{
							echo "</tr><tr>";
							$n=0;
						}
						$n=$n+1;
					
					}
				?>
				</tr>
				</table>
			</span>

			<span class="Logs" id ="8">
			    <table class="table auto-width" style = "width:100%"><tr> 
			    <?php
					$n=1;
					foreach ($Tags as $tag) {

						if ($tag!= "Log_Type" && $tag!= "_id" )
							echo '<td><input type="checkbox" class="check" name='.$tag.' value="'.$tag.'"><br>'.$tag.' &nbsp;&nbsp;&nbsp;</td>';
						if($n==11)
						{
							echo "</tr><tr>";
							$n=0;
						}
						$n=$n+1;
					
					}
				?>
				</tr>
				</table>
			</span>
		</span>
	

	<br><br>

	<h1>AGGREGATE TAGS</h1>			<!--Aggregate tags - sum, avg, count-->
		
		<span class="Aggregate" id ="Agg">
		    <table class="table auto-width" style = "width:100%">
		    <tr> 
		    	
			<td><input type="checkbox" class="Aggcheck" name="count" value="count" data-toggle="modal" data-target="#countQueryModal"><br>Count &nbsp;&nbsp;&nbsp;</td>
			<td><input type="checkbox" class="Aggcheck" name="average" value="average" data-toggle="modal" data-target="#averageQueryModal"><br>Average &nbsp;&nbsp;&nbsp;</td>
			<td><input type="checkbox" class="Aggcheck" name="sum" value="sum" data-toggle="modal" data-target="#sumQueryModal"><br>Sum &nbsp;&nbsp;&nbsp;</td>
				
			</tr>
			</table>	
		</span>
			
		<script>
			
		 $(document).ready(function(){

		 	var option = "#8";		//By default all types of logs are selected so all the fields are shown as checkboxes
		 	
		 	$(option).show();
			$(option).siblings().hide();

			var App_Name = '<?php echo str_replace("_7_7_"," ",$App_Name); ?>'; 	//for display removing the "_7_7" from the app name earlier placed instead of the tags
			var User_Id = '<?php echo $User_Id; ?>';

			$("#app_dropdown").text(App_Name);
			$("#app_dropdown").html($("#app_dropdown").text()+ "&nbsp; <span class=\"caret\"></span>");
			
			//when an aggregate tag checkbox is checked or unchecked
			//a bootstrap modal displaying how to use this aggregate tag for querying
			//and text "agg_tag(replace_it)" is appended in the querybox.

			$(".Aggcheck").click(function(){

					var old = $("#query").val();	//whatever was initially present in the query box
					old.replace(/\s+/g, ' ');			
					var query_string = "";
					var value= $(this).val();

					value.replace(/\s+/g, ' ');
					value.trim();
									
					var boxname=$(this).attr('name');	//the name of the checkbox
								
					query_string = query_string.concat(old);
					query_string = query_string.concat(" ");
									
					query_string = query_string.concat(boxname);
					
					query_string = query_string.concat('(replace_it) ');
					query_string.trim();
					
					query_string.replace(/\s+/g, ' ');
					
					$('#query').val(""); 
					
					$('#query').val(query_string); 
					
				    var length = query_string.length; 

				    //setInputSelection is the higlighting function which highlights the text "replace_it" for user ease
					setInputSelection(document.getElementById("query"), length-12, length-2);

			});
		
			//when any log field tag checkbox is checked 
			//text "tag = "replace_it"" is appended in the querybox and when it is 
			//unchecked this text is removed

			$(".Logs").on('click','input',function(){					
			
			   if ($(this).is(':checked'))			//query_string is the new value which will be in the query box after this is clicked
			   {

				var old = $("#query").val();
				old = old.
			       replace (/(^\s*)|(\s*$)/gi, ""). // removes leading and trailing spaces
			       replace (/[ ]{2,}/gi," ").    // replaces multiple spaces with one space 
			       replace (/\n +/,"\n");           // Removes spaces after newlines

				var query_string = "";
				var value= $(this).val();
				
				value.replace(/\s+/g, ' ');
				value.trim();
								
				var boxname=$(this).attr('name');	//name of the clicked checkbox			
				
				query_string = query_string.concat(old);
				query_string = query_string.concat(" ");				
				
				query_string = query_string.concat(boxname);
				query_string = query_string.concat(" = ");
				query_string = query_string.concat('"replace_it" ');
				query_string.trim();
				
				query_string.replace(/\s+/g, ' ');
				
				$('#query').val(""); 
				
				$('#query').val(query_string); 
				
			    var length = query_string.length; 
				setInputSelection(document.getElementById("query"), length-12, length-2);

			}	

			else
			{
				//when a checkbox is unchecked
				//we need to remove text related to it from the query box

				var old = $("#query").val();	//whatever was initially present in the query box
				
				old.trim();

				var query_elements_array = old.split(" ");

				var i = 0;
				var len = query_elements_array.length;
				var new_query_box_value = "";		//the value of the query box after this event
				
				while (i<len)
				{
								
					if (query_elements_array[i]==$(this).attr('name'))
					{
						break;
					}
					new_query_box_value = new_query_box_value.concat(query_elements_array[i]);
					new_query_box_value = new_query_box_value.concat(" ")
					
					i++;
				}
				//skipping the unchecked checkbox's part
				while(i+3<len)
				{
					
					new_query_box_value = new_query_box_value.concat(query_elements_array[i+3]);
					new_query_box_value = new_query_box_value.concat(" ");
								
					i++;
				}
			
				$('#query').val(new_query_box_value); 
				
			}

		});
		}); 
	// END OF Checkbox script


	// when a query is submitted following takes place
		 $(document).ready(function(){
			
			$("#query_submit").click(function(){

				$("#overlay").show();				// the loader image
				$("#output").hide();	

			var query = $("#query").val();

			var set_log_type = $("#type_dropdown").val();			//the log type which is set
			var set_time_dropdown = $("#time_dropdown").val();	 	//the time dropdown which is already set
			var User_Id = '<?php echo $User_Id; ?>';
			var set_app_type = $("#app_dropdown").text();

			jQuery.ajaxSetup({async:false});

			if (set_time_dropdown == "8")					// time dropdown 8 implies custom time 
			{
				var time_drop_text = $("#time_dropdown").html();	

				//extracting the start and end time from the time dropdown text (html)
				startTimeValue = time_drop_text.split(" ")[0].concat(" ").concat(time_drop_text.split(" ")[1]);
				endTimeValue = time_drop_text.split(" ")[3].concat(" ").concat(time_drop_text.split(" ")[4]);
				
				//posting this to the file querybuilder.php in logalytics root through ajax
				var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	$.post(post_variables,{query:query,set_log_type:set_log_type,set_time_dropdown:set_time_dropdown,startTimeValue:startTimeValue,endTimeValue:endTimeValue,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 	
		 $("#output").html(data);
		 });

			}
			else //any other value of time dropdown does not need any starttime and endtime separately, since they are like "last xxx minutes/days/etc" or all time
			{
			var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	$.post(post_variables,{query:query,set_log_type:set_log_type,set_time_dropdown:set_time_dropdown,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 	
		 $("#output").html(data);
		 });
			}
			
			$("#overlay").hide();			//hide the loader image now since the query is completed
			$("#output").fadeIn(1000);		//show the results
		   jQuery.ajaxSetup({async:true});	
									    		
			
		});
		});

		  $(document).ready(function(){

			//when the user wants to input a custom time
			$("#customTimeButton").click(function(){

				$("#overlay").show();	//the loader image
				$("#output").hide();	

			var endTimeValue = $("#endTime").val();

			if(endTimeValue.split(" ").length == 1)			//if the user did only input the date and not time
			{
				endTimeValue = endTimeValue.concat(" 00:00:00");
				
			}

			var startTimeValue = $("#startTime").val();

			if(startTimeValue.split(" ").length == 1)	//if the user did only input the date and not time
			{
				startTimeValue = startTimeValue.concat(" 00:00:00");
				
			}

			var set_log_type = $("#type_dropdown").val(); // the set log type
		    var set_app_type = $("#app_dropdown").text(); //the currently set app 
		    var User_Id = '<?php echo $User_Id; ?>';
			
			var time_dropdown = "8";	//for custom time time dropdown is set to value 8
			
			$("#time_dropdown").val(time_dropdown);
			
			$("#time_dropdown").html( startTimeValue + " to " + endTimeValue + "  &nbsp; <span class=\"caret\"></span>");
						
			jQuery.ajaxSetup({async:false});

			var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	$.post(post_variables,{time_dropdown:time_dropdown,startTimeValue:startTimeValue,endTimeValue:endTimeValue,set_log_type:set_log_type,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 		$("#output").html(data);
		 		 
		 	});	

		 	$("#overlay").hide();		//query is completed, hide the loader image
			$("#output").fadeIn(1000);	//show the output

		   jQuery.ajaxSetup({async:true});	
		});
		});


		 $(document).ready(function(){

			$(".time_op").click(function(){			//the time dropdown options are of class time_op
				
				$("#overlay").show();	
				$("#output").hide();	

			var time_dropdown = $(this).val();
		    var set_log_type = $("#type_dropdown").val();
		    var set_app_type = $("#app_dropdown").text();
		    var User_Id = '<?php echo $User_Id; ?>';
		    $("#time_dropdown").val(time_dropdown);		//the valueof the selected option is set to time dropdown value
		    
		    $("#time_dropdown").html($(this).text()+ "&nbsp; <span class=\"caret\"></span>");

		    jQuery.ajaxSetup({async:false});

		    var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	//post all the information like the current app, current log type etc
		 	$.post(post_variables,{time_dropdown:time_dropdown,set_log_type:set_log_type,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 		$("#output").html(data);
		 	
		 
		 	});

		 	$("#overlay").hide();
			$("#output").fadeIn(1000);		
		   jQuery.ajaxSetup({async:true});	

		 });
		});

		 $(document).ready(function(){

			$(".type_op").click(function(){		//the log type dropdown options have class 'type_op'
				
				$("#overlay").show();			//query begins show the loader
				$("#output").hide();
					
			var log_type = $(this).val();

			$("#type_dropdown").val(log_type); //the valueof the selected option is set to log type dropdown value

			var option= "#" + log_type;
			var set_time_dropdown = $("#time_dropdown").val();
			
			$(option).fadeIn(1000);
			$(option).siblings().hide();	//show only those checkboxes which are of the current log type

			var set_app_type = $("#app_dropdown").text();
		    var User_Id = '<?php echo $User_Id; ?>';

		   $("#type_dropdown").html($(this).text()+ "&nbsp; <span class=\"caret\"></span>");

		   jQuery.ajaxSetup({async:false});

		   if (set_time_dropdown == "8")	//custom time needs startTimeValue and endTimeValue
			{
				var time_drop_text = $("#time_dropdown").html();

				startTimeValue = time_drop_text.split(" ")[0].concat(" ").concat(time_drop_text.split(" ")[1]);
				endTimeValue = time_drop_text.split(" ")[3].concat(" ").concat(time_drop_text.split(" ")[4]);
				
				var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
				 
		 		$.post(post_variables,{log_type:log_type,startTimeValue:startTimeValue,endTimeValue:endTimeValue,set_time_dropdown:set_time_dropdown,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 		$("#output").html(data);
		 	
		 
		 		});
		 	 
			}
			else // non custom time does not require additional post parameters of startTimeValue and endTimeValue
			{
				var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	
		 		$.post(post_variables,{log_type:log_type,set_time_dropdown:set_time_dropdown,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 		$("#output").html(data);
		 			 
		 		});

		 	}
			$("#overlay").hide();
			$("#output").fadeIn(1000);

		   jQuery.ajaxSetup({async:true});		
			
		 });
		});

		$(document).ready(function(){

			$(".app_op").click(function(){

			//the app dropdown options have class set to "app_op"

			$("#overlay").show();	
			$("#output").hide();

			$("#tags_output").hide();	//hide the current tag checkboxes
			
			var app_type = $(this).text();	//the newly selected app

			$("#app_dropdown").text(app_type); //set the current app to the newly selected app
			$("#app_dropdown").html($(this).text()+ "&nbsp; <span class=\"caret\"></span>");

			var User_Id = '<?php echo $User_Id; ?>';
			var set_time_dropdown = $("#time_dropdown").val();
			var set_log_type = $("#type_dropdown").val();
			var set_app_type = $("#app_dropdown").text();

			var index;

		    $('#'+set_log_type).html("");

		  	jQuery.ajaxSetup({async:false});

		    var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	//post the newlyselected app to the querybuilder file to get the new checkboxes to be shown
		 	$.post(post_variables,{app_type:app_type,User_Id:User_Id},function(data){

		 		tag_data = JSON.parse(data);

		 		//tag data contains all the tags of all types in 8 arrays

		 		$('#'+set_log_type).append("");	//empty the visible chekboxes div

		 		//we want to show only those checkboxes which are of the current log type,
		 		//so we only index the concerned subarray of tag_data
		 		for (index = 0; index < tag_data[set_log_type-1].length; ++index) 
		    	{	
		    		if ((index+1)%20 == 0)	//for display purposes
		    		{
		    			$('#'+set_log_type).append("<br><br><br>");
		    		}
		    		if(tag_data[set_log_type-1][index]!= "Line" && tag_data[set_log_type-1][index]!= "_id" && tag_data[set_log_type-1][index]!= "Time_Of_Arrival")
		    		{			    		
			    		addCheckbox(tag_data[set_log_type-1][index]); // takes a name and dynamically creates a checkbox for it
			    		$('#'+set_log_type).append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");			    		
			    	}
		    	}
		    });
		 	$("#tags_output").fadeIn(1000);	//finally, show the new tags	
		    
			if (set_time_dropdown == "8")
			{
				var time_drop_text = $("#time_dropdown").html();
				startTimeValue = time_drop_text.split(" ")[0].concat(" ").concat(time_drop_text.split(" ")[1]);
				endTimeValue = time_drop_text.split(" ")[3].concat(" ").concat(time_drop_text.split(" ")[4]);
				
				var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
				 
		 		$.post(post_variables,{log_type:set_log_type,startTimeValue:startTimeValue,endTimeValue:endTimeValue,set_time_dropdown:set_time_dropdown,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 			$("#output").html(data); });
		 	 
			}
			else
			{
				var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	
		 		$.post(post_variables,{log_type:set_log_type,set_time_dropdown:set_time_dropdown,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 			$("#output").html(data); });
			}

			$("#overlay").hide();
			$("#output").fadeIn(1000);	

		    jQuery.ajaxSetup({async:true});		
						
		 });
		});

		function addCheckbox(input) {

			//adds a checkbox for an input
		  
		   var set_log_type = $("#type_dropdown").val();
		   var container = $('#'+set_log_type);
		   
		   $('<input />', { type: 'checkbox',  value: input, class:'check', name:input }).appendTo(container);
		   $('<label />', { 'for': 'new'+set_log_type, text: input }).appendTo(container);
		 
		}

		function setInputSelection(input, startPos, endPos) {
			//a selection function, basically highlights between startpos and endposition
        input.focus();
        if (typeof input.selectionStart != "undefined") {
            input.selectionStart = startPos;
            input.selectionEnd = endPos;
        } else if (document.selection && document.selection.createRange) {
            
            input.select();
            var range = document.selection.createRange();
            range.collapse(true);
            range.moveEnd("character", endPos);
            range.moveStart("character", startPos);
            range.select();
        }
    }
  
			$("#query_form").submit(function(event){

				//basically does the same thing as query_submit button,
				//triggers when the user presses an enter instead of clicking submit 
				
				$("#overlay").show();	
				$("#output").hide();
				event.preventDefault();

			var query = $("#query").val();

			var set_log_type = $("#type_dropdown").val();
			var set_time_dropdown = $("#time_dropdown").val();
			var User_Id = '<?php echo $User_Id; ?>';
			var set_app_type = $("#app_dropdown").text();
			
			jQuery.ajaxSetup({async:false});
			if (set_time_dropdown == "8")
			{
				var time_drop_text = $("#time_dropdown").html();
				startTimeValue = time_drop_text.split(" ")[0].concat(" ").concat(time_drop_text.split(" ")[1]);
				endTimeValue = time_drop_text.split(" ")[3].concat(" ").concat(time_drop_text.split(" ")[4]);
				var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	$.post(post_variables,{query:query,set_log_type:set_log_type,set_time_dropdown:set_time_dropdown,startTimeValue:startTimeValue,endTimeValue:endTimeValue,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 	
		 $("#output").html(data);
		 });

			}
			else
			{
				var post_variables = window.location.protocol + '//' + window.location.host + '/logalytics/querybuilder.php';
		 	$.post(post_variables,{query:query,set_log_type:set_log_type,set_time_dropdown:set_time_dropdown,set_app_type:set_app_type,User_Id:User_Id},function(data){
		 	
		 $("#output").html(data);
		 });
			}
							    		
			$("#overlay").hide();
			$("#output").fadeIn(1000);		
		   jQuery.ajaxSetup({async:true});	
		});

		/*$t = $("#output"); // CHANGE it to the table's id you have

		$("#overlay").css({
		  opacity : 0.5,
		  top     : $t.offset().top,
		  width   : $t.outerWidth(),
		  height  : $t.outerHeight()
		});

		$("#img-load").css({
		  top  : ($t.height() / 2),
		  left : ($t.width() / 2)
		});*/

		</script>

		<br>

		<h1>APP LOGS</h1>
		
		<!--the loader image-->	
		<center>
			<div id="overlay">
  				<img src="http://promdressbycolor.com/images/loading.gif" 
    			id="img-load" align="center"/>
			</div>
    	</center>

		<span id="output">
		<!--the span where logs are outputted after query is finished-->
			
		</span>
		
		<!--Bootstrap modals-->

		<!--Aggregate tag sum checkbox modal -->
		<div class="modal fade" id="sumQueryModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  		<div class="modal-dialog">
    	<div class="modal-content">
      	<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"></h4>
      	</div>
      	<div class="modal-body">
        <h1>&nbsp;&nbsp;Sum Query Format</h1>
    	<div class="container-fluid">
     	<br>
     	/Primary_Key/ Sum(Field_name) <br>
     	* It calculates the sum of the field -> Field_name grouped with reference to the Primary_Key 
     	<br>* Primary_Key is needed at the very start of the query
    
   		</div>
      	</div>
      	<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    	</div>
  		</div>
		</div>
		</div>

		<!--Aggregate tag count checkbox modal -->
		<div class="modal fade" id="countQueryModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  		<div class="modal-dialog">
    	<div class="modal-content">
     	 <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"></h4>
      	</div>
      	<div class="modal-body">
        <h1>&nbsp;&nbsp;Count Query Format</h1>
    	<div class="container-fluid">
     	<br>
      	Count(Field_name)
      	<br>* It calculates the count of different values in Field_name for all the selected Documents in the Log
   		</div>
     	</div>
     	 <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    	</div>
  		</div>
		</div>
		</div>


		<!--Aggregate tag average checkbox modal -->
		<div class="modal fade" id="averageQueryModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  		<div class="modal-dialog">
    	<div class="modal-content">
      	<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"></h4>
      	</div>
      	<div class="modal-body">
        <h1>&nbsp;&nbsp;Average Query Format</h1>
    	<div class="container-fluid">
     	<br>
     	/Primary_Key/ Avg(Field_name) 
     	<br>* It calculates the average of the field -> Field_name grouped with reference to the Primary_Key 
     	<br>* Primary_Key is needed at the very start of the query 
   		</div>
      	</div>
      	<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    	</div>
  		</div>
		</div>
		</div>


		<!--custom time modal -->
		<div class="modal fade" id="customTimeModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  		<div class="modal-dialog">
    	<div class="modal-content">
      	<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel"></h4>
      	</div>
      	<div class="modal-body">
        <h1>&nbsp;&nbsp;Custom Time</h1>
    	<div class="container-fluid">
     	<br>
     	<form id="customTimeform" action = "#" method="POST" onsubmit="Enter();">
 
 		From:<input type="textbox" name="startTime" id = "startTime" placeholder = "2014-06-28 10:49:47">
 		To:<input type="textbox" name="endTime" id = "endTime" placeholder = "2014-06-28 10:49:47">
		<input type="button" class="btn btn-primary" value="Submit" id="customTimeButton" data-dismiss="modal">

		</form>
    
   		</div>
      	</div>
      	<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    	</div>
  		</div>
		</div>
		</div>

		<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

  </body>
  </html>