<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	session_start(); //we need to call PHP's session object to access it through CI
	class Home extends CI_Controller {
	 
		function __construct()
		{
		parent::__construct();
		$CI =& get_instance(); //Loads the codeigniter base instance (The object your controller is extended from. & for php4 compatibility
    	
       $CI->load->library('session');
       $this->load->helper('url');
		
		}

		function index()
		{
		 
		$data = $this->check_session();
		$this->load->model('dbmodel');
		 
		$data['title'] = "home";
    	$product=$this->input->post('product', TRUE);
    	// if their is a package enable/disable request then process it accordingly
    	if($product)
    	{
    		$record = $this->dbmodel->get_one('Admin_DB','Packages',array('Package_Id'=>$product));
    		if($record['Package_State']=='disabled')
    			$this->dbmodel->update('Admin_DB','Packages',array('Package_Id'=>$product),array('$set' => array('Package_State'=>'active')));
    		else
    			$this->dbmodel->update('Admin_DB','Packages',array('Package_Id'=>$product),array('$set' => array('Package_State'=>'disabled')));
    	}
   		 $data['package'] = $this->dbmodel->get('Admin_DB','Packages',array());
	     $this->load->helper('url');
	     $this->load->helper(array('form'));
	     $data['logout']=site_url().'/user/logout';
	     $data['add']= site_url().'/home/adminpac';
	     $data['base_url']=base_url();
		 $this->load->view('home_view', $data);
		 
		}
		
		function check_session() // checks if the user is logged in or not
		{	
			
			$this->load->model('dbmodel');
			if($this->dbmodel->session_get('logged_in'))
			{
			 $session_data = $this->dbmodel->session_get('logged_in');
			 $data['username'] = $session_data['username'];

			}
			else
			{
				
			 $data['message'] = 'You must log in first. Don\'t Jump ahead of yourself.';
			 redirect('user', 'refresh');
			} 
			return $data;
		}

public function adminpac() // function to add a new package for the users
{
	$data = $this->check_session();
	$this->load->model('dbmodel');
    $data['error']=FALSE;
    // if all the query parameters are valid add the package in the db
    if ( $this->input->post('inputPN', TRUE) && $this->input->post('inputNAA', TRUE) && $this->input->post('inputLRP', TRUE) && $this->input->post('inputMSA', TRUE) && $this->input->post('inputPC', TRUE))
    {
    	$document = array( "Package_Id" => $this->getGUID() ,"User_Id" => $this->dbmodel->session_get('Admin_Id'),"Package_Name" => $_GET['inputPN'] ,"Num_Apps_Allowed" => $_GET['inputNAA'],"Creation_Date" => date("d/m/Y"),"Update_Date" => date("d/m/Y"),"Log_Retention_Period" => $_GET['inputLRP'],"Max_Storage_Allowed" => $_GET['inputMSA'],"Package_State" => "active","Package_Cost" => $_GET['inputPC']);
    	$this->dbmodel->insert('Admin_DB','Packages',$document);
    	redirect('home', 'refresh');
    }
    else if($this->input->post('add_pac', TRUE)) $data['error']=TRUE;
    $data['package'] = $this->dbmodel->get('Admin_DB','Packages');
    $data['logout']=site_url().'/user/logout';
    $data['base_url']=base_url();
    $this->load->view('admin_add_pac',$data);
 }

		
public function getGUID()  // generates a unique GUID and returns it.
{
    if (function_exists('com_create_guid'))
    {
        return com_create_guid();
    }
    else
    {
        mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $hyphen = chr(45);// "-"
        $uuid = chr(123)// "{"
            .substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid,12, 4).$hyphen
            .substr($charid,16, 4).$hyphen
            .substr($charid,20,12)
            .chr(125);// "}"
        return $uuid;
    }
}
}
	 
?>
