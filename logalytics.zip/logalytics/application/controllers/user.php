<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	 
	class User extends CI_Controller {
	 
	 function __construct()
	 {
	   parent::__construct();
	   $CI =& get_instance(); //Loads the codeigniter base instance (The object your controller is extended from. & for php4 compatibility
       $CI->load->library('session');
	 }
	 
	 function index()

	 {
		$data['title'] = "home" ;
		$this->load->helper('url');
		$this->load->helper(array('form'));
		$this->load->view('login_view', $data);
	
	 }
	 
	
	
	  public function logout()
	 {
		 
		  $this->session->sess_destroy();
		  $this->index();
	 }
}	
		
	
	 
	?>
