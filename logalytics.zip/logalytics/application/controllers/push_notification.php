<?php
class Push_Notification extends CI_Controller
{
    function __construct()
     {
       parent::__construct();

      //loading models and helpers
      $this->load->helper('url');
      $this->load->helper('url_helper');
     }
    public function index() // function to activate a user account
    {
      $APPLICATION_ID = '2yyxLSuCVw1ym2J5Bq9hmR3ux7sH0U9ut13RSXcc';
      $REST_API_KEY = 'GLB7pl99tEh1hC2UdG7jkEyd42zAvqHddXqOoaIm';
      $MESSAGE = 'start sending';

        $url = 'https://api.parse.com/1/push';
        $data = array(
                'where' => '{}',
                'data' => array(
                "action" => 'sa.demo.PushLogs',                
            ),
        );
        $_data = json_encode($data);
        $headers = array(
            'X-Parse-Application-Id: ' . $APPLICATION_ID,
            'X-Parse-REST-API-Key: ' . $REST_API_KEY,
            'Content-Type: application/json',
            'Content-Length: ' . strlen($_data),
        );

        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $_data);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        redirect('home','refresh');
    }
}
?>