<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
     
    class Apps extends CI_Controller {
     
     function __construct()
     {
       parent::__construct();
       $this->load->config('logalytics');
        $this->load->helper('url');
        $this->load->model('dbmodel');
     }
     
     function index()
     {  
        $page = $_SERVER['PHP_SELF'];
        $sec = "30";
        header("Refresh: $sec; url=$page");
        if($this->dbmodel->session_get('email') == TRUE)
        {
        $temp = $this->dbmodel->get_one('Admin_DB','Users',array('Email_Id' => $this->dbmodel->session_get('email')));
        $User_Id=$temp['User_Id'];
        if(isset($temp['Current_Package']))
        {   
            $Package_Id=$temp['Current_Package'];
            $Application_Names=array();
            $Application_Events=array();
            $Application_Keys = array();
            $cursor=$this->dbmodel->get($User_Id,'Apps',array());
            
            foreach ($cursor as $row)
            {
                array_push($Application_Names,$row['App_Name']);
                $temp = $this->dbmodel->get_one($User_Id,'Apps',array('App_Name' => $row['App_Name']));
                //for count of events
                $db_name = $User_Id;
                $collection_name = $temp['App_Id']."_Logs";
                
               
                $count = $this->dbmodel->count($db_name,$collection_name);

                $key_array = array($row['Rest_Key'],$row['JS_Key'],$row['Client_Key'],$row['API_Key'],$row['Python_Key'],$row['App_Id']);
                $Application_Keys[$row['App_Name']] = $key_array;
               
                $Application_Events[$row['App_Name']] = $count;
             
            } 
        

        $data['Application_Names'] = $Application_Names;
        $data['Application_Events'] = $Application_Events;
        $data['Application_Keys'] = $Application_Keys;
        $data['user_id'] = $User_Id;
        $data['username']=$this->dbmodel->session_get('username');
        $data['logout']=site_url().'/auth/logout';        
        $data['base_url']=base_url();
        $data['title'] = "apps" ;
        $temp2=$this->dbmodel->get_one('Admin_DB','Packages',array('Package_Id' => $Package_Id));       
        $data['num_apps'] = $this->dbmodel->count($User_Id,'Apps');
        $Max_Apps_Allowed= $temp2['Num_Apps_Allowed'];
        $data["remaining_apps"] = $Max_Apps_Allowed - $data['num_apps'];
        
        if (isset($_POST['save_changes']))
            {       
                    if (in_array($_POST['AppName'],$Application_Names) && empty($_POST['AppName']))
                    {
                            redirect("apps","refresh");
                    }
                    else
                    {
                    
                            $Created_App_Count = $this->dbmodel->count($User_Id,'Apps');
                            
                            if ( $Created_App_Count < $Max_Apps_Allowed)
                            {
                            
                                $Create_App_Name = str_replace(" ","_7_7_",$_POST['AppName']);
                                
                                //$data['new_app'] = $Create_App_Name;
                                array_push($Application_Names,$Create_App_Name);
                                
                                 $App_Id =  sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                 // 32 bits for "time_low"
                                 mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

                                // 16 bits for "time_mid"
                                mt_rand( 0, 0xffff ),

                                // 16 bits for "time_hi_and_version",
                                // four most significant bits holds version number 4
                                mt_rand( 0, 0x0fff ) | 0x4000,

                                // 16 bits, 8 bits for "clk_seq_hi_res",
                                // 8 bits for "clk_seq_low",
                                // two most significant bits holds zero and one for variant DCE1.1
                                mt_rand( 0, 0x3fff ) | 0x8000,

                                // 48 bits for "node"
                                mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
                                ); 
                                //$data['new_app_appid'] = $App_Id;
                                $Rest_Key = sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                // 32 bits for "time_low"
                                mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

                                // 16 bits for "time_mid"
                                mt_rand( 0, 0xffff ),

                                // 16 bits for "time_hi_and_version",
                                // four most significant bits holds version number 4
                                mt_rand( 0, 0x0fff ) | 0x4000,

                                // 16 bits, 8 bits for "clk_seq_hi_res",
                                // 8 bits for "clk_seq_low",
                                // two most significant bits holds zero and one for variant DCE1.1
                                mt_rand( 0, 0x3fff ) | 0x8000,

                                // 48 bits for "node"
                                mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
                                );
                                //$data['new_app_rest_key'] = $Rest_Key;
                                $JS_Key = sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                    // 32 bits for "time_low"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_mid"
                                    mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_hi_and_version",
                                    // four most significant bits holds version number 4
                                    mt_rand( 0, 0x0fff ) | 0x4000,

                                    // 16 bits, 8 bits for "clk_seq_hi_res",
                                    // 8 bits for "clk_seq_low",
                                    // two most significant bits holds zero and one for variant DCE1.1
                                    mt_rand( 0, 0x3fff ) | 0x8000,

                                    // 48 bits for "node"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
                                );
                                //$data['new_app_js_key'] = $JS_Key;
                                $Client_Key = sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                    // 32 bits for "time_low"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_mid"
                                    mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_hi_and_version",
                                    // four most significant bits holds version number 4
                                    mt_rand( 0, 0x0fff ) | 0x4000,

                                    // 16 bits, 8 bits for "clk_seq_hi_res",
                                    // 8 bits for "clk_seq_low",
                                    // two most significant bits holds zero and one for variant DCE1.1
                                    mt_rand( 0, 0x3fff ) | 0x8000,

                                    // 48 bits for "node"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
                                );
                                //$data['new_app_client_key'] = $Client_Key;
                                $API_Key = sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                    // 32 bits for "time_low"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_mid"
                                    mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_hi_and_version",
                                    // four most significant bits holds version number 4
                                    mt_rand( 0, 0x0fff ) | 0x4000,

                                    // 16 bits, 8 bits for "clk_seq_hi_res",
                                    // 8 bits for "clk_seq_low",
                                    // two most significant bits holds zero and one for variant DCE1.1
                                    mt_rand( 0, 0x3fff ) | 0x8000,

                                    // 48 bits for "node"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
                                );
                                // $data['new_app_api_key'] = $API_Key;
                                $Python_Key = sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                    // 32 bits for "time_low"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_mid"
                                    mt_rand( 0, 0xffff ),

                                    // 16 bits for "time_hi_and_version",
                                    // four most significant bits holds version number 4
                                    mt_rand( 0, 0x0fff ) | 0x4000,

                                    // 16 bits, 8 bits for "clk_seq_hi_res",
                                    // 8 bits for "clk_seq_low",
                                    // two most significant bits holds zero and one for variant DCE1.1
                                    mt_rand( 0, 0x3fff ) | 0x8000,

                                    // 48 bits for "node"
                                    mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
                                );
                                 //$data['new_app_python_key'] = $Python_Key;
                                $Is_Active = "true";
                                $this->dbmodel->create_collection($User_Id,$App_Id.'_Logs');
                                $this->dbmodel->create_collection($User_Id,$App_Id.'_Tags');
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags_Json"=>array()));
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags_Xml"=>array()));
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags_Access_Log"=>array()));
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags_Error_Log"=>array()));
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags_IIS_Log_File_Format"=>array()));
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags_W3C_Extended_Log_Format"=>array()));
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags_NCSA_Common_Log_Format"=>array()));
                                $this->dbmodel->insert($User_Id,$App_Id.'_Tags',array("tags"=>array()));
                                $this->dbmodel->create_collection($User_Id,$App_Id.'_Files');
                                $Create_Date = date(DATE_ATOM);

                                $Update_Date = date(DATE_ATOM);
                               
                                $Is_Deleted = "false";
                                
                                $App_Name = $Create_App_Name;
                                //before insert lets first create a subfolder for this app in the s3 bucket
                                if (!class_exists('S3'))require_once('S3.php');
                                                    
                                $s3_Key=$this->config->item('S3');
                                 
                                if (!defined('awsAccessKey')) define('awsAccessKey', $s3_Key['awsAccessKey']);
                                if (!defined('awsSecretKey')) define('awsSecretKey', $s3_Key['awsSecretKey']);
                                
                                $Bucket_Name = "bucket_".$this->dbmodel->session_get('userid');
                                
                                $s3 = new S3(awsAccessKey, awsSecretKey);                   

                                $Sub_Path = $App_Id."/dummy.txt";
                                                    
                                /* function to upload dummy file to app sufolder on S3 user's bucket */
                                $s3->putObjectFile("dummy.txt", $Bucket_Name, $Sub_Path, S3::ACL_PUBLIC_READ);

                                
                                $cursor=$this->dbmodel->insert($User_Id,'Apps',array("App_Id"=>$App_Id,"App_Name"=>$App_Name,"Create_Date"=>$Create_Date,"Update_Date"=>$Update_Date,"Is_Active"=>$Is_Active,"Is_Deleted"=>$Is_Deleted,"Rest_Key"=>$Rest_Key,"JS_Key"=>$JS_Key,"Client_Key"=>$Client_Key,"API_Key"=>$API_Key,"Python_Key"=>$Python_Key));

                                $config = Array(
                                                'protocol' => 'smtp',
                                                'smtp_host' => 'smtp.sendgrid.net',
                                                'smtp_port' => '587',
                                                'smtp_user' => 'it@semusi.com',
                                                'smtp_pass' => 'pass@word1.',
                                                'mailtype' => 'html',
                                                'charset' => 'iso-8859-1',
                                                'wordwrap' => TRUE
                                                );

                                $this->load->library('email', $config);
                                $this->email->set_newline("\r\n");
                                $this->email->from('it@semusi.com');
                                $this->email->to($this->dbmodel->session_get('email'));
                                $this->email->subject('New App Created:');
                                $this->email->message('Hi'.$this->dbmodel->session_get('name').'<br> You have created a new app with : <br>'."App_Id: ".$App_Id."<br>App_Name: ".$App_Name."<br>Rest_Key: ".$Rest_Key."<br>JS_Key: ".$JS_Key."<br>Client_Key: ".$Client_Key."<br>API_Key: ".$API_Key."<br>Python_Key: ".$Python_Key);
                                if(!$this->email->send()) show_error($this->email->print_debugger());

                                $data['num_apps'] = $cursor=$this->dbmodel->count($User_Id,'Apps');

                                $data['Application_Names'] = $Application_Names;

                                $data['title'] = "apps" ;

                                $this->load->helper('url');

                                $data['New_App_Id'] = $App_Id;
                                $data['New_App_Name'] = $App_Name;
                                $data['New_API_Key'] = $API_Key;
                                $data['New_Client_Key'] = $Client_Key;
                                $data['New_Rest_Key'] = $Rest_Key;
                                $data['New_Python_Key'] = $Python_Key;
                                $data['New_JS_Key'] = $JS_Key;
                                $this->load->view('appmessage', $data);


                            }

                        else{
                               $this->load->view('sorrymessage', $data);                      
                            }
                    }
            }
            elseif (isset($_POST['view_keys']))
                    {
                        $data['App_Name'] = $_POST['App_Name'];
                        $data['App_Id'] = $_POST['App_Id'];
                        $data['App_Key'] = $_POST['App_Key'];
                        $data['Client_Key'] = $_POST['Client_Key'];
                        $data['Rest_Key'] = $_POST['Rest_Key'];
                        $data['Python_Key'] = $_POST['Python_Key'];
                        $data['JS_Key'] = $_POST['JS_Key'];
                        $data['Application_Names'] = $_POST['Application_Names'];
                        $this->load->view('appkeys', $data);
                        
                    }
            elseif (isset($_POST['data_browser']))
                    {
                        $sess_array = $this->session->all_userdata();
                        $sess_array["current_app"] = $_POST['App_Name'];
                        $this->session->set_userdata($sess_array);
                        redirect('querybuilder','refresh');
                        
                    }
            else
            {   
                $bool = 0;
                
                
                foreach($Application_Names as $App)
                {
                    $data['App_Name'] = $App;
                    



                    if (isset($_POST[$App.'_Data_Viewer']))
                    {   
                        $sess_array = $this->session->all_userdata();
                        $sess_array["current_app"] = $App;
                        $this->session->set_userdata($sess_array);
                        
                        redirect('querybuilder','refresh');
                    }
                    
                    elseif (isset($_POST['delete_confirmation_'.$App]))
                    {   
                        
                   
                        $user_id = $this->dbmodel->session_get('userid');
                        $app_name = $App;
                                        
                        $this->dbmodel->remove_app($user_id,$app_name);

                        $temp = $this->dbmodel->get_one($user_id,'Apps',array('App_Name' => $app_name));

                        //$app_id = "9f9c8a9f-b571-4302-bd40-b7a8748ae442";
                        $app_id = $temp['App_Id'];
                        $bucket = "bucket_".$user_id;
                        $s3_Key=$this->config->item('S3');
                        if (!class_exists('S3'))
                        require_once('S3.php');
                        //AWS access info
                        if (!defined('awsAccessKey'))
                         define('awsAccessKey', $s3_Key['awsAccessKey']);
                        if (!defined('awsSecretKey'))
                         define('awsSecretKey', $s3_Key['awsSecretKey']);
                        //instantiate the class
                        $s3 = new S3(awsAccessKey, awsSecretKey);
    
                        $bucket_contents = $s3->getBucket($bucket);
        
                        if($bucket_contents)
                        {
                            foreach ($bucket_contents as $file)
                                {
                                    //print_r($file);echo "<br><br><br><br><br>";
                                    $reg_match = "/".$app_id."/";
                                    if (preg_match($reg_match,$file['name']))
                                         {
                                                $s3->deleteObject($bucket, $file['name']);
                                                
                                        }
                                }
                        }
                        
                        redirect('apps','refresh');
                        //$bool = 1;
                        
                    }
                   
                }

                if(!$bool)
                {
                $this->load->view('apps', $data);
                }
                 
            }
    
        }
        else redirect('products','refresh');
        }
        else redirect('auth','refresh');
        
    }
    function downloads()
    {
        $Email_Id=$this->dbmodel->session_get('email');
        if($Email_Id == TRUE)
        {
            $user_nm=$this->dbmodel->session_get('username');
            if(isset($user_nm))
            $data['username']=$user_nm; 
            else  $data['username']=$Email_Id;
            $data['logout']=site_url().'/auth/logout';
            $this->load->view('downloads', $data);
        }    
    }
    }
    ?>