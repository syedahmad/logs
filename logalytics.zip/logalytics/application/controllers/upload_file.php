<?php
class Upload_File extends CI_Controller
{
    function __construct()
     {
       parent::__construct();            
        $this->load->helper('url');  
        $this->load->model('dbmodel');
        $this->load->config('logalytics');           
     }
    public function index()
    {

      $User_Id = $_POST['user'];
      $App_Id = $_POST['app'];
      $Bucket_Id = "bucket_".$User_Id;
      //for finding the current package owned by the concerned user
      $User_Document = $this->dbmodel->get_one('Admin_DB','Users',array('User_Id' => $User_Id));
      if($User_Document['State'] == 'Active')
      {
        $Package_Id = $User_Document['Current_Package'];
        //For Finding the max allowed upload limit for the package from the database
        $Package_Document = $this->dbmodel->get_one('Admin_DB','Packages',array('Package_Id' => $Package_Id));     
        //1GB = 1073741824 bytes
        $Upload_Limit = intval($Package_Document['Max_Storage_Allowed']) * 1073741824;
        
        //Establishing a connection with s3
        $s3_Key=$this->config->item('S3');
        if (!class_exists('S3'))require_once('S3.php');
        //AWS access info
        if (!defined('awsAccessKey')) define('awsAccessKey', $s3_Key['awsAccessKey']);
        if (!defined('awsSecretKey')) define('awsSecretKey', $s3_Key['awsSecretKey']);

        //instantiate the class
        $s3 = new S3(awsAccessKey, awsSecretKey);

        $allowedExts = array("zip");
        $temp = explode(".", $_FILES["file"]["name"]);
        $extension = end($temp);
        $fileName = $_FILES['file']['name'];
        $fileTempName = $_FILES['file']['tmp_name'];
        $fileSize = $_FILES["file"]["size"];     
        $Sub_Path = $App_Id."/".$fileName;
        $uploaded_files=array();

        //autorefresh
        $page = $_SERVER['PHP_SELF'];
        $sec = "5";
        header("Refresh: $sec; url=$page");

        $bucket_contents = $s3->getBucket($Bucket_Id);

        if ($bucket_contents)      //if the user owns a bucket and has an app created in it
        {
          
          $Bucket_Size = 0;

          foreach ($bucket_contents as $file)
          {
       
              $fname = $file['name'];
              $furl = "http://".$Bucket_Id."s3.amazonaws.com/".$fname;
              $Bucket_Size += $file['size'];
              array_push($uploaded_files,$fname);
          }
          //move the file to the bucket
          $Upload_Allowed = (($Bucket_Size + $fileSize) <= $Upload_Limit);
          
      
          if($Upload_Allowed)
          {
            if (!(in_array($App_Id.'/'.$fileName,$uploaded_files)))
            {
              if ($s3->putObjectFile($fileTempName, $Bucket_Id, $Sub_Path, S3::ACL_PUBLIC_READ)) 
              {
                // if a file is uploaded by the user the pass the info about the file to the parsers via rabbitmq and mark the file as unprocessed in the db.
                  require_once 'vendor/autoload.php';

                  $connection = new PhpAmqpLib\Connection\AMQPConnection('localhost', 5672, 'guest', 'guest');
                  $channel = $connection->channel();

                  $channel->queue_declare('hello', false, false, false, false);

                  $msg = new PhpAmqpLib\Message\AMQPMessage(json_encode(array("App_Id" => $App_Id,"User_Id" => $User_Id,"filename" => 'https://s3.amazonaws.com/'.$Bucket_Id.'/'.$App_Id.'/'.$fileName)));
                  $channel->basic_publish($msg, '', 'hello');
                  $channel->close();
                  $connection->close();
                  $document=array('Name'=>'https://s3.amazonaws.com/'.$Bucket_Id.'/'.$App_Id.'/'.$fileName,'Type' =>$_FILES["file"]["type"],'Size' => $_FILES["file"]["size"] , 'Status'=>'unprocessed' , 'Time_Of_Arrival' => date('Y-m-d H:i:s'));
                  $this->dbmodel->insert($User_Id,$App_Id.'_Files',$document);
              }
              else
              {
                  // "Something went wrong while uploading your file... sorry.";
              }
            }
            else
            {
                //do nothing
            }
          }
        }
        else
        {
          // "You do not have a bucket ... sorry";
        }
      }
    }
}
?>
