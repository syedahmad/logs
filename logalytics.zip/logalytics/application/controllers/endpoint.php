<?php 
require('application/libraries/REST_Controller.php');
class Endpoint extends REST_Controller
{
    public function index_get()
    {
    	$data = array('returned: '. $this->get('content'));
        $this->response($data);

    }	
    public function index_post()
    {
    
    	$User_Id=$this->post('user');
    	$Api_Key=$this->post('X-API-KEY');
    	$App_Id=$this->post('app');
    	$this->load->model('dbmodel');
    	$app=$this->dbmodel->get_one($User_Id,'Apps',array('App_Id' => $App_Id));
    	if ($Api_Key == $app['Rest_Key'])
    	{
    		$jsons= json_decode($this->post('content'),true);
    		if ($jsons) 
            {
                $jsons['Time_Of_Arrival']=date('Y-m-d H:i:s');
                $jsons['Log_Type']='Json';
                $this->dbmodel->insert($User_Id , $App_Id.'_Logs' , $jsons);
            }    
    		else 
                $this->dbmodel->insert($User_Id , $App_Id.'_Logs' , array('endpoint_log' => $jsons,'Time_Of_Arrival'=>date('Y-m-d H:i:s')));
    	}
    }	
}
?>
