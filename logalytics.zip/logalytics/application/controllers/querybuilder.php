<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
     
    class Querybuilder extends CI_Controller {
     
     function __construct()
     {
       parent::__construct();
       $this->load->config('logalytics');
     }
     
     function index()
     { 

        $this->load->helper('url');
        $this->load->model('dbmodel');
        $temp = $this->dbmodel->get_one('Admin_DB','Users',array('Email_Id' => $this->dbmodel->session_get('email')));
        $User_Id=$temp['User_Id'];
        $data['User_Id'] = $User_Id;
        $data['App_Name'] = $this->session->userdata("current_app");
        $temp = $this->dbmodel->get_one($User_Id,'Apps',array("App_Name"=>$data['App_Name']));
        $App_Id = $temp['App_Id'];
        
        $data['App_Id'] = $App_Id;
        


        if($this->dbmodel->session_get('email') == TRUE)
        {
            $this->load->view('querybuilder',$data);
        }
        
        else 
            {
                redirect('auth','refresh');
            }

    }
}

    ?>