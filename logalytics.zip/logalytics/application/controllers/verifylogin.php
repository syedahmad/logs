<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	 
	class Verifylogin extends CI_Controller {
	 
	 function __construct()
	 {

	   parent::__construct();
	   $this->load->model('user_model');
	   $this->load->helper('url');
	   $CI =& get_instance(); 
       $CI->load->library('session');
	 
	 }
	 
	 function index() // gets the user credentials from the form and verifies it
	 { 

		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_check_database');
		$valid = $this->form_validation->run();
	
	   if(!$valid)
	   {
	  
	   $data['title'] = "home" ;
	   $this->load->helper('url');
	   $this->load->view('login_view', $data);
	   }
	   else
	   {
	     
	     redirect('home', 'refresh');
	   }
	 }
	 
	 function check_database($password)  //checks if the user credentials exhists in the db or not.
	 {
	  
	   $username = $this->input->post('username');
	   $result = $this->user_model->login($username, $password);
	
	   if($result)
	   {

	    	$sess_array = array();
	    	$sess_array = array(
	         'id' => $result["Admin_Id"],
	         'username' => $result["Admin_Login"]
	       		);
	     
	    	$this->session->set_userdata('logged_in', $sess_array);
	    	return TRUE;
	   }
	   else
	   {
	    	$this->form_validation->set_message('check_database', 'Invalid username or password');
	    	return false;
	   }
	 }
	}
	?>
