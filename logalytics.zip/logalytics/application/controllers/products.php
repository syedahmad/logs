<?php
class Products extends CI_Controller
{
    public function index()
	{

        //loading models and helpers.
        $this->load->helper('url');
        $this->load->model('dbmodel');
        // pass urls required by the view login via a variable data
    	$data['fb_url']=site_url()."/auth/session/facebook";
        $data['google_url']=site_url()."/auth/session/google";
        $data['git_url']=site_url()."/auth/session/github";
        $data['product_url']=site_url()."/products";
        $data['base_url']=base_url();
        $query=$this->input->post('product', TRUE);

        if( !$query ) $data['product']='';
        else  $data['product']=$query;

        $data['logged']=$this->dbmodel->session_get('email');
        $data['package'] = $this->dbmodel->get('Admin_DB','Packages', array( 'Package_State' => 'active' ) );

    	if($data['logged'] == TRUE)
        {                      
            $data['act_pac']='';     
            $query1=$this->dbmodel->get_one('Admin_DB','Users',array('Email_Id'=>$this->dbmodel->session_get('email')));
            // get the current package of a user
            foreach ($query1 as $key => $value)
            {
                if ($key == 'Current_Package')$data['act_pac']=$query1['Current_Package'];
            }
            // process the new package selection request
            if($query)
            {
                    $data['act_pac']=$query;
                    $this->dbmodel->update('Admin_DB','Users',array( "Email_Id"=>$query1['Email_Id']), array('$set'=>array('Current_Package' => $query,'Pac_Start_Date' => date('Y-m-d H:i:s'))));
                    $cur_pac=$this->dbmodel->get_one('Admin_DB','Packages', array( 'Package_Id' => $query ));
                    // send user an email of the info about the selected package
                    $config = Array(
                                    'protocol' => 'smtp',
                                    'smtp_host' => 'smtp.sendgrid.net',
                                    'smtp_port' => '587',
                                    'smtp_user' => 'it@semusi.com',
                                    'smtp_pass' => 'pass@word1.',
                                    'mailtype' => 'html',
                                    'charset' => 'iso-8859-1',
                                    'wordwrap' => TRUE
                                    );

                    $this->load->library('email', $config);
                    $this->email->set_newline("\r\n");
                    $this->email->from('it@semusi.com');
                    $this->email->to($query1['Email_Id']);
                    $this->email->subject('New Package Selected:');
                    $this->email->message('Hi'.$this->dbmodel->session_get('name').'<br> You have subscribed to a new package with Package Id: '.$query.' and Package Name: '.$cur_pac['Package_Name']);
                    if(!$this->email->send()) show_error($this->email->print_debugger());
                    redirect('apps','refresh');                
            }
            $user_nm=$this->dbmodel->session_get('username');
            if(isset($user_nm))
                $data['username']=$user_nm; 
            else  
                $data['username']=$query1['Email_Id'];
            $data['logout']=site_url().'/auth/logout';
            $data['app_link']=site_url().'/apps';
            $this->load->view('log_prod',$data);       
        }    
        else 
        {        
            $this->load->view('product',$data);
        }
	
	}
}
?>
