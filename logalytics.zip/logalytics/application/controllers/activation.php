<?php
class Activation extends CI_Controller
{
    function __construct()
     {
       parent::__construct();

      //loading models and helpers
      $this->load->helper('url');
      $this->load->helper('url_helper');
      $this->load->model('dbmodel');
     }
    public function index() // function to activate a user account
    {
      
      $User_Id=$this->input->get('uid');
      $Act_Code=$this->input->get('actcode');
      $user=$this->dbmodel->get_one('Admin_DB','Users' , array( 'User_Id' => $User_Id));
      // if valid activation link then update the user state as active
      if ($user['State'] == 'Inactive' && $user['Activation_Code'] == $Act_Code)
      {
       $this->dbmodel->update('Admin_DB','Users',array('User_Id' => $User_Id),array('$set'=>array('State' =>'Active','Verified' => "True")));
       echo "Your account is successfully activated";
      }
      elseif ($user['State'] == 'Active') {
        echo "Your account is already activated";
      }
    }
}
?>