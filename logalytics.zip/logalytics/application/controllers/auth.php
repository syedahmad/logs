<?php
class Auth extends CI_Controller
{
    function __construct()
     {
       parent::__construct();

       //loading models and helpers and libraries and config
       $this->load->helper('url');
       $CI =& get_instance(); 
       $CI->load->library('session');
       $this->load->helper('url_helper');
       $this->load->config('logalytics');
       $this->load->model('dbmodel');
     }
    public function index($git_error=False)
    {
    
        // pass urls required by the view login via a variable data
      	$data['fb_url']=site_url()."/auth/session/facebook";
      	$data['google_url']=site_url()."/auth/session/google";
      	$data['git_url']=site_url()."/auth/session/github";
        $data['product_url']=site_url()."/products";
        $data['base_url']=base_url();
        $data['git_error']= $git_error;
        // if the user is logged in the redirect the user to product view
        if ($this->dbmodel->session_get('email'))redirect('products','refresh');
      	$this->load->view('login',$data);
    }
    public function session($provider)
    {
                
        $this->load->spark('oauth2/0.3.1');
        // retrieve secret and id keys for git,fb and google
        $fb_config=$this->config->item('fb');
        $google_config=$this->config->item('google');
        $git_config=$this->config->item('git');
	//facebook
         if($provider == 'facebook') {
		      $provider	= $this->oauth2->provider($provider, array(
			     'id' =>  $fb_config['id'],
			     'secret' => $fb_config['secret'],
			));			
		}
	//google
		else if($provider == 'google'){
			$provider 	= $this->oauth2->provider($provider, array(
				'id' => $google_config['id'],
				'secret' => $google_config['secret'],
			)); 			
		}
	//github
		else if($provider == 'github'){

			$provider 	= $this->oauth2->provider($provider, array(
				'id' => $git_config['id'] ,
				'secret' => $git_config['secret'] ,
        'scope' => 'user:email',
			));
		}    

        if ( ! $this->input->get('code'))
        {
            // By sending no options it'll come back here
            $provider->authorize();
        }
        else
        {
            
            try
            {	

              $token = $provider->access($_GET['code']);
              $user = $provider->get_user_info($token);
              if (isset($user['email']))
              {
				        $record = $this->dbmodel->get_one('Admin_DB','Users' , array( 'Email_Id' => $user["email"] ) );
                // if a new user comes in add his credentials in the db and make his S3 bucket and send him a welcome mail as well as set his session and force him to select a new package.
				        if($record == NULL){
                     $document = array( "User_Info" => serialize($user) ,"Email_Id" => $user["email"],'User_Id' => $this->getGUID(),'Activation_Code' => $this->getGUID(),'Act_Add_Date'=> date('Y-m-d H:i:s'),'State' => 'Active','Verified' => "False");
                     $link=site_url()."/activation?uid=".$document['User_Id']."?actcode=".$document['Activation_Code'];
                     if (!class_exists('S3'))require_once('S3.php');
                    
                    //AWS access info
                     $s3_Key=$this->config->item('S3');
                     
                    if (!defined('awsAccessKey')) define('awsAccessKey', $s3_Key['awsAccessKey']);
                    if (!defined('awsSecretKey')) define('awsSecretKey', $s3_Key['awsSecretKey']);
 
                    //instantiate the class
                    $Bucket_Name = "bucket_".$document['User_Id'];
                    
                    $s3 = new S3(awsAccessKey, awsSecretKey);
                    $s3->putBucket($Bucket_Name, S3::ACL_PUBLIC_READ);
                    
                    // new user comes in add his credentials in the db and create a Apps collection for his apps keys
                    $this->dbmodel->insert('Admin_DB','Users',$document);
                    $this->dbmodel->create_collection($document['User_Id'],'Apps');
                    //set his session
                    $newdata = array(
                   'username'  => $user["name"],
                   'email'     => $user["email"],
                   'userid'    => $document['User_Id']
                    );
                    $this->dbmodel->session_add($newdata);
                    // send the user a welcome mail 
                    $config = Array(
                                    'protocol' => 'smtp',
                                    'smtp_host' => 'smtp.sendgrid.net',
                                    'smtp_port' => '587',
                                    'smtp_user' => 'it@semusi.com',
                                    'smtp_pass' => 'pass@word1.',
                                    'mailtype' => 'html',
                                    'charset' => 'iso-8859-1',
                                    'wordwrap' => TRUE
                                    );

                    $this->load->library('email', $config);
                    $this->email->set_newline("\r\n");
                    $this->email->from('it@semusi.com');
                    $this->email->to($user['email']);
                    $this->email->subject('Welcome');
                    $this->email->message('Hi '.$user["name"].' Welcome to logalytics <br>Your User_Id is: '.$document['User_Id'].' <br> Click on the activation before 5 days to activate the account:'.$link);
                    if(!$this->email->send()) show_error($this->email->print_debugger());
                    redirect('products','refresh');
                }
                else
                {

                  // check if user has activated or not within 5 days after registration
                   $today_dt = new DateTime("");
                   $expire_dt = new DateTime($record['Act_Add_Date']);
                   $expire_dt->modify("+5 day");
                   if (($expire_dt < $today_dt) && $record['Verified']=="False") {
                   $this->dbmodel->update('Admin_DB','Users',array( 'Email_Id' => $user["email"] ),array('$set'=>array('State' =>'Inactive')));
                  }
                  // set the user session
                  $newdata = array(
                    'username'  => $user["name"],
                    'email'     => $user["email"],
                    'userid'    => $record['User_Id']
                    );
                  $this->dbmodel->session_add($newdata);
                  // finds the user has selected a package or not, if not then force him to select one
                  $act_pac= NULL;
                  foreach ($record as $key => $value)
                  {
                    if ($key == 'Current_Package')$act_pac=$record['Current_Package'];
                  }
                  if (!$act_pac) redirect('products','refresh');
                  redirect('apps','refresh');
                }
              }
              else {
                    $this->index(TRUE);
              }
            }

            catch (OAuth2_Exception $e)
            {
                show_error('That didnt work: '.$e);
            }

        }
    }

    public function logout()  // sets the user session to null
    {

        $newdata = array(
                   'username'  => '',
                   'email'     => '',
                    );
        if ($this->dbmodel->session_get('email') == TRUE)
        {
            $this->dbmodel->session_unset($newdata);
        }
        redirect(site_url().'/auth');
    }
 public function getGUID() // generates a unique GUID and returns it.
 {

    if (function_exists('com_create_guid'))
    {
        return com_create_guid();
    }
    else
    {
        mt_srand((double)microtime()*10000);//optional for php 4.2.0 and up.
        $charid = strtoupper(md5(uniqid(rand(), true)));
        $hyphen = chr(45);// "-"
        $uuid = // "{"
            substr($charid, 0, 8).$hyphen
            .substr($charid, 8, 4).$hyphen
            .substr($charid,12, 4).$hyphen
            .substr($charid,16, 4).$hyphen
            .substr($charid,20,12)
            ;// "}"
        return $uuid;
    }
  }
}
?>
