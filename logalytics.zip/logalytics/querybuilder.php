<?php



function Normal_QueryBuilder($query1,$app_type,$User_Id){
  
  $App_Name = substr($app_type,0,-3);
  $App_Name = str_replace(" ","_7_7_",$App_Name);
  $m = new MongoClient();
      
  $User_DB = $m->$User_Id;
 
   
  $App_Collection = $User_DB->Apps;
  $cursor = $App_Collection->find(array("App_Name" => $App_Name));
 
  foreach ($cursor as $row)
  {
    $App_Id = $row['App_Id'];
  }
  
 
  $Log_Collection_Name = $App_Id."_Logs";
  $Log_Collection = $User_DB->$Log_Collection_Name;
   
  $cursor = $Log_Collection->find();
  //$date = new MongoDate();  
  foreach ($cursor as $row)
  {
    //$date = new MongoDate(strtotime($row['Time_Of_Arrival']));  //need to change this
    if (is_string($row['Time_Of_Arrival']))
    {
      $date = new MongoDate(strtotime($row['Time_Of_Arrival']));
      $newdata = array('$set' => array("Time_Of_Arrival" =>  $date));
    $Log_Collection->update(array("_id" => $row['_id']), $newdata);
    }
    
  }


  $Selected_Tags = array();
  $Select_Array = array();

  $string = " ";
  $i =0;
  $query = $query1;

  if($query && $query!= -1)
  {
     
    $Log_Type = $_POST['set_log_type'];

      if ($Log_Type == 1)
      {
        
        $Log_Type = "Json";

      }
      if ($Log_Type == 2)
      {
       
        $Log_Type = "Xml";
        
      }
      if ($Log_Type == 3)
      {
        
        $Log_Type = "Access_Log";
        
      }
      if ($Log_Type == 4)
      {
        
        $Log_Type = "Error_Log";

      }
      if ($Log_Type == 5)
      {
        
        $Log_Type = "IIS_Log_File_Format";

      }
      if ($Log_Type == 6)
      {
       
        $Log_Type = "W3C_Extended_Log_Format";

      }
      if ($Log_Type == 7)
      {
        
        $Log_Type = "NCSA_Common_Log_Format";

      }

      $time_dropdown = $_POST['set_time_dropdown'];

        $f[1] = 0;
        $f[2] = " ";

        if ($time_dropdown == 1)
        {
          
          $f[1] = 15;
          $f[2] = "minutes";
         
        }

        if ($time_dropdown == 2)
        {

          $f[1] = 30;
          $f[2] = "minutes";

        }

        if ($time_dropdown == 3)
        {

          $f[1] = 60;
          $f[2] = "minutes";

        }
        if ($time_dropdown == 4)
        {
          $f[1] = 24;
          $f[2] = "hours";
        }
        if ($time_dropdown == 5)
        {
          $f[1] = 7;
          $f[2] = "days";
        }
        if ($time_dropdown == 6)
        {
          $f[1] = 30;
          $f[2] = "days";
        }
        if ($time_dropdown == 8)
        {
          $f[1] = $_POST['startTimeValue'];
          $f[2] = $_POST['endTimeValue'];
        }
        

        $date = new MongoDate();    
                 
        $diff =0.0 ;
        if ($f[2] =="days")
        {
               
        $diff = 24*60*60;

        }
        if ($f[2] == "hours")
        {
          
          $diff = 60*60;

        }
        if ($f[2] == "minutes")
        {
           $diff = 60;
        }
        if ($f[2] == "seconds")
        {
          $diff = 1;
        }
                 
        $diff1 =  ($date ->sec)-($f[1]*$diff);
                 
        $end = new MongoDate($diff1);
                 
      
      $Query_Tags = array();
      $Tag_Values = array();
      $Operators = array();
      $Equals_Array = array();
      $Not_Equals_Tags = array();
      $RegEx_Array = array();
      $RegEx_Value = array();



      $i = 1;
  
      $query = ' '.$query;

      //Put a space in the beginning of the string even if there is not one for consistency

      $j = 0;
      
      preg_match_all('/".*?"|\'.*?\'/', $query, $matches);

      $Number_Of_Tags = sizeof($matches[0]);

      while ($j < $Number_Of_Tags)
      {

        $Tag_Values[$j] = substr($matches[0][$j],1,-1);
        $Tag_Values[$j] = str_replace( '/', '\/', $Tag_Values[$j] );
        $j++;

      }
      //First check if there are spaces between '' and remove them or put a rare character

      
      
      
      $query = preg_replace_callback(
          '~"(.+?)"~',
          create_function(
              '$match',
              'return str_replace(" ", "$!$!", $match[0]);'
          ),
          $query
      );
      
      $pieces = array();
      
      $pieces = preg_split("/[\s]+/", $query);

      
      if (strtolower($pieces[1]) == "select")
        
      {
        $select = 1;
        if ($pieces[2]!= "*")
        {
          
          $array = preg_split("/,/", $pieces[2]);
  
          foreach ($array as $tag)
          { 
            
            $Select_Array[$tag] = 1;

          }
          $Select_Array["_id"] = 0;
        }
        
        else
        {
          $Select_Array["_id"] = 0;
          $Select_Array["Log_Type"] = 0;
          $Select_Array["Line"] = 0;
          $Select_Array['Time_Of_Arrival'] = 0;
        }
        
        if(sizeof($pieces) == 3)
        {
        $query = str_replace(array($pieces[1],$pieces[2]), array("",""), $query);
        }
        if(sizeof($pieces) > 3)
        { 
         
          $query = str_replace(array($pieces[1],$pieces[3]), array("",""), $query);
          $replace_regex = "/".$pieces[2]."/";
          if ($pieces[2] = "*")
            { 
              $replace_regex = "/"."\*"."/";
            }
          
          $query = preg_replace($replace_regex, "", $query, 1);
          
        }   
       
        
      }

      else
        {
          $select = 0;

          $Select_Array["_id"] = 0;
          $Select_Array["Log_Type"] = 0;
          $Select_Array["Line"] = 0;
          $Select_Array['Time_Of_Arrival'] = 0;
        }   

      $query = " ".$query;

      $j = 0;
      $m = 0;

      $pieces = preg_split("/[\s]+/", $query);
      
      $array_replace = array();
      $replace_with = array();
      $z=0;
      while ($z < sizeof($pieces))
      {
        if(preg_match("(\".+?\")",$pieces[$z]))
        {

          
          array_push($array_replace,$pieces[$z]);
          array_push($replace_with,"");

        }
        
        
        $z = $z + 1;
      }
     
      $query = str_replace($array_replace, $replace_with, $query);
      
      if (strlen(trim($query)) == 0 && !($select))
      {

        $pieces[1] = str_replace( '/', '\/', $pieces[1] );
       
        $search_string = preg_replace_callback(
          '~"(.+?)"~',
          create_function(
              '$match',
              'return str_replace("$!$!", " ", $match[0]);'
          ),
          $pieces[1]
      );
      
      }
      else
      { 
        if (!($select))
         {
          $search_string  = "Tarsh5216351%$%";
        }
        
      }
      $pieces = preg_split("/[\s]+/", $query);
     

      
      $i = 1;
     
      while ($i < sizeof($pieces)-2)
      {
        
        $Query_Tags[$j] = $pieces[$i];
        $Operators[$j] =strtolower($pieces[$i+1]);
        
        
        $i = $i + 2;
        $j = $j + 1;
      }
     
      $Query_Array = array();
      $Part_Array = array();
      $order_by = 0;
  
      while ($m < sizeof($Query_Tags))
      { 
        
        if ($Operators[$m] == "=")
        {
            
         $Part_Array[$m] = array($Query_Tags[$m]=>$Tag_Values[$m]);
          
         array_push($Equals_Array,$Tag_Values[$m]);
        
        
        }

        if ($Operators[$m] == "contains")
        {

        $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/".$Tag_Values[$m]."/"));
        
        $RegEx_Array[$Query_Tags[$m]] = new MongoRegex("/".$Tag_Values[$m]."/");

        }

        if ($Operators[$m] == "not_contains")
        {
            
            $Tag_Values[$m] = preg_replace_callback(
              '~%(.+?)%~',
              create_function(
                  '$match',
                  'return str_replace("%", "", $match[0]);'
              ),
              $Tag_Values[$m]  
            );

            $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^((?!".$Tag_Values[$m].").)*$/"));

        }

        if ($Operators[$m] == "begins_with")
        {

        $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^".$Tag_Values[$m]."/"));
        $RegEx_Array[$Query_Tags[$m]] = new MongoRegex("/^".$Tag_Values[$m]."/");

        }
        if ($Operators[$m] == "not_begins_with")

        {
        
            $Tag_Values[$m] = preg_replace_callback(
              '~(.+?)%~',
              create_function(
                  '$match',
                  'return str_replace("%", "", $match[0]);'
              ),
              $Tag_Values[$m]
            );
            $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^(?!".$Tag_Values[$m].").*$/"));
        }

        if ($Operators[$m] == "ends_with")
        {

        $Tag_Values[$m] = preg_replace_callback(
                '~%(.+?)~',
                create_function(
                    '$match',
                    'return str_replace("%", "", $match[0]);'
                ),
                $Tag_Values[$m]
              );
          $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/".$Tag_Values[$m]."$/"));
          $RegEx_Array[$Query_Tags[$m]] =  new MongoRegex("/".$Tag_Values[$m]."$/");


        }
        if ($Operators[$m] == "not_ends_with")
        {

        $Tag_Values[$m] = preg_replace_callback(
                '~%(.+?)~',
                create_function(
                    '$match',
                    'return str_replace("%", "", $match[0]);'
                ),
                $Tag_Values[$m]
              );
          $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^((?!".$Tag_Values[$m]."$)[/\w.-])+$/"));
        }


        if ($Operators[$m] == "like")
        {
          if(preg_match("/%.+%/",$Tag_Values[$m]))
          {
            $Tag_Values[$m] = preg_replace_callback(
              '~%(.+?)%~',
              create_function(
                  '$match',
                  'return str_replace("%", "", $match[0]);'
              ),
              $Tag_Values[$m]
            );

            $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/".$Tag_Values[$m]."/"));
            $RegEx_Array[$Query_Tags[$m]] = new MongoRegex("/".$Tag_Values[$m]."/");
            
          }
          if(preg_match("/.+%/",$Tag_Values[$m]))
          { 
            $Tag_Values[$m] = preg_replace_callback(
              '~(.+?)%~',
              create_function(
                  '$match',
                  'return str_replace("%", "", $match[0]);'
              ),
              $Tag_Values[$m]
            );
            $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^".$Tag_Values[$m]."/"));
            $RegEx_Array[$Query_Tags[$m]] = new MongoRegex("/^".$Tag_Values[$m]."/");
          }
          if(preg_match("/%.+/",$Tag_Values[$m]))
          {

            $Tag_Values[$m] = preg_replace_callback(
                '~%(.+?)~',
                create_function(
                    '$match',
                    'return str_replace("%", "", $match[0]);'
                ),
                $Tag_Values[$m]
              );
          $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/".$Tag_Values[$m]."$/"));
          $RegEx_Array[$Query_Tags[$m]] =  new MongoRegex("/".$Tag_Values[$m]."$/");
          }
        }

        if ($Operators[$m] == "not_like")
        {
          if(preg_match("/%.+%/",$Tag_Values[$m]))
          { 
            
            $Tag_Values[$m] = preg_replace_callback(
              '~%(.+?)%~',
              create_function(
                  '$match',
                  'return str_replace("%", "", $match[0]);'
              ),
              $Tag_Values[$m]  
            );

            $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^((?!".$Tag_Values[$m].").)*$/"));
          }
          if(preg_match("/.+%/",$Tag_Values[$m]))
          { 
            $Tag_Values[$m] = preg_replace_callback(
              '~(.+?)%~',
              create_function(
                  '$match',
                  'return str_replace("%", "", $match[0]);'
              ),
              $Tag_Values[$m]
            );
            $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^(?!".$Tag_Values[$m].").*$/"));
          }
          if(preg_match("/%.+/",$Tag_Values[$m]))
          {

            $Tag_Values[$m] = preg_replace_callback(
                '~%(.+?)~',
                create_function(
                    '$match',
                    'return str_replace("%", "", $match[0]);'
                ),
                $Tag_Values[$m]
              );
          $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^((?!".$Tag_Values[$m]."$)[/\w.-])+$/"));
          }
        }

        if ($Operators[$m] == "begins_with")
        {
        $Part_Array[$m] = array($Query_Tags[$m]=> new MongoRegex("/^".$Tag_Values[$m]."/"));
        
        }
        if ($Operators[$m] == "order_by")
        { 
          

          if($Tag_Values[$m] == "ASC")
          { 
            
            $order_by = array("$Query_Tags[$m]" => 1);
            
          }
          if($Tag_Values[$m] == 'DESC')
            {
              $order_by = array($Query_Tags[$m] => -1);
            }
        
        }
        if ($Operators[$m] == ">")
        {
                  
          $val = $Tag_Values[$m];
          
          $Part_Array[$m] = array($Query_Tags[$m]=> array('$gt'=> $val));

        }
        if ($Operators[$m] == ">=")
        {
        $val = $Tag_Values[$m];
        $Part_Array[$m] = array($Query_Tags[$m]=> array('$gte'=> $val));

        }
        if ($Operators[$m] == "<=")
        {
        $val = $Tag_Values[$m];
        $Part_Array[$m] = array($Query_Tags[$m]=> array('$lte'=> $val));

        }
        if ($Operators[$m] == "<")
        {
        $val = $Tag_Values[$m];
        $Part_Array[$m] = array($Query_Tags[$m]=> array('$lt'=> $val));

        }
        if ($Operators[$m] == "!=")
        {
        $val = $Tag_Values[$m];
        $Part_Array[$m] = array($Query_Tags[$m]=> array('$ne'=> $val));
        array_push($Not_Equals_Tags,$Query_Tags[$m]);

        }
        if (!in_array($Operators[$m],array("!=","<","<=",">=",">","order_by","begins_with","not_begins_with","not_like","like","not_ends_with","ends_with","contains","not_contains","=")))
        {
            $Part_Array[$m] = array("_id"=> "#$@$");
        }

        $m++;

      }
      
      
      if ($Part_Array == array())
      {
        if ($Log_Type != 8)
        {
        $Part_Array[0] = array("Log_Type" => $Log_Type);
        }
        else
        {
         $Query_Array   = array();
        }
        if ($time_dropdown!=7 )
        {
          if ($time_dropdown==8)
          { 
            $start = new MongoDate(strtotime($f[1]));
            $end = new MongoDate(strtotime($f[2]));
            $Part_Array[1] = array("Time_Of_Arrival" => array('$gte' => $start,'$lte' => $end));
          }
          else
          {
          $Part_Array[1] = array("Time_Of_Arrival" => array('$lt' => $date,'$gte' => $end));
          }
          //$Part_Array[1] = array("Time_Of_Arrival" => array('$lt' => $date,'$gte' => $end));
        }
        else
        {
          if (strlen(trim($query)) != 0)
          {
          $Part_Array[1] = array("Time_Of_Arrival" => array('$lt' => $date));
          }
        }
        
      }
      else
      { 
        if ($Log_Type != 8)
        {
          
        $Part_Array[$m] = array("Log_Type" => $Log_Type);
        $m++;
        
        }
        if ($time_dropdown!=7)
        {
          if ($time_dropdown==8)
          { 
            $start = new MongoDate(strtotime($f[1]));
            $end = new MongoDate(strtotime($f[2]));
            $Part_Array[$m] = array("Time_Of_Arrival" => array('$gte' => $start,'$lte' => $end));
            $m++;
          }
          else
          {
          $Part_Array[$m] = array("Time_Of_Arrival" => array('$lt' => $date,'$gte' => $end));
          $m++;
          }
          
        }
        else
        {
          $Part_Array[$m] = array("Time_Of_Arrival" => array('$lt' => $date));
          $m++;
        }

         
        $Query_Array['$and'] = $Part_Array;
      }
      if (strlen(trim($query)) == 0)
        {
          if ($time_dropdown!=7)
          {
              if ($time_dropdown==8)
              { 
                $start = new MongoDate(strtotime($f[1]));
                $end = new MongoDate(strtotime($f[2]));
                $Part_Array[$m] = array("Time_Of_Arrival" => array('$gte' => $start,'$lte' => $end));
                $m++;
              }
              else
              {
              $Part_Array[$m] = array("Time_Of_Arrival" => array('$lt' => $date,'$gte' => $end));
              $m++;
              }
            
          }
          else
          {
            $Part_Array[$m] = array("Time_Of_Arrival" => array('$lt' => $date));
            $m++;
          }

          if ($Log_Type!=8)
          {
            $Part_Array[$m] = array("Log_Type" => $Log_Type);
            $m++;
          }
           $Query_Array['$and'] = $Part_Array;
        }


      
      if ($order_by)
      { 
        
        $cursor = $Log_Collection->find($Query_Array,$Select_Array);

      } 
      else
      { 
                
        $cursor = $Log_Collection->find($Query_Array,$Select_Array);
         
      }
      $RegEx_Keys = array_keys($RegEx_Array);
      if(!$select)
      {$search_regex = new MongoRegex("/".substr($search_string,1,-1)."/");}

      
    
      $reg_condition = 0;
    $color = 0;
      foreach ($cursor as $row)
      {
        $color++;
        foreach ($row as $field)
        { 

          $k = -1;

          if (strlen(trim($query)) == 0 && !($select))
          { 

              if(preg_match($search_regex,$field))
                { 
                  
                  $reg_condition = 1;
                  
                }
              else{
                
                $reg_condition = 0;
              }
          
          } 


          if($RegEx_Array)
          {
            foreach($RegEx_Array as $regex_Key_Value)
            {
             
              $k++;
              if(preg_match($regex_Key_Value,$field)&& $field==$row[$RegEx_Keys[$k]])
              { 
                $another_reg_condition = 1;
                break;
              }
              else
              {
                $another_reg_condition  =0;
              }
            }
          }
          else
          {
              $another_reg_condition  = 0;
          }


          if (in_array($field,$Equals_Array))
          { 
              // echo "APPLE1";
            echo "<mark>".$field."</mark>";
            echo "&nbsp;&nbsp;&nbsp;&nbsp;";
          }
          elseif ($reg_condition == 1) 
          {
              //echo "APPLE2";
           echo "<mark>".$field."</mark>";
            echo "&nbsp;&nbsp;&nbsp;&nbsp;";
          } 
          elseif ($another_reg_condition == 1) 
          {
             // echo "APPLE3";
           echo "<mark>".$field."</mark>";
            echo "&nbsp;&nbsp;&nbsp;&nbsp;";
          }       
          else
          {
           
                    if ($color%2 == 0)       
                    {
                      echo '<font color="green">'. $field.'</font>';
                    }
                    else
                    {
                      echo '<font color="red">'. $field.'</font>';
                    }
           
                  echo "&nbsp;&nbsp;&nbsp;&nbsp;";
          }

        } 
        if($row!=array())
        {echo "<br>";}
      }
    } 
    $f = array();
    $f[1] =0;$f[2] =0;
    if ($query == -1)
    {
      
      if(isset($_POST['log_type']))
      { 
         
         $time_dropdown = $_POST['set_time_dropdown'];
         

          if ($time_dropdown == 1)
        {
          
          $f[1] = 15;
          $f[2] = "minutes";
         
        }

        if ($time_dropdown == 2)
        {
          $f[1] = 30;
          $f[2] = "minutes";
        }

        if ($time_dropdown == 3)
        {
          $f[1] = 60;
          $f[2] = "minutes";
        }
        if ($time_dropdown == 4)
        {
          $f[1] = 24;
          $f[2] = "hours";
        }
        if ($time_dropdown == 5)
        {
          $f[1] = 7;
          $f[2] = "days";
        }
        if ($time_dropdown == 6)
        {
          $f[1] = 30;
          $f[2] = "days";
        }
        if ($time_dropdown == 8)
        {
          $f[1] = $_POST['startTimeValue'];
          $f[2] = $_POST['endTimeValue'];
        }
        

        $date = new MongoDate();    
                 
        $diff =0.0;
        if ($f[2] =="days")
        {
                  
        $diff = 24*60*60;

        }
        if ($f[2] == "hours")
        {
          $diff = 60*60;
        }
        if ($f[2] == "minutes")
        {
          $diff = 60;
        }
        if ($f[2] == "seconds")
        {
          $diff = 1;
        }
                 
        $diff1 =  ($date ->sec)-($f[1]*$diff);
                 
        $end = new MongoDate($diff1);
                 
                 
        $Part_Array = array();

        if ($time_dropdown!=7)
        {
            if ($time_dropdown==8)
            { 
              $start = new MongoDate(strtotime($f[1]));
              $end = new MongoDate(strtotime($f[2]));
              $Part_Array[0] = array("Time_Of_Arrival" => array('$gte' => $start,'$lte' => $end));
              
            }
            else
            {
            $Part_Array[0] = array("Time_Of_Arrival" => array('$lt' => $date,'$gte' => $end));
           
            }
         
        }
        else
        {
          $Part_Array[0] = array("Time_Of_Arrival" => array('$lt' => $date));
        }

          //============================================================

        $Log_Type = $_POST['log_type'];
        

        if ($Log_Type == 1)
        {
          $Log_Type = "Json";
        }
        if ($Log_Type == 2)
        {
          $Log_Type = "Xml";
          
        }
        if ($Log_Type == 3)
        {
          $Log_Type = "Access_Log";
          
        }
        if ($Log_Type == 4)
        {
          $Log_Type = "Error_Log";
        }
        if ($Log_Type == 5)
        {
          $Log_Type = "IIS_Log_File_Format";
        }
        if ($Log_Type == 6)
        {
          $Log_Type = "W3C_Extended_Log_Format";
        }
        if ($Log_Type == 7)
        {
          $Log_Type = "NCSA_Common_Log_Format";
        }

        if ($Log_Type!=8)
        {
          $Part_Array[1] = array("Log_Type" => $Log_Type);
        }
                 
        $Query_Array = array();
        $Query_Array['$and'] =  $Part_Array;
        
       
        $cursor = $Log_Collection->find($Query_Array,array("Log_Type"=> 0, "Time_Of_Arrival" => 0));
        echo "<br>";
        $color = 1;
        foreach ($cursor as $row)
                {
                   if ($color%2 == 0)       
                    {
                      echo '<font color="green">'. $row['Line'].'</font>';
                    }
                    else
                    {
                      echo '<font color="red">'. $row['Line'].'</font>';
                    }
                $color++;
                                  
                 
                  echo "<br>";
                }
               
              
      

            }

      if(isset($_POST['time_dropdown']))
      {

        $Log_Type = $_POST['set_log_type'];
        if ($Log_Type == 1)
        {
          $Log_Type = "Json";
        }
        if ($Log_Type == 2)
        {
          $Log_Type = "Xml";
          
        }
        if ($Log_Type == 3)
        {
          $Log_Type = "Access_Log";
          
        }
        if ($Log_Type == 4)
        {

          $Log_Type = "Error_Log";
        }
        if ($Log_Type == 5)
        {
          $Log_Type = "IIS_Log_File_Format";
        }
        if ($Log_Type == 6)
        {
          $Log_Type = "W3C_Extended_Log_Format";
        }
        if ($Log_Type == 7)
        {
          $Log_Type = "NCSA_Common_Log_Format";
        }

        
        $time_dropdown = $_POST['time_dropdown'];
        if ($time_dropdown == 1)
        {
          
          $f[1] = 15;
          $f[2] = "minutes";
         
        }

        if ($time_dropdown == 2)
        {
          $f[1] = 30;
          $f[2] = "minutes";
        }

        if ($time_dropdown == 3)
        {
          $f[1] = 60;
          $f[2] = "minutes";
        }
        if ($time_dropdown == 4)
        {
          $f[1] = 24;
          $f[2] = "hours";
        }
        if ($time_dropdown == 5)
        {
          $f[1] = 7;
          $f[2] = "days";
        }
        if ($time_dropdown == 6)
        {
          $f[1] = 30;
          $f[2] = "days";
        }
        if ($time_dropdown == 8)
        {
          $f[1] = $_POST['startTimeValue'];
          $f[2] = $_POST['endTimeValue'];
        }


        

        $date = new MongoDate();    
                 
        $diff =0.0 ;
        if ($f[2] =="days")
        {
                   
        $diff = 24*60*60;

        }
        if ($f[2] == "hours")
        {
          
          $diff = 60*60;

        }
        if ($f[2] == "minutes")
        {
          
          $diff = 60;

        }
        if ($f[2] == "seconds")
        {
          
          $diff = 1;

        }
                 
        $diff1 =  ($date ->sec)-($f[1]*$diff);
                 
        $end = new MongoDate($diff1);
                 
                
        $Part_Array = array();



        if ($time_dropdown!=7)
        {
          if ($time_dropdown==8)
          { 
            $start = new MongoDate(strtotime($f[1]));
            $end = new MongoDate(strtotime($f[2]));
            $Part_Array[0] = array("Time_Of_Arrival" => array('$gte' => $start,'$lte' => $end));
          }
          else
          {
          $Part_Array[0] = array("Time_Of_Arrival" => array('$lt' => $date,'$gte' => $end));
          }
        }
        else
        {
          $Part_Array[0] = array("Time_Of_Arrival" => array('$lt' => $date));
        }

        if ($Log_Type!=8)
        {
          $Part_Array[1] = array("Log_Type" => $Log_Type);
        }
                 
        $Query_Array = array();
        $Query_Array['$and'] =  $Part_Array;
       
        $cursor = $Log_Collection->find($Query_Array,array("Time_Of_Arrival" =>0));
        $color = 1;
        foreach ($cursor as $row)
        {
          
          foreach ($row as $field)
          {
            if($field!= $row['Line']  && $field != $row['_id'] &&  $field != $row['Log_Type'])
            {
              if ($color%2 == 0)       
              {
                echo '<font color="green">'.$field.'</font>';
              }
              else
              {
                echo '<font color="red">'.$field.'</font>';
              }
              echo "&nbsp;&nbsp;&nbsp;&nbsp;";
            }

          }
           $color++;                    
                
          echo "<br>";
        }
                       
          
        
      }
      
  }
  
 
}




function MapReduce_QueryBuilder($query1,$app_type,$User_Id){


  $App_Name = substr($app_type,0,-3);
 $App_Name = str_replace(" ","_7_7_",$App_Name);
  $m = new MongoClient();
      
  $User_DB = $m->$User_Id;

   
  $App_Collection = $User_DB->Apps;
  $cursor = $App_Collection->find(array("App_Name" => $App_Name));
 
  foreach ($cursor as $row)
  {
    $App_Id = $row['App_Id'];
  }
  
  $db = $m->$User_Id;

  $Log_Collection_Name = $App_Id."_Logs"; //Just a name 
  $Log_Collection = $db->$Log_Collection_Name;

  $cursor = $Log_Collection->find();
  //$date = new MongoDate();  
  foreach ($cursor as $row)
  {
    //$date = new MongoDate(strtotime($row['Time_Of_Arrival']));  //need to change this
    if (is_string($row['Time_Of_Arrival']))
    {
      $date = new MongoDate(strtotime($row['Time_Of_Arrival']));
      $newdata = array('$set' => array("Time_Of_Arrival" =>  $date));
    $Log_Collection->update(array("_id" => $row['_id']), $newdata);
    }
    
  }

  
  $query= $query1;

  $all_occ = array();
  for ($t=0;$t<strlen($query);$t = $t + 1)
  {
      if ($query[$t] == '"')
     {
       $all_occ = array_merge($all_occ,array($t));
     }
  }

for ($r=0;$r<count($all_occ);$r = $r + 2)
{
 $string = substr($query,$all_occ[$r]+1,$all_occ[$r+1] - $all_occ[$r] - 1 );
 $string = str_replace(' ','@',$string);

 $query = substr($query,0,$all_occ[$r]+1).$string.substr($query,$all_occ[$r+1]);
}
$query = preg_replace('/\s+/', ' ',$query);
if ($query[0]==" ")
{
  $query = substr($query,1);
}

$all_occ = array();
for ($t=0;$t<strlen($query);$t = $t + 1)
{
 if ($query[$t] == '"')
 {
   $all_occ = array_merge($all_occ,array($t));
 }
}
for ($r=0;$r<count($all_occ);$r = $r + 2)
{
 $string = substr($query,$all_occ[$r]+1,$all_occ[$r+1] - $all_occ[$r] - 1 );
 $string = str_replace('@',' ',$string);
 
 $query = substr($query,0,$all_occ[$r]+1).$string.substr($query,$all_occ[$r+1]);
}

$replace = array();
preg_match_all('/in/i',$query,$replace);
for($counter = 0; $counter < count($replace) ; $counter = $counter + 1)
{
$query = str_replace($replace[$counter],'in',$query);
}

$replace = array();
preg_match_all('/not_in/i',$query,$replace);
for($counter = 0; $counter < count($replace) ; $counter = $counter + 1)
{
$query = str_replace($replace[$counter],'not_in',$query);
}

$replace = array();
 
preg_match_all('/sum/i',$query,$replace);

for($counter = 0; $counter < count($replace) ; $counter = $counter + 1)
{

$query = str_replace($replace[$counter],'Sum',$query);


}

$replace = array();
preg_match_all('/count/i',$query,$replace);

for($counter = 0; $counter < count($replace) ; $counter = $counter + 1)
{
 
$query = str_replace($replace[$counter],'Count',$query);
}


$replace = array();
preg_match_all('/avg/i',$query,$replace);
for($counter = 0; $counter < count($replace) ; $counter = $counter + 1)
{
$query = str_replace($replace[$counter],'Avg',$query);
}

$replace = array();
preg_match_all('/where/i',$query,$replace);
for($counter = 0; $counter < count($replace) ; $counter = $counter + 1)
{
$query = str_replace($replace[$counter],'where',$query);
}

$arr_reducer= array();
$arr_mapper = array();
$arr_queryD = array();
$arr_query = explode(" ", $query);
for ($r=0;$r<count($arr_query);$r = $r +1)
{
  if (preg_match('/^{/',$arr_query[$r]))
  {
         
           if (preg_match('/}$/',$arr_query[$r]))
           {
             $arr_query[$r] = substr($arr_query[$r],1,strlen($arr_query[$r])-2);
             $s = array($arr_query[$r]);
          
             $f=$r;
            }
           else
           {
             $arr_query[$r]= substr($arr_query[$r],1);
          
             $s = array($arr_query[$r]);
        
             for ($f=$r+1; $f<count($arr_query);$f = $f+1)
             {
       
               if (preg_match('/}$/',$arr_query[$f]))
                 {
                    $s = array_merge($s,array(substr($arr_query[$f],0,strlen($arr_query[$f])-1)));
                 
                    break;
                 }
               $s=array_merge($s,array($arr_query[$f]));
            
             }
           }
           $s = array_merge($s,array("end"));
       
           for ($t = 0 ; $t<count($s); $t = $t + 1)
           {
              if (preg_match('/^"/',$s[$t]))
              {
                if (preg_match('/"$/',$s[$t]))
                {
                   $s[$t] = substr($s[$t],1,strlen($s[$t])-2);
                }
                else
                {
                  $s1 = substr($s[$t],1)." ";
                   for ($f=$t+1; $f<count($s);$f = $f+1)
                     {
       
                         if (preg_match('/"$/',$s[$f]))
                         {
                             $s1 = $s1.substr($s[$f],0,strlen($s[$f])-1);
                        
                               break;
                         }
                         $s1=$s1.$s[$f]." ";
                      
                    }
                    $s = array_merge(array_slice($s,0,$t),array($s1),array_slice($s,$f+1));
                }
                
              }
           }
           
    $arr_query = array_merge(array_slice($arr_query,0,$r),$s,array_slice($arr_query,$f+1,count($arr_query)-$f-1)); 
  }
  if (preg_match('/^"/',$arr_query[$r]))
  {
           if (preg_match('/"$/',$arr_query[$r]))
           {
             $arr_query[$r] = substr($arr_query[$r],1,strlen($arr_query[$r])-2);
             $s = $arr_query[$r];
          
             $f=$r;
            }
           else
           {
             $arr_query[$r]= substr($arr_query[$r],1);
           
             $s = $arr_query[$r]." ";
          
             for ($f=$r+1; $f<count($arr_query);$f = $f+1)
             {
       
               if (preg_match('/"$/',$arr_query[$f]))
                 {
                    $s = $s.substr($arr_query[$f],0,strlen($arr_query[$f])-1);
                   
                    break;
                 }
               $s=$s.$arr_query[$f]." ";
          
             }
           }
    
    $arr_query = array_merge(array_slice($arr_query,0,$r),array($s),array_slice($arr_query,$f+1,count($arr_query)-$f-1)); 
  }
}

$end = count($arr_query);
for ($i=0;$i<count($arr_query);$i=$i+1)
{
   if ($i==0)
  {
    if ((preg_match("/^Sum\(/",$arr_query[$i]))||(preg_match("/^Count\(/",$arr_query[$i]))||(preg_match("/^Avg\(/",$arr_query[$i]))) 
    {
    $arr_mapper = array(" ");
    }
  }
  if ($arr_query[$i]=='where')
  {
    $end = $i;
    break;
  }
        if ((preg_match("/^Sum\(/",$arr_query[$i]))||(preg_match("/^Count\(/",$arr_query[$i]))||(preg_match("/^Avg\(/",$arr_query[$i]))) 
  {
         
          $pos = strpos($arr_query[$i],"(");
          
          
          $arr_reducer = array_merge($arr_reducer,array(substr($arr_query[$i],0,$pos)),array(substr($arr_query[$i],$pos+1,strlen($arr_query[$i])-$pos-2)));
    $arr_mapper = array_merge($arr_mapper,array(substr($arr_query[$i],$pos+1,strlen($arr_query[$i])-$pos-2)));
 
  }
  else
  {
    if ($i!=0)
    {
       $arr_reducer=array_merge($arr_reducer,array($arr_query[$i]));  
    }
    $arr_mapper = array_merge($arr_mapper,array($arr_query[$i]));
  }
 
}

$j = $end + 1;


while ($j<count($arr_query))
{
  
  if ($arr_query[$j]!='->')
  {       
          if(($arr_query[$j]=='=')||($arr_query[$j]=='!=')||($arr_query[$j]=='>')||($arr_query[$j]=='<'))
          {
           $arr_queryD = array_merge($arr_queryD,array($arr_query[$j]),array($arr_query[$j+1]));
           $j = $j+1;
           
                  
          }
          else{
                if (($arr_query[$j] == ':')||($arr_query[$j] == '!:'))
                {
                   if ($arr_query[$j+2] != "->")
                   {
                    $arr_queryD = array_merge($arr_queryD,array($arr_query[$j]),array($arr_query[$j+1]));
                    $j = $j + 1;
                   }
                   else
                   {
                   $arr_queryD = array_merge($arr_queryD,array($arr_query[$j]),array($arr_query[$j+1]),array($arr_query[$j+3]));
                   $j = $j+3;
                   }
                 
                echo '<br/>';
                echo '<br/>';
         
                echo '<br/>';
          }
          else
            {
                  if (($arr_query[$j]=='in')||($arr_query[$j] == 'not_in'))
                  {
                     if ($arr_query[$j-1]=='Time_Of_Arrival')
                     {
                        for ($e=$j;$e<count($arr_query);$e = $e +1)
                     {
                       if (($arr_query[$e]==',')||($arr_query[$e]=='and')||($e=count($arr_query)-1))
                       {
                        $d = $j + 1;
                        $arr_query1 = array_slice($arr_query,0,$d);
                   
                        echo '<br/>';
                        while($d<=$e)
                        {
                         $f = $arr_query[$d]." ".$arr_query[$d+1];
                         $arr_query1 = array_merge($arr_query1,array($f));
                       
                         $d = $d + 2;
                        }
                        $arr_query1 = array_merge($arr_query1,array('end'),array_slice($arr_query,$e+1));
                     
                        $arr_query = $arr_query1;
                        break;
                       }
                     }
                     }
                     else
                     {
                     for ($e=$j;$e<count($arr_query);$e = $e +1)
                     {
                       if (($arr_query[$e]==',')||($arr_query[$e]=='and'))
                       {
                        $arr_query = array_merge(array_slice($arr_query,0,$e),array('end'),array_slice($arr_query,$e));
                        break;
                       }
                     }
                     }
                  }
                  $arr_queryD = array_merge($arr_queryD,array($arr_query[$j]));
            }
            }
  }
 $j = $j +1;
}
if ($i==count($arr_query))
{
$arr_queryD = array();
}
$time_dropdown = $_POST['set_time_dropdown'];
$Log_Type = $_POST['set_log_type'];

if ($Log_Type == 1)
      {
        $Log_Type = "Json";
      }
      if ($Log_Type == 2)
      {
        $Log_Type = "Xml";
        
      }
      if ($Log_Type == 3)
      {
        $Log_Type = "Access_Log";
        
      }
      if ($Log_Type == 4)
      {
        $Log_Type = "Error_Log";
      }
      if ($Log_Type == 5)
      {
        $Log_Type = "IIS_Log_File_Format";
      }
      if ($Log_Type == 6)
      {
        $Log_Type = "W3C_Extended_Log_Format";
      }
      if ($Log_Type == 7)
      {
        $Log_Type = "NCSA_Common_Log_Format";
      }
       

          if ($time_dropdown == 1)
        {
          
          $string = "last_15_minutes";
         
        }

        if ($time_dropdown == 2)
        {
          $string = "last_30_minutes";
        }

        if ($time_dropdown == 3)
        {
          $string = "last_60_minutes";
        }
        if ($time_dropdown == 4)
        {
          $string = "last_24_hours";
        }
        if ($time_dropdown == 5)
        {
          $string = "last_7_days";
        }
        if ($time_dropdown == 6)
        {
          $string = "last_30_days";;
        }
        
         if (($time_dropdown ==7)&&($Log_Type !=8)) 
         {
          $arr_queryD = array_merge(array('Log_Type','=',$Log_Type),$arr_queryD);
         }
         if (($time_dropdown !=7)&&($Log_Type ==8))
         { 
            
             if ($time_dropdown ==8)
          {
          $startTime = new MongoDate(strtotime($_POST['startTimeValue']));
          $endTime = new MongoDate(strtotime($_POST['endTimeValue']));
          $arr_queryD = array_merge($arr_queryD,array('Time_Of_Arrival',':',$startTime,$endTime));
           }
           else
           {
           $arr_queryD = array_merge($arr_queryD,array('Time_Of_Arrival',':',$string));
           }
         }
         if (($time_dropdown !=7)&&($Log_Type !=8))
         {
          if ($time_dropdown ==8)
        {
          $startTime = $_POST['startTimeValue'];
          $endTime = $_POST['endTimeValue'];
          $arr_queryD = array_merge($arr_queryD,array('Time_Of_Arrival',':',$startTime,$endTime),array('Log_Type','=',$Log_Type));
        }
        else
        {
          $arr_queryD = array_merge($arr_queryD,array('Time_Of_Arrival',':',$string),array('Log_Type','=',$Log_Type));
        }  
        }







function mapReduce($k,$arr_mapper,$arr_reducer , $arr_queryD , $db , $Log_Collection_Name)
{
    
  

    $name = "map_reduce".(string)$k ;


   $mapFunction1 = new MongoCode ( 'function() 
    { 
                       first = { "value" : 0 , "count" : 0 } ;
                       second = { "value" : 0 , "count" : 0 } ;
                    
       first = this[arr_mapper[0]];
       if (!isNaN(first))
       {
        first = parseInt(first);
       }
       second = this[arr_mapper[1]];
       if (!isNaN(second))
       {
        second = parseInt(second);
       }
             if (arr_reducer[0]=="Count")
             {
                                print("entered");
                                first = second;
                                second= 1;
             }
        emit (first,second); 
    } ',array('arr_mapper' => $arr_mapper , 'arr_reducer' => $arr_reducer));
  $reduceFunction1 = new MongoCode ('function(key,values)
  {
    return Array.sum(values);

   }');
$final = query($arr_queryD,$arr_mapper,$arr_reducer);

if ($final == array())
{
$result = $db->command(array(
    'mapreduce' => $Log_Collection_Name, // collection name
    'map' => $mapFunction1,
    'reduce' => $reduceFunction1,
    "out" => array('inline' => 1)  // new collection name
));
}
else
{
$result = $db->command(array(
    'mapreduce' => $Log_Collection_Name, // collection name
    'map' => $mapFunction1,
    'reduce' => $reduceFunction1,
    "query" => $final,
    "out" => array('inline' => 1)  // new collection name
));

}


echo '<br/>';
echo ("The Result    " ) ;

for ($i = 0;$i<count($result["results"]);$i = $i +1)
{
 if ($arr_reducer[0]=="Count")
{
    echo ($arr_reducer[1]);
    echo "   -   ";
    echo $result["results"][$i]["_id"]."  ";

    echo ("Count   -   ");
    echo $result["results"][$i]["value"];
    echo '<br/>'; 
}
else
{
    echo ($arr_mapper[0]);
    echo "   -   ";
    echo $result["results"][$i]["_id"]."   ";
    
    echo ($arr_reducer[0]);
    echo (" of ");
    echo ($arr_reducer[1]);
    echo ("   -   ");
    echo $result["results"][$i]["value"]; 
}

}



}

function mapReduce1($k,$arr_mapper,$arr_reducer , $arr_queryD , $db , $Log_Collection_Name)
{
    $c = $db -> selectCollection("map_reduce_example");
    $c -> drop();
    $final = query($arr_queryD,$arr_mapper,$arr_reducer);
    //echo "final";
    //var_dump($final) ;
    //echo ("mapreduce1"); 
    //var_dump($arr_mapper);
    //echo '<br/>';
    //var_dump($arr_reducer);
    //echo '<br/>';
    //var_dump($k);
    //echo '<br/>' ;

    //$name = "map_reduce".(string)$k ;
    //var_dump($name);
    //echo '<br/>';
 $mapFunction2 = new MongoCode ( 'function()
                           {
                                second = {"value" : 0 , "count" : 1 } ;
                                second.value = this[arr_mapper[1]];
                                first = this[arr_mapper[0]];
    emit (first,second);
      } ',array('arr_mapper' => $arr_mapper , 'arr_reducer' => $arr_reducer));
$reduceFunction2 = new MongoCode ('function(key,values)
  {
        reducedVal = {"value" : 0 , "count" : 0 };
    for (var idx = 0; idx < values.length; idx++) {
                         reducedVal.count += values[idx].count;
                         reducedVal.value += values[idx].value;
                     }
    return reducedVal;

  }');
$finalizeFunction2 = new MongoCode('function(key,reducedVal)
  {
  if (reducedVal.count ==1)
  {
   reducedVal.avg = reducedVal.value;
  }
  else
  {
  reducedVal.avg = reducedVal.value/reducedVal.count;
  }
  return reducedVal ;
  }' );

if ($final == array())
{
$result = $db->command(array(
    'mapreduce' => $Log_Collection_Name, // collection name
    'map' => $mapFunction2,
    'reduce' => $reduceFunction2,
    'finalize' => $finalizeFunction2,
    "out" => array ( 'merge' => "map_reduce_example") // new collection name
));
}
else
{
 //echo "correct" ;
$result = $db->command(array(
    'mapreduce' => $Log_Collection_Name, // collection name
    'map' => $mapFunction2,
    'reduce' => $reduceFunction2,
    'finalize' => $finalizeFunction2,
    "out" => array ( 'merge' => "map_reduce_example") ,
    "query" => $final
));

}
echo '<br/>';
echo ("The result" ) ;
echo '<br/>';
//var_dump($result);
echo '<br/>';
//var_dump(json_decode($result));

//var_dump($result["results"]);
$c = $db -> selectCollection("map_reduce_example");
$cursor = $c -> find();
foreach ($cursor as $doc)
{
    echo ($arr_mapper[0]);
    echo "   -   ";
    echo $doc["_id"];
    echo '<br/>';
    echo ($arr_reducer[0]);
    echo (" of ");
    echo ($arr_reducer[1]);
    echo ("   -   ");
    echo $doc["value"]["avg"];
    echo '<br/>'; 
}


}
function query($arr_queryD,$arr_mapper,$arr_reducer)
{
$final = array();
for ($r=0;$r<count($arr_queryD);$r=$r+1)
   { 
                 

      if ($arr_queryD[$r]=='in')
      {
      
    
        $in_arr = array();
        for ($f=$r+1 ; $f < count($arr_queryD) ; $f = $f + 1)
        {
             if ($arr_queryD[$f]=='end')
             {
              break;
             }
             else
             {
               
                  if ($arr_queryD[$r-1]=='Time_Of_Arrival')
                  {
                    $in_arr = array_merge($in_arr,array(new MongoDate(strtotime($arr_queryD[$f]))));
                  }
                  else
                  {
                $in_arr = array_merge($in_arr,array($arr_queryD[$f]));
                  }
                
              }
        } 
        
        $final = array_merge($final,array($arr_queryD[$r-1] => array('$in' => $in_arr))); 
      }
      if ($arr_queryD[$r]=='not_in')
      {
   
        $in_arr = array();
        for ($f=$r+1 ; $f < count($arr_queryD) ; $f = $f + 1)
        {
             if ($arr_queryD[$f]=='end')
             {
              break;
             }
             else
             {
               
                   if ($arr_queryD[$r-1]=='Time_Of_Arrival')
                  {
                    $in_arr = array_merge($in_arr,array(new MongoDate(strtotime($arr_queryD[$f]))));
                  }
                  else
                  {
                $in_arr = array_merge($in_arr,array($arr_queryD[$f]));
                  }
               
                  
              }
        } 
      
        $final = array_merge($final,array($arr_queryD[$r-1] => array('$not' => array('$in' => $in_arr)))); 
      }
      if(($arr_queryD[$r]=='~')||($arr_queryD[$r] =='!~'))
      {
       $reg = $arr_queryD[$r+1];
       
       $reg=str_replace("-",".*",$reg);
       $reg=str_replace("%",".*",$reg);
         $reg = "/".$reg."/";
          $regex = new MongoRegex($reg);
          if ($arr_queryD[$r]=='~')
          {
          $final = array_merge($final,array($arr_queryD[$r-1] => $regex));
          }
          else
          {
           $final = array_merge($final,array($arr_queryD[$r-1] => array('$not' => $regex)));
          }
       }  
      if($arr_queryD[$r]=='=')
       {
         
         if ($arr_queryD[$r-1]=='Time_Of_Arrival')
                  {
                    $t1 = new MongoDate(strtotime($arr_queryD[$r+1]));
                  }
                  else
                  {
          $t1= $arr_queryD[$r+1];
          }
          
          $final = array_merge($final,array($arr_queryD[$r-1] => $t1));
       }
       if($arr_queryD[$r]=='!=')
       {
         
          if ($arr_queryD[$r-1]=='Time_Of_Arrival')
                  {
                    $t1 = new MongoDate(strtotime($arr_queryD[$r+1]));
                  }
                  else
                  {
          $t1= $arr_queryD[$r+1];
          }
         
          $final = array_merge($final,array($arr_queryD[$r-1] => array('$ne' => $t1)));
       }
       if ($arr_queryD[$r] == '>')
        {
        
         if ($arr_queryD[$r-1]=='Time_Of_Arrival')
                  {
                    $t1 = new MongoDate(strtotime($arr_queryD[$r+1]));
                  }
                  else
                  {
          $t1= $arr_queryD[$r+1];
          }
      
       $final = array_merge($final,array($arr_queryD[$r-1] => array('$gte' => $t1)));
       }
      if ($arr_queryD[$r] == '<')
        {
         
         if ($arr_queryD[$r-1]=='Time_Of_Arrival')
                  {
                    $t1 = new MongoDate(strtotime($arr_queryD[$r+1]));
                  }
                  else
                  {
          $t1= $arr_queryD[$r+1];
          }
         //}
       $final = array_merge($final,array($arr_queryD[$r-1] => array('$lt' => $t1)));
       }
       if ($arr_queryD[$r] == ':')
        {
         if ($arr_queryD[$r-1]=='Time_Of_Arrival')

         {
      
           if (strpos($arr_queryD[$r+1],"_") != False)
           {
               $date = new MongoDate();
               
               $f = explode("_",$arr_queryD[$r+1]);
               $f[1] = intval($f[1]);
               $diff =0.0 ;
               if ($f[2] =="days")
               {
                 
                 $diff = 24*60*60;
               }
               if ($f[2] == "hours")
               {
                 $diff = 60*60;
               }
               if ($f[2] == "minutes")
               {
                 $diff = 60;
               }
               if ($f[2] == "seconds")
               {
                 $diff = 1;
               }
               
               $diff1 =  ($date ->sec)-($f[1]*$diff);
              
               echo '<br/>';

               $end = new MongoDate($diff1);
               
               $final = array_merge($final,array($arr_queryD[$r-1] => array('$lt' => $date,'$gte' => $end)));
           }
           else
           {
           $final = array_merge($final,array($arr_queryD[$r-1] => array('$lt' => new MongoDate(strtotime($arr_queryD[$r+2])),'$gte' => new MongoDate(strtotime($arr_queryD[$r+1])))));
           }
          }
         else
         {
         
          $t1= $arr_queryD[$r+1];
         
          $t2= $arr_queryD[$r+2];
         
         $final = array_merge($final,array($arr_queryD[$r-1] => array('$lt' => $t2 , '$gte' => $t1)));
         }
       }
       if ($arr_queryD[$r] == '!:')
        {
         
          $t1= $arr_queryD[$r+1];
        
          $t2= $arr_queryD[$r+2];
         
         $final = array_merge($final,array($arr_queryD[$r-1] => array('$not' => (array('$lt' => $t2 , '$gte' => $t1)))));
       }
  }

return ($final);
}

$start = 0;
$k=0;
for ($t=1;$t<count($arr_mapper);$t = $t + 1)
{
        $new_arr = array(); 
  for($y=$start;$y<count($arr_reducer);$y=$y+1)
  {
    if (($arr_reducer[$y]==$arr_mapper[$t])&&($arr_reducer[$y-1]!="Avg"))
    {
            //echo "entered";
            if (($arr_reducer[$y-1]!='Sum') && ($arr_reducer[$y-1]!='Count') && ($arr_reducer[$y-1] !='Avg'))
            {
               echo " Result  " ;
               
               $r = array_slice($arr_reducer,$y,1);
               
               $arr = $r[0];
              
               $collection = $Log_Collection;
               $final = query($arr_queryD,$arr_mapper,$arr_reducer);
                           $cursor = $collection -> find($final,array($arr_mapper[0] => 1 , $arr => 1 ));
                           
                           foreach ($cursor as $doc) {
                                                      var_dump($arr_mapper[0]);
                                                      echo "   -   ";
                                                      var_dump($doc[$arr_mapper[0]])."  ";
                                                      //echo '<br/>';
                                                      var_dump($arr);
                                                      echo "   -   ";
                                                      var_dump($doc[$arr]);
                                                      //echo '<br/>';
                                                      echo '<br/>';
                                                      }
               $start = $y+1;
               break;
            }
            else
            {
      $k = $k + 1 ;
      mapReduce($k,array_merge($new_arr,array($arr_mapper[0]),array($arr_mapper[$t])),array_slice($arr_reducer,($y-1),2),$arr_queryD,$db,$Log_Collection_Name);
      $start = $y+1;
                        break;
                        }
    }
    if (($arr_reducer[$y]==$arr_mapper[$t])&&($arr_reducer[$y-1]=="Avg"))
    {
            //echo ("Average entered");
            $k = $k + 1 ;
            mapReduce1($k,array_merge($new_arr,array($arr_mapper[0]),array($arr_mapper[$t])),array_slice($arr_reducer,($y-1),2),$arr_queryD,$db , $Log_Collection_Name);
            $start = $y+1;
                        break;
     }
     
  }
}

} 
    if(isset($_POST['app_type']))
    { 

        $app_type = $_POST['app_type'];
        $user_id = $_POST['User_Id'];
        
        
        $App_Name = str_replace(" ","_7_7_",$app_type);
        
        $m = new MongoClient();
            
        $User_DB = $m->$user_id;
        
         
        $App_Collection = $User_DB->Apps;
        $cursor = $App_Collection->findOne(array("App_Name" => $App_Name));
       
        $App_Id = $cursor['App_Id'];
        
        
        $Tag_Collection_Name = $App_Id."_Tags";
        $Tags = array();
        $cursor1 = $User_DB->$Tag_Collection_Name->findOne(array("tags_Json" => array('$exists' => true)));
        $cursor2 = $User_DB->$Tag_Collection_Name->findOne(array("tags_Xml" => array('$exists' => true)));
        $cursor3 = $User_DB->$Tag_Collection_Name->findOne(array("tags_Access_Log" => array('$exists' => true)));
        $cursor4 = $User_DB->$Tag_Collection_Name->findOne(array("tags_Error_Log" => array('$exists' => true)));
        $cursor5 = $User_DB->$Tag_Collection_Name->findOne(array("tags_IIS_Log_File_Format" => array('$exists' => true)));
        $cursor6 = $User_DB->$Tag_Collection_Name->findOne(array("tags_W3C_Extended_Log_Format" => array('$exists' => true)));
        $cursor7 = $User_DB->$Tag_Collection_Name->findOne(array("tags_NCSA_Common_Log_Format" => array('$exists' => true))); 
        $cursor8 = $User_DB->$Tag_Collection_Name->findOne(array("tags" => array('$exists' => true)));

        $Tags_Json = $cursor1['tags_Json'];
        $Tags_Xml = $cursor2['tags_Xml'];
        $Tags_Access_Logs = $cursor3['tags_Access_Log'];
        $Tags_Error_Log = $cursor4['tags_Error_Log'];
        $Tags_IIS_Log_File_Format = $cursor5['tags_IIS_Log_File_Format'];
        $Tags_W3C_Extended_Log_Format = $cursor6['tags_W3C_Extended_Log_Format'];
        $Tags_NCSA_Common_Log_Format = $cursor7['tags_NCSA_Common_Log_Format'];
        $Tags = $cursor8['tags'];
        $Array = array();

        $Array[0] = $Tags_Json;
        $Array[1] = $Tags_Xml;
        $Array[2] = $Tags_Access_Logs;
        $Array[3] = $Tags_Error_Log;
        $Array[4] = $Tags_IIS_Log_File_Format;
        $Array[5] = $Tags_W3C_Extended_Log_Format;
        $Array[6] = $Tags_NCSA_Common_Log_Format;
        $Array[7] = $Tags;

        echo json_encode($Array);

    }

    if (isset($_POST['User_Id']))
      { 
       
        $User_Id = $_POST['User_Id'];
      }
    if (isset($_POST['set_app_type']))
      { 
       
        $app_type = $_POST['set_app_type'];
     }

    if (isset($_POST['query']))
    {
      $query1 = $_POST['query'];

      
      
      if (isset($_POST['set_app_type']))
      {
         
        if((preg_match('/Count/i',$query1))||(preg_match('/Avg/i',$query1))||(preg_match('/Sum/i',$query1)))
        {
          
          MapReduce_QueryBuilder($query1,$app_type,$User_Id);
        }
        else
        {
         
          Normal_QueryBuilder($query1,$app_type,$User_Id);
        }
      }
    }
    else
    {
      $query1= -1;      
      
      if (isset($_POST['set_app_type']))
      { 
          $User_Id = $_POST['User_Id'];
         $app_type = $_POST['set_app_type'];

        
          if((preg_match('/Count/i',$query1))||(preg_match('/Avg/i',$query1))||(preg_match('/Sum/i',$query1)))
          {
            
            MapReduce_QueryBuilder($query1,$app_type,$User_Id);
          }
          else
          {

            Normal_QueryBuilder($query1,$app_type,$User_Id);
          }
      }
    }

 ?>
