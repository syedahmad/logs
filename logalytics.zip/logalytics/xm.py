import xml.etree.ElementTree as ET
import xml.dom.minidom
import re
#tree = ET.parse('example.xml')
text = """
<log>
<record>
<date>2009-05-21T00:00:00</date>
<millis>1242878400161</millis>
<sequence>323</sequence>
<logger>com.ibm.is.auditing</logger>
<level>FINE</level>
<thread>51</thread>
<message>LOGIN (InformationServerSystemUser): UserID="InformationServerSystemUser",
Client="Server client", Origin="SwordIFS",
SessionID="34BADF15-ABA5-4FA9-AA7D-68D26402C2D6"</message>
<key>info.audit.session.LOGIN</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>InformationServerSystemUser</param>
<param>InformationServerSystemUser</param>
<param>Server client</param>
<param>SwordIFS</param>
<param>34BADF15-ABA5-4FA9-AA7D-68D26402C2D6</param>
</record>
<record>
<date>2009-05-21T00:00:04</date>
<millis>1242878404458</millis>
<sequence>324</sequence>
<logger>com.ibm.is.auditing</logger>
<level>FINE</level>
<thread>51</thread>
<message>LOGOUT (InformationServerSystemUser): UserID="InformationServerSystemUser",
Client="Server client", Origin="SwordIFS",
SessionID="34BADF15-ABA5-4FA9-AA7D-68D26402C2D6"</message>
<key>info.audit.session.LOGOUT</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>InformationServerSystemUser</param>
<param>InformationServerSystemUser</param>
<param>Server client</param>
<param>SwordIFS</param>
<param>34BADF15-ABA5-4FA9-AA7D-68D26402C2D6</param>
</record>
<record>
<date>2009-05-21T16:24:50</date>
<millis>1242937490614</millis>
<sequence>351</sequence>
<logger>com.ibm.is.auditing</logger>
<level>INFO</level>
<thread>46</thread>
<message>LOGIN (admin): UserID="admin", Client="Web Console", Origin="localhost",
SessionID="1C8D5CFD-269B-400F-8187-788D93681B09"</message>
<key>info.audit.session.LOGIN</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>admin</param>
<param>admin</param>
<param>Web Console</param>
<param>localhost</param>
<param>1C8D5CFD-269B-400F-8187-788D93681B09</param>
</record>
<record>
<date>2009-05-21T16:27:24</date>
<millis>1242937644348</millis>
<sequence>370</sequence>
<logger>com.ibm.is.auditing</logger>
<level>INFO</level>
<thread>46</thread>
<message>ADD_USER (admin): UserID="ppds1", LastName="PersonDS1",
FirstName="Project"</message>
<key>info.audit.user.ADD_USER</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>admin</param>
<param>ppds1</param>
<param>PersonDS1</param>
<param>Project</param>
</record>
<record>
<date>2009-05-21T16:27:24</date>
<millis>1242937644645</millis>
<sequence>371</sequence>
<logger>com.ibm.is.auditing</logger>
<level>INFO</level>
<thread>46</thread>
<message>ASSIGN_USER_ROLES (admin): UserIDs="ppds1", RoleIDs="SuiteUser"</message>
<key>info.audit.role.ASSIGN_USER_ROLES</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>admin</param>
<param>ppds1</param>
<param>SuiteUser</param>
</record>
<record>
<date>2009-05-21T16:27:24</date>
<millis>1242937644801</millis>
<sequence>372</sequence>
<logger>com.ibm.is.auditing</logger>
<level>INFO</level>
<thread>46</thread>
<message>ASSIGN_USER_ROLES (admin): UserIDs="ppds1", RoleIDs="DataStageAdmin,
DataStageUser"</message>
<key>info.audit.role.ASSIGN_USER_ROLES</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>admin</param>
<param>ppds1</param>
<param>DataStageAdmin, DataStageUser</param>
</record>
<record>
<date>2009-05-21T16:27:24</date>
<millis>1242937644973</millis>
<sequence>373</sequence>
<logger>com.ibm.is.auditing</logger>
<level>INFO</level>
<thread>46</thread>
<message>SET_CREDENTIAL (admin): UserID="ppds1"</message>
<key>info.audit.user.SET_CREDENTIAL</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>admin</param>
<param>ppds1</param>
</record>
<record>
<date>2009-05-21T16:27:53</date>
<millis>1242937673989</millis>
<sequence>375</sequence>
<logger>com.ibm.is.auditing</logger>
<level>INFO</level>
<thread>45</thread>
<message>LOGOUT (admin): UserID="admin", Client="Web Console", Origin="localhost",
SessionID="1C8D5CFD-269B-400F-8187-788D93681B09"</message>
<key>info.audit.session.LOGOUT</key>
<catalog>com.ascential.acs.auditing.server.impl.resources.StringData</catalog>
<param>admin</param>
<param>admin</param>
<param>Web Console</param>
<param>localhost</param>
<param>1C8D5CFD-269B-400F-8187-788D93681B09</param>
</record>
</log>"""

def check (t):
	s = 0
	for i in range (0,len(t)):
		if (t[i]=='<'):
			s= s+1
		if (t[i]=='>'):
			s=s-1
	if (s<0):
		while (s<0):
			t = t +'>'
			s = s+1
	return t


def start_correct(t):
	
	for i in range(0,len(t)):
		if (re.match('\<\w+.\w+[="]*\w+\"\>',t[i])):
			t[i]=t[i].split(' ',1)[0]+'>'
	return t

def end_correct (t):
	for i in range (0,len(t)):
		t[i]=t[i][:1]+ t[i][2:]
	return t

start = re.findall(r'\<\w+.\w*[="]*\w*\"*\>',text)
end = re.findall(r'\<[/]+\w+\>',text)
start1 = start_correct(start)
end1 = end_correct(end)


def node_end_correct(a,x):
	list1 = []
	alen = len(a)
	xlen = len(x)
	i=0
	j=0
	while (i<xlen):
		
		if (j==alen):
			break
		while (j<alen):
			if (list1!=[]):
				if (x[i]==list1[len(list1)-1]):
					list1.pop()
					i = i +1
					break
		list1.append(a[j])
		if (a[j]==x[i]):
			list1.pop()
			j = j +1
			i = i + 1
			break
		else :
			j = j+1
	
	for x1 in a[j:] :
		list1.append(x1)
	return list1
def node_start_correct(a,x):
	list1 = []
	alen = len(a)
	xlen = len(x)
	i=0
	j=0
	while (j<=alen):
		
		while (i<xlen):
			if (j==alen and list1==[]):
				j=j+1
				break
			if (list1!=[]):
				if (x[i]==list1[len(list1)-1]):
					
					list1.pop()
					i = i +1
					if (j==alen):
						j=j+1
						break
			list1.append(a[j])
			if (a[j]==x[i]):
				list1.pop()
				j = j +1
				i = i + 1
				break
			else :
				j = j+1
		
	list2 = x[i:]
	
	for x1 in list1 :
		list2.remove(x1)
	return list2

def number_check(text,start1,end1):
	s=0
	list1=[]
	
	if (len(start1)==len(end1)):
		if (re.search('^<data>',text)):
			return text
		else:
			
			for i in range(0,len(end1)):
				s3 = end1[i][:1]+'/'+end1[i][1:]
				s1 = text.find(s3)
				limit = text[:s1]
				if (limit.find(end1[i])==(-1)):
					text = end1[i] + text
					text = text + s3
			text = '<data>' + text + '</data>'
			
	elif (len(start1)<len(end1)):
		
		list1 = node_start_correct(start1,end1)
		s = 1
	else :
		list1 = node_end_correct(start1,end1)
	if (s==0):
		
		while (list1!=[]):
			
			s1 = list1.pop()
			text = text + s1[:1] + '/' + s1[1:]
	else:
		for i in range(0,len(list1)):
			text = list1[i] + text

	if (re.search('^<data>',text)):
		
		return text
	else:
		start = re.findall(r'\<\w+.\w*[="]*\w*\"*\>',text)
		end = re.findall(r'\<[/]+\w+\>',text)
		start1 = start_correct(start)
		end1 = end_correct(end)
		text = number_check(text,start1,end1)
	return text

def start_check(t,start1,end1):
	if (re.search('^<data>',t) or re.search('^\"*\w+\"*\<',t)):
		t=t
	elif (re.search('^[=]*["]*\w+\"\>',t) or re.search('^\w*\>',t)):
		t = t[t.index('<'):]
	elif (t[0]=='<' and t[len(t)-1]=='>'):
		if (len(start1)>len(end1)):
			t = '<data>' + t
			start1 = ['<data>'] +start1
		else:
			t = t + '</data>'
			end1 = end1 + ['<data>']
	else:
		t = t[t.index('<'):]

	t = end_check(t,start1,end1)
	return t

def end_check(t,start1,end1):
	if (re.search('</data>$',t)):
		t = t
	if (t[len(t)-1]=='>' and re.search('^<data>',t)):
		t = t
	if (re.search('\<\/*\w*$',t)):
		t = t[:t.rfind('>')+1]
	if (re.search('\w*.\=\"\w*\"*\/*$',t)):
		v = re.search('\w*.\=\"\w*\"*\/*$',t).group()
		if (v[len(v)-1]=='/'):
			t = t + '>'
		elif (v[len(v)-1]=='"' and v[len(v)-2]!='='):
			t = t +'/>'
		else:
			t = t + '"/>'
	if (re.search('\/$',t)):
		t = t + '>'
	else:
		t = t[:t.rfind('>')+1]
		
		t = number_check(t,start1,end1)
		
		return t

text = start_check(text,start1,end1)
root = ET.fromstring(text)
rough = ET.tostring(root,'utf-8')
reparsed = xml.dom.minidom.parseString(rough)
print reparsed.toprettyxml(indent="\t")	
