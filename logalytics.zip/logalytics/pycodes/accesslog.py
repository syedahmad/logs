import apachelog, sys,cStringIO,pika

# using the apache log library
list_dic=[]
# Format copied and pasted from Apache conf - use raw string + single quotes
connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='accesslog')

def callback(ch, method, properties, body):
    count = 0
    error = 0

    format = r'%h %l %u %t \"%r\" %s %O \"%{Referer}i\" \"%{User-Agent}i\"'

    p = apachelog.parser(format)

    for line in cStringIO.StringIO(body.decode('string_escape')):
        if line != "\n":
            try:

                count = count + 1
                #print count
                data = p.parse(line)
               
                #print "1"            
                
            except:
                error = 1
                #print count
                if count <= 5 and error == 1:
                    sys.stderr.write("Incorrect_Format")
                    sys.exit()
                sys.stderr.write("Unable to parse %s" % line)

    for line in cStringIO.StringIO(body.decode('string_escape')):
        if line != "\n":
            try:

                
                #print count
                data = p.parse(line)
               
                #print "1"
                
                Client_IP = data["%h"]
                User_Identity = data["%l"]
                User_Name = data["%u"]
                Time = data["%t"]
                Request_Line = data["%r"]
                Status_Code = data["%s"]
                Size_Returned = data["%O"]
                Referer = data["%{Referer}i"]
                User_Agent = data["%{User-Agent}i"]

                i = 0;
                
                while Request_Line[i]!= " ":
                    i = i + 1

                Method = Request_Line[0:i]

                i = i + 1
                j = i

                while Request_Line[i]!= " ":
                    i = i + 1

                URL = Request_Line[j:i]

                i = i + 1
                k = i

                Protocol = Request_Line[k:len(Request_Line)]

                lineDict = {'Client_IP':Client_IP,'User_Identity':User_Identity,'User_Name':User_Name,'Time':Time,'Method':Method,'URL':URL,'HTTP_Version':Protocol,'Status_Code':Status_Code,'Size_Returned':Size_Returned,'Referer':Referer,'User_Agent':User_Agent, 'Line': line[:-1]}
                list_dic.append(lineDict)

            except:
                sys.stderr.write("Unable to parse %s" % line)

    print list_dic            
    exit()

channel.basic_consume(callback,
                      queue='accesslog',
                      no_ack=True)

channel.start_consuming()
