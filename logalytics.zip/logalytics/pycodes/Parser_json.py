import json, re,sys,pika


def check1(a):

	if (a<0):
		a=10000
	return a


def ending_correct(testVar):

	demo = testVar
	if (end == ','):
		testVar= testVar[:len(testVar)-1]
		demo = testVar
	if (re.search('\:\"\w+$',testVar)):		
		testVar = testVar + '"'
		demo = testVar
	if (re.search('\:\"*$',testVar)):
		testVar = testVar[:testVar.rfind(':')+1] + '""'
		demo = testVar
	if (re.search('[[,{]+\"\w*\"*$',testVar)):
		st = re.search('[[,{]+\"\w*\"*$',testVar).group()
		if (st[len(st)-1] == '"'):

			if (st[len(st)-2]!=',' and st[len(st)-2]!='[' and st[len(st)-2]!='{'):
				testVar = testVar + ':""'
				demo = testVar
			else :
				s = st[0]
				testVar = testVar[:testVar.rfind(s)+1]
				demo = testVar
		else :
			s = st[0]
			testVar = testVar[:testVar.rfind(s)]
			demo = testVar
	return demo

def check_brackets(x):
	global glob
	s=0
	s1=0
	for i in range(0,len(x)):
		if (x[i]=='{'):
			s=s+1
		if (x[i]=='}'):
			s=s-1
		if (x[i]=='['):

			s1=s1+1
		if (x[i]==']'):
			s1=s1-1
		if (s<0):
			glob = 1
	while (s<0):		
		x=x[:len(x)-1]
		s=s+1
	while (s1<0):		
		glob = 2
		new_string = x[:x.find(']')+1]				
		if (new_string[0]=='{' or re.search('^\,\{',new_string) or re.search('^\}\,',new_string)) :			
			new_string = '['+new_string[new_string.find('{'):]			
		elif(re.search('^\,[^{]',new_string)):
			new_string = '['+'{' +new_string[1:]
		elif(re.search('^\}\[^,]',new_string)):
			new_string = '['+'{' +new_string[0:]
		elif (new_string[0]==':' or re.search('^\"\w+\"',new_string)):			
			a1=new_string.find(',')
			a2=new_string.find('{')
			if (a1<a2):
				if (new_string[a1+1]=='{'):
					new_string = '['+ new_string[a1+1:]
				else:
					new_string = '[' +'{' +new_string[a1+1:]
			else :
					new_string = '['+new_string[a2+1:]			
		elif (re.search('^\"\w+\"\:',new_string)):
			new_string = '['+'{'+new_string
		else :
			a1=new_string.find(',')
			a2=new_string.find('{')
			if (a1<a2):
				if (new_string[a1+1]=='{'):
					new_string = '['+new_string[a1+1:]
				else:
					new_string = '[' +'{' +new_string[a1+1:]
			else :
				new_string = '['+new_string[a2+1:]
		x=new_string		
		s1=s1+1		
	return x

def start_correct(testVar):
	global glob
	if (glob==2):

		testVar = testVar1 + testVar[testVar.rindex(']')+1:]

	

	if (start == ':' or start == ',' or start =='{' or re.search('^\"\:',testVar) or re.search('^\"\w+\"',testVar) or re.search('^\"\,',testVar)):
		a1=testVar.find(',')
		a2=testVar.find('{')
		if (a1<a2):

			testVar = '{' + testVar[a1+1:]
		else:
			testVar = '{' + testVar[a2+1:]
	 #testVar = check_brackets(testVar)
	elif (re.search('^\"\w+\"\:',testVar)) :
		testVar = '{' + testVar
	#testVar = check_brackets(testVar)
	elif (start=='['):
		testVar = '{"unnamed_entity":' + testVar
	else:
		a1=testVar.find(',')
		a2=testVar.find('{')
		a3=testVar.find('[')
		a1=check1(a1)
		a2=check1(a2)
		a3=check1(a3)
		if (a1<a2):

			if (a3<a1):

				testVar = '{"unnamed_entity":'+testVar[a3:]
			else:
				if (testVar[a1+1]=='{'):

					testVar = testVar[a1+1:]
				else:
					testVar = '{' + testVar[a1+1:]
		else:
		 	if (a3<a2):
			 	testVar = '{"unnamed_entity":'+testVar[a3:]
		 	else:
			 	testVar = testVar[a2:]
	return testVar		 	

def final_call(testVar):
	a = ""
	x=testVar
	for i in range (0,len(x)):

		if (x[i]=='{'):

			a = a + '}'
		if (x[i]=='}' or x[i]==']'):
			a = a[:len(a)-1]
		if (x[i]=='['):
			a = a + ']'
	if (len(a)!=0):
		i = len(a)
		while (i!=0):
			x = x + a[i-1]
			i = i-1
	return x

end=''
glob =0

connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='json')

def callback(ch, method, properties, body):
	testVar =body
	start = testVar[0]
	end = testVar[len(testVar)-1]
	testVar1 = check_brackets(testVar)
	testVar = ending_correct(testVar)
	testVar= start_correct(testVar)
	testVar = final_call(testVar)

	json_input = testVar


	try:
		decoded = json.loads(json_input)

	# pretty printing of json-formatted string
		print json.dumps(decoded, sort_keys=True, indent=4)

	except (ValueError, KeyError, TypeError):
		sys.stderr.write("JSON format error")
	exit()	


channel.basic_consume(callback,
                      queue='json',
                      no_ack=True)

channel.start_consuming()
