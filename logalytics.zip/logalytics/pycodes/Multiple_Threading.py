#!/usr/bin/python

import os, sys, zipfile, traceback, glob, time, requests
import threading
import time

class myThread (threading.Thread):
	def __init__(self, PathToFolder):
		threading.Thread.__init__(self)
        
		self.PathToFolder = PathToFolder
		
	def run(self):
		
		threadLock.acquire()
		
		fetchFiles(self.PathToFolder)
		
		threadLock.release()
		
		return
    
def fetchFiles(PathToFolder):
	
	formats = ['.ar','.iso','.tar','.bz2','.gz','.rar','.zip','.apk','.tar.gz','.tar.bz2','tar.xz','.xz','.jar','.sda','.rk','.tlz','.tar.Z','.Z']
	countr_1 = 0								#counters for counting number of unzipped and zipped files originally
	countr_2 = 0
	global del_files
	FileNames = []
	
	#time.sleep(delay)
	
	for dirPath, dirNames, fileNames in os.walk(PathToFolder):
		
		for item in fileNames:    

			FilesPath = os.path.join(dirPath,item)
			#print item
			#print FilesPath
			fileName, fileExtension = os.path.splitext(FilesPath)
			#print fileExtension
			
			FileNames.append(item)
			
		# Zipping the Unzipped files .
				
			if not (fileExtension in formats):
									
				file_zip = zipfile.ZipFile(os.path.join(dirPath,"%s.zip"% item), "w", zipfile.ZIP_DEFLATED)
				try:
					file_zip.write(os.path.join(dirPath,item), arcname= item)
				finally:
					file_zip.close()
					countr_1 += 1          # counting intial unzipped files
					
					
					
				if (del_files == 'y'):
					
					os.remove(FilesPath)
			
			# Now, Uploading all the zipped ones	
				
				t = "%s.zip"% item  #Path to the Zipped files
				ZipFilesPath = os.path.join(dirPath,t)		
				
				r = requests.post('http://localhost/logalytics/index.php/upload_file', files={'file': open(ZipFilesPath, 'rb')}) #sending file to php 
				
								
			elif (fileExtension in formats):
			
				r = requests.post('http://localhost/logalytics/index.php/upload_file', files={'file': open(FilesPath, 'rb')})
				countr_2 += 1               #counting intial zipped files
					#print r.text	
	
		#print '\n',len(FileNames), 'file(s) were found in searched folder %s' % PathToFolder, '\n'  #print FileNames,'\n'
		
		#print 'out of which Initially, %s were already zipped'% countr_2, 'and', '%s were not'% countr_1,'\n'
						
						

threadLock = threading.Lock()
#threads = []

	# Take input of all folders in a string separated by a comma each	


folder_path = raw_input('Provide the path of the logs folders separated by comma : ')

del_files = raw_input('You want to REMOVE the original files ? y OR n : ')

if (del_files == 'n'):

	print '\n','Alright then',"\n",'  You will keep the original files with you'

print "\n","Processing ......","\n"

Individual_folders = folder_path.split(',')

# Create new threads

while True :
	
	time.sleep(2)
	
	for each in Individual_folders :
	
		thread1 = myThread(each)
	
		
	#Start new Threads
		thread1.start()
				
