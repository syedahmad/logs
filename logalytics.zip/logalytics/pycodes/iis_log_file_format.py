import sys, cStringIO,pika
connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='iis_log')

def callback(ch, method, properties, body):
    i = 0
    count = 0
    error = 0
    fieldLine = "Client_IP_Address User_Name Date Time Service_and_Instance Server_Name Server_IP_Address Time_Taken Client_Bytes_Sent Server_Bytes_Sent Service_Status_Code Windows_Status_Code Request_Type Target_Of_Operation Parameters" 
    fieldsList = []
    fieldsList = fieldLine.split()
    list_dic=[]


    for line in cStringIO.StringIO(body.decode('string_escape')):

        if count == 5:
            break

        try:
            if line!= "\n":
                    count = count + 1
                    lineList = line.split(',')[:-1]
                #print lineList
                    lineDict = {}
                    if lineList:
                    #print "2"
                        trash = None #do nothing
                    else:
                    #print "3"
                        error = 1
                        if count <= 5 and error == 1:
                            sys.stderr.write("Incorrect_Format") 
                            break          

            else:
                trash = None #do nothing 

        except:
            error = 1
            
            if count <= 5 and error == 1:

                sys.stderr.write("Incorrect_Format") 
                break               
            sys.stderr.write("Unable to parse %s" % line)

    if error:
        exit()

    for line in cStringIO.StringIO(body.decode('string_escape')):

        try:
            if line!= "\n":
                    lineList = line.split(',')[:-1]
                #print lineList
                    lineDict = {}
                    
                    lineDict[fieldsList[i]] = str(lineList[i])
                    i=i+1

                    while i < len(lineList):
                        lineDict[fieldsList[i]] = str(lineList[i])[1:]
                        i = i + 1

                    i = 0 

                    lineDict["Line"] = line[:-1]
                    
                    list_dic.append(lineDict)
                

            else:
                trash = None #do nothing 

        except:
            
            sys.stderr.write("Unable to parse %s" % line)


    print list_dic
    exit()

channel.basic_consume(callback,
                      queue='iis_log',
                      no_ack=True)

channel.start_consuming()
