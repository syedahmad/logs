import xml.etree.ElementTree as ET
import xml.dom.minidom
import re,sys,pika
#tree = ET.parse('example.xml')


def check (t):
	 
	s = 0
	for i in range (0,len(t)):
		  
		if (t[i]=='<'):
			   
			s= s+1
		if (t[i]=='>'):
			s=s-1
	if (s<0):
		while (s<0):
			t = t +'>'
			s = s+1
	return t 


		   
def start_correct(t):
	for i in range(0,len(t)):
		if (re.match('\<\w+.\w+[="]*\w+\"\>',t[i])):
		   
			t[i]=t[i].split(' ',1)[0]+'>'
	return t 

def end_correct (t):
	for i in range (0,len(t)):
		  
		t[i]=t[i][:1]+ t[i][2:]
	return t


def node_end_correct(a,x):
	list1 = []
	alen = len(a)
	xlen = len(x)
	i=0
	j=0
	while (i<xlen):		
		if (j==alen):
			break
		while (j<alen):
			if (list1!=[]):
				if (x[i]==list1[len(list1)-1]):
					list1.pop()
					i = i +1
					break
			list1.append(a[j])
			if (a[j]==x[i]):
				list1.pop()
				j = j +1
				i = i + 1
				break
			else :
				j = j+1
	for x1 in a[j:] : 
		list1.append(x1)
	return list1
                
def node_start_correct(a,x):
	list1 = []
	alen = len(a)
	xlen = len(x)
	i=0
	j=0
	while (j<=alen):		
		while (i<xlen):
			if (j==alen and list1==[]):
				j=j+1
				break
			if (list1!=[]):
				if (x[i]==list1[len(list1)-1]):					
					list1.pop()
					i = i +1
					if (j==alen):
						j=j+1
						break
			list1.append(a[j])
			if (a[j]==x[i]):
				list1.pop()
				j = j +1
				i = i + 1
				break
			else :
				j = j+1		
	list2 = x[i:]	
	for x1 in list1 :
		list2.remove(x1)
	return list2

def number_check(text,start1,end1):
	s=0
	list1=[]	
	if (len(start1)==len(end1)):
		if (re.search('^<data>',text)):
			return text
		else:			
			for i in range(0,len(end1)):
				s3 = end1[i][:1]+'/'+end1[i][1:]
				s1 = text.find(s3)
				limit = text[:s1]
				if (limit.find(end1[i])==(-1)):
					text = end1[i] + text 
					text = text + s3
			text = '<data>' + text + '</data>'			
	elif (len(start1)<len(end1)):		
		list1 = node_start_correct(start1,end1)
		s = 1
	else :
		list1 = node_end_correct(start1,end1)
	if (s==0): 		
		while (list1!=[]):			
			s1 = list1.pop()
			text = text +  s1[:1] + '/' + s1[1:]
	else: 
		for i in range(0,len(list1)):
			text = list1[i] + text

	if (re.search('^<data>',text)):		
		return text
	else: 
		start = re.findall(r'\<\w+.\w*[="]*\w*\"*\>',text)
		end = re.findall(r'\<[/]+\w+\>',text)
		start1 = start_correct(start)
		end1 = end_correct(end)
		text = number_check(text,start1,end1)
	return text

def start_check(t,start1,end1):
	if (re.search('^<data>',t) or re.search('^\"*\w+\"*\<',t)):
		t=t
	elif (re.search('^[=]*["]*\w+\"\>',t) or re.search('^\w*\>',t)):
			   
		t = t[t.index('<'):]
	elif (t[0]=='<' and t[len(t)-1]=='>'):
		   
			if (len(start1)>len(end1)):
				t = '<data>' + t 
				start1 = ['<data>'] +start1
			else:
				t = t + '</data>'
				end1 = end1 + ['<data>']
	else:
			   
		t = t[t.index('<'):]

	t = end_check(t,start1,end1)
	return t

def end_check(t,start1,end1):
	if (re.search('</data>$',t)):
		t = t
	if (t[len(t)-1]=='>' and re.search('^<data>',t)):
		t = t
	if (re.search('\<\/*\w*$',t)):
		t = t[:t.rfind('>')+1]
	if (re.search('\w*.\=\"\w*\"*\/*$',t)):		
		v = re.search('\w*.\=\"\w*\"*\/*$',t).group()
		if (v[len(v)-1]=='/'):
			t = t + '>'
		elif (v[len(v)-1]=='"' and v[len(v)-2]!='='):
			t = t +'/>'
		else:
			t = t + '"/>'
	if (re.search('\/$',t)):
            t = t + '>'
	else:
		t = t[:t.rfind('>')+1]		
		t = number_check(t,start1,end1) 		
		return t     	 


connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='xml')


def callback(ch, method, properties, body):
	text = body
	start = re.findall(r'\<\w+.\w*[="]*\w*\"*\>',text)
	end = re.findall(r'\<[/]+\w+\>',text)
	start1 = start_correct(start)
	end1 = end_correct(end)
	text = start_check(text,start1,end1)
	root = ET.fromstring(text)
	rough = ET.tostring(root,'utf-8')
	reparsed = xml.dom.minidom.parseString(rough)
	print reparsed.toprettyxml(indent="\t")
	exit()	

channel.basic_consume(callback,
                      queue='xml',
                      no_ack=True)

channel.start_consuming()
