import sys,cStringIO,pika

import apachelogparser as a
list_dic=[]
connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='errorlog')

def callback(ch, method, properties, body):
    alog = a.ApacheErrorLogParser()
    
    for line in cStringIO.StringIO(body.decode('string_escape')):
    
        try:
        
            alog.parse(line)

            date = alog.date

            errorType = alog.type

            description = alog.description[1:]

            clientIp = alog.client_ip

            lineDict = {'date':date,'errorType':errorType,'description':description,'clientIp':clientIp, 'Line': line}        

       
            list_dic.append(lineDict)
        
    
        except:
       
            if line!= "\n":
            
                sys.stderr.write("Unable to parse %s" % line)


    print list_dic
    exit()

channel.basic_consume(callback,
                      queue='errorlog',
                      no_ack=True)

channel.start_consuming() 
