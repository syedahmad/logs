#!/usr/bin/env python
from __future__ import generators
import pika,json,zipfile,os.path,os,pymongo,datetime,random
from pymongo import MongoClient
import subprocess, sys,shlex,ast,urllib2,cStringIO,gzip,errno,httplib
from datetime import datetime
from xml.etree import cElementTree as ET
from ast import literal_eval
from socket import error as SocketError

def config_extract(line):
    contr = 0
    for word in line:
        contr += 1
        if word == "=" :
            break
    
    return line[contr]

r = open("locations.conf","r")
x = r.readlines()

# code to get the locations of the parsers

xml_loc = config_extract(x[1].split())
json_loc =  config_extract(x[4].split())
access_loc = config_extract(x[7].split())
error_loc = config_extract(x[10].split())
iis_loc = config_extract(x[13].split())
w3_loc = config_extract(x[16].split())
ncsa_loc = config_extract(x[19].split())
host = config_extract(x[22].split())


records=[]
def give_element(root): # returns the dictionary of the processed xml documents i.e. tags to value mapping of logs
    if list(root)==[]:
        return {root.tag:root.text,'Line':'<'+root.tag+'>'+root.text+'</'+root.tag+'>'}
    else:
        global records
        lis={}
        for i in list(root):
            a=give_element(i)
            lis=dict(a.items() + lis.items())
        records.append(lis)
        return {}

def typeNameGen(n): # return a list of parsers class objects randomly choosen
    types = Type.__subclasses__()
    for i in range(n):
        yield random.choice(types).__name__

def rabbit(queue,location,data):
    connection = pika.BlockingConnection(pika.ConnectionParameters(
        host=host))
    channel = connection.channel()

    channel.queue_declare(queue=queue)

    channel.basic_publish(exchange='',
                      routing_key=queue,
                      body=data)        
    connection.close()
    result=subprocess.Popen(shlex.split(r"python %r" %(location,)), stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)        
    return result.communicate()

def db_add_logs(type_name,list_dic,collection,collection1,all_tags,error_log):
        post=collection.find_one({'tags_'+type_name:{'$exists': True}})
        post_id=post['_id']
        db_tags=post['tags_'+type_name]
        for dictionary in list_dic:                            
            if len(dictionary):
                error_log=0
                dictionary['Time_Of_Arrival']=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                dictionary['Log_Type']=type_name
                collection1.insert(dictionary)
                keys_tag=dictionary.keys()
                for tag in keys_tag:
                    if tag not in db_tags:
                        db_tags.append(tag)
                        all_tags.append(tag)
        collection.update({'_id':post_id},{"$set":{'tags_'+type_name:db_tags}})
        return all_tags,error_log

def process_data(collection,collection1,collection2,fn,file_data):
            types = [ TypeFactory.createType(i) for i in set(typeNameGen(25))]
            error_log=1
            post_all=collection.find_one({'tags':{'$exists': True}})
            post_id_all=post_all['_id']
            all_tags=post_all['tags']
            for i in types:
                if type(i).__name__!= 'Error_Log':
                    comm_result=i.parse(file_data)
                    #print comm_result[0],type(i)
                    if(len(comm_result[0]) and comm_result[0][0]=='['):
                        all_tags,error_log=db_add_logs(type(i).__name__,eval(comm_result[0]),collection,collection1,all_tags,error_log)
                        
                    elif len(comm_result[0]) and type(i).__name__=="Xml" and comm_result[0][0]!='[':
                        global records
                        give_element(ET.fromstring(comm_result[0]))
                        all_tags,error_log=db_add_logs(type(i).__name__,records,collection,collection1,all_tags,error_log)
                        records=[]

                    elif len(comm_result[0]) and type(i).__name__=="Json" and comm_result[0][0]!='[':
                        rec=eval(comm_result[0])
                        all_tags,error_log=db_add_logs(type(i).__name__,rec,collection,collection1,all_tags,error_log)
                
                    else:
                        pass            
            if error_log == 1:
                comm_result=Error_Log().parse(file_data)
                #print comm_result[0],'Error_Log'
                all_tags,error_log=db_add_logs('Error_Log',eval(comm_result[0]),collection,collection1,all_tags,error_log)

            collection.update({'_id':post_id_all},{"$set":{'tags':all_tags}})
            collection2.update({'Name':fn,'Status':'unprocessed'},{"$set":{'Status':'processed'}})

class TypeFactory:
    factories = {}
    def addFactory(id, typeFactory):
        TypeFactory.factories.put[id] = typeFactory
    addFactory = staticmethod(addFactory)

    def createType(id):
        if not TypeFactory.factories.has_key(id):
            TypeFactory.factories[id] = \
              eval(id + '.Factory()')       # or use TypeFactory.addFactory( id, eval(id + '.Factory()'))
        return TypeFactory.factories[id].create()
    createType = staticmethod(createType)

class Type(object): pass

class Json(Type):
    def parse(self,data): # puts the data in the rabbitmq named json and gets the parsed result in stdout
        return rabbit('json',json_loc,data)
            
    class Factory:
        def create(self): return Json()

class Xml(Type):
    def parse(self,data): # puts the data in the rabbitmq named xml and gets the parsed result in stdout
        return rabbit('xml',xml_loc,data)
            
    class Factory:
        def create(self): return Xml()

class Access_Log(Type):
    def parse(self,data): # puts the data in the rabbitmq named accesslog and gets the parsed result in stdout
        return rabbit('accesslog',access_loc,data)
            
    class Factory:
        def create(self): return Access_Log()

class Error_Log(Type):
    def parse(self,data): # puts the data in the rabbitmq named errorlog and gets the parsed result in stdout
        return rabbit('errorlog',error_loc,data)
            
    class Factory:
        def create(self): return Error_Log()

class IIS_Log_File_Format(Type): #IIS 6
    def parse(self,data): # puts the data in the rabbitmq named iis_log and gets the parsed result in stdout
        return rabbit('iis_log',iis_loc,data)
            
    class Factory:
        def create(self): return IIS_Log_File_Format()

class W3C_Extended_Log_Format(Type): #IIS 7 and above
    def parse(self,data): # puts the data in the rabbitmq named w3c_iis_log and gets the parsed result in stdout
        return rabbit('w3c_iis_log',w3_loc,data)
            
    class Factory:
        def create(self): return W3C_Extended_Log_Format()

class NCSA_Common_Log_Format(Type):
    def parse(self,data): # puts the data in the rabbitmq named ncsa and gets the parsed result in stdout
        return rabbit('ncsa',ncsa_loc,data)
            
    class Factory:
        def create(self): return NCSA_Common_Log_Format()  

connection = pika.BlockingConnection(pika.ConnectionParameters(
        host=host))
channel = connection.channel()

channel.queue_declare(queue='hello')

print ' [*] Waiting for messages. To exit press CTRL+C'


def callback(ch, method, properties, body):

    info=json.loads(body)
    filename = info['filename']
    App_Id = info['App_Id']
    User_Id = info['User_Id']
    client = MongoClient(host, 27017)
    db = client[User_Id]
    tag_col='%s_Tags' % (App_Id,)
    log_col='%s_Logs' % (App_Id,)
    file_col='%s_Files' % (App_Id,)
    collection = db[tag_col]
    collection1=db[log_col]
    collection2=db[file_col]
    print filename
    try:
        remotezip = urllib2.urlopen(filename)
        zipinmemory = cStringIO.StringIO(remotezip.read())
        if zipfile.is_zipfile(zipinmemory):
            zip = zipfile.ZipFile(zipinmemory)
            for fn in zip.namelist():
                    file_data = zip.read(fn)
                    process_data(collection,collection1,collection2,filename,file_data)
        else:
            remotezip = urllib2.urlopen(filename)
            zipinmemory = cStringIO.StringIO(remotezip.read())
            f = gzip.GzipFile(fileobj=zipinmemory)
            file_data = f.read()
            process_data(collection,collection1,collection2,filename,file_data)
    except urllib2.HTTPError, e:
        print 'HTTPError = ' + str(e.code)
    except urllib2.URLError, e:
        print 'URLError = ' + str(e.reason)
    except httplib.HTTPException, e:
        print 'HTTPException'
    except Exception:
        import traceback
        print 'generic exception: ' + traceback.format_exc()
    except SocketError as e:
        if e.errno != errno.ECONNRESET:
            raise    
    

channel.basic_consume(callback,
                      queue='hello',
                      no_ack=True)

channel.start_consuming()
