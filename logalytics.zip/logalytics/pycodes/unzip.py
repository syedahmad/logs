"""import zipfile
import os.path
import os
def unzip(path):
    zfile = zipfile.ZipFile(path)
    for name in zfile.namelist():
        (dirname, filename) = os.path.split(name)
        fileName, fileExtension = os.path.splitext(filename)
        if filename == '':
            # directory
            if not os.path.exists(dirname):
                os.mkdir(dirname)
        else:
            # file
            fd = open(name, 'w')
            fd.write(zfile.read(name))
            if fileExtension=='.json':
                import Parser_json
            elif fileExtension=='.xml':
                import Parser_xml
            elif fileExtension=='.log':
                import Apache
            fd.close()
    zfile.close()
unzip('https://s3.amazonaws.com/bucket_A2337F02-904D-ECED-5B44-C1372514A230/151ef552-6007-4438-94e9-cd493c280d5f/error.log.zip')

import urllib2, cStringIO, zipfile

try:
    remotezip = urllib2.urlopen('https://s3.amazonaws.com/bucket_A2337F02-904D-ECED-5B44-C1372514A230/151ef552-6007-4438-94e9-cd493c280d5f/error.log.zip')
    zipinmemory = cStringIO.StringIO(remotezip.read())
    zip = zipfile.ZipFile(zipinmemory)
    for fn in zip.namelist():
        
            ranks_data = zip.read(fn)
            for line in ranks_data.split("\n"):
                print line
except urllib2.HTTPError:
    pass  

from pymongo import MongoClient
User_Id = "A2337F02-904D-ECED-5B44-C1372514A230"
App_Id = "151ef552-6007-4438-94e9-cd493c280d5f"

client = MongoClient('localhost', 27017)
db = client[User_Id]
a='151ef552-6007-4438-94e9-cd493c280d5f_Tags'
b='151ef552-6007-4438-94e9-cd493c280d5f_Logs'
c='151ef552-6007-4438-94e9-cd493c280d5f_Files'
collection = db[a] #% (App_Id,)
collection1=db[b] #% (App_Id,)
collection2=db[c] #% (App_Id,)
collection1.insert({'a':1,'b':2})    """


"""

import zipfile
zfilename = "/var/www/logalytics/loganalytics.jar"
if zipfile.is_zipfile(zfilename):
    print "%s is a valid zip file" % zfilename
else:
    print "%s is not a valid zip file" % zfilename
print '-'*40

zfile = zipfile.ZipFile( zfilename, "r" )

zfile.printdir()
print '-'*40

for info in zfile.infolist():
    fname = info.filename

    data = zfile.read(fname)


 #   if fname.endswith(".txt"):
#        print "These are the contents of %s:" % fname
    print data


    filename = fname
    fout = open(filename, "w")
    fout.write(data)
    fout.close()
    print "New file created --> %s" % filename
    print '-'*40
"""
import gzip,urllib2,cStringIO
remotezip = urllib2.urlopen('https://s3.amazonaws.com/bucket_2D76D826-7BFB-18C1-96CE-14B4C89E96E0/6fb0ca24-dec6-46ac-90d7-9d7826075c18/access.log.tar.gz')
zipinmemory = cStringIO.StringIO(remotezip.read())
f = gzip.GzipFile(fileobj=zipinmemory)
file_content = f.read()
print file_content,type(file_content)
f.close()

