import sys, cStringIO,pika
list_dic=[]
connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='w3c_iis_log')

def callback(ch, method, properties, body):
    i = 0
    count = 0

    for line in cStringIO.StringIO(body.decode('string_escape')):

        try:
            if line!= "\n":
                count = count + 1

                if count == 1:      #the first line of the iis w3c log file        
                    lineList = line.split(' ',1)
                    if str(lineList[0]) != "#Software:":
                        sys.stderr.write("Incorrect_Formata")

                        break
                    software = str(lineList[1])
                   

                elif count == 2:      #the second line of the iis w3c log file        
                    lineList = line.split(' ',1)
                    if str(lineList[0]) != "#Version:":
                        sys.stderr.write("Incorrect_Formatb")
                        break
                    version = str(lineList[1])
                    

                elif count == 3:      #the third line of the iis w3c log file        
                    lineList = line.split(' ',1)
                    if str(lineList[0]) != "#Date:":
                        sys.stderr.write("Incorrect_Formatc")
                        break
                    date = str(lineList[1])
                    
                elif count == 4:      #the fourth line of the iis w3c log file        
                    lineList = line.split()
                    if str(lineList[0]) != "#Fields:":
                        sys.stderr.write("Incorrect_Formatd")
                        break
                    fields = []
                    fields = lineList[1:]
                    

                else:
                    lineList = line.split()

                    lineDict = {}

                    while i < len(lineList):
                        lineDict[fields[i]] = lineList[i]
                        i = i + 1

                    i = 0 

                    lineDict["Line"] = line[:-1]

                    list_dic.append(lineDict)

            else:
                trash = None #do nothing 

        except:            
            sys.stderr.write("Unable to parse %s" % line)

    print list_dic
    exit()

channel.basic_consume(callback,
                      queue='w3c_iis_log',
                      no_ack=True)

channel.start_consuming()
