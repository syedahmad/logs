import sys, cStringIO,pika,apachelog

def __list_to_string__(list_line): 
                                                          #Converts a list to string, 
            return_str = str()                            #for example converts ['Sat', 'Aug', '12', '04:05:51', '2006']
            for i in list_line:                           #to 'Sat Aug 12 04:05:49 2006'
                return_str += " " + i
            return return_str

connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()

channel.queue_declare(queue='ncsa')

def callback(ch, method, properties, body):
    i = 0
    count = 0
    error = 0
    fieldLine = "Client_IP_Address Remote_Log_Name User_Name Time Method URL HTTP_Version Service_Status_Code Bytes_Sent" 
    fieldsList = []
    list_dic=[]
    fieldsList = fieldLine.split()
    format = r'%h %l %u %t \"%r\" %>s %b'

    p = apachelog.parser(format)
    for line in cStringIO.StringIO(body.decode('string_escape')):
        if line != "\n":
            try:

                count = count + 1

                data = p.parse(line)
                #print data

            except:
                error = 1
                if count <= 5 and error == 1:
                    sys.stderr.write("Incorrect_Format")
                    sys.exit()
                if count > 5:
                    break

                sys.stderr.write("Unable to parse %s" % line)


    for line in cStringIO.StringIO(body.decode('string_escape')):

        try:
            if line!= "\n":
            
                lineList = line.split()
                
                lineDict = {}

                while i<3:
                    lineDict[fieldsList[i]] = str(lineList[i])
                    i = i + 1

                lineDict[fieldsList[i]] = __list_to_string__(lineList[i:i+2])[2:-1]
                i = i + 1
                lineDict[fieldsList[i]] = str(lineList[i+1])[1:]
                i = i + 1

                while i < len(fieldsList):
                    lineDict[fieldsList[i]] = str(lineList[i+1])
                    i = i + 1

                i = 0 

                lineDict["HTTP_Version"] = lineDict["HTTP_Version"][:-1]
                lineDict["Line"] = line[:-1]
                list_dic.append(lineDict)

                
            else:
                trash = None #do nothing 

        except:

            sys.stderr.write("Unable to parse %s" % line)

    print list_dic
    exit()

channel.basic_consume(callback,
                      queue='ncsa',
                      no_ack=True)

channel.start_consuming()
