from boto.s3.connection import S3Connection, Bucket, Key,OrdinaryCallingFormat
from pymongo import MongoClient
import datetime,smtplib,pika,json
from dateutil.relativedelta import relativedelta
from dateutil import parser
from email.mime.text import MIMEText 

grace=-5

def config_extract(line):
    contr = 0
    for word in line:
        contr += 1
        if word == "=" :
            break
    
    return line[contr]

r = open("locations.conf","r")
x = r.readlines()           

host = config_extract(x[22].split())

client = MongoClient(host, 27017)

AWS_ACCESS_KEY = config_extract(x[25].split())
AWS_SECERET_KEY = config_extract(x[28].split())

def email(Email_Id,msg,subject):
	headers = "\r\n".join(["from: " + "it@semusi.com",
				                    "subject: " + subject,
				                    "to: " + Email_Id,
				                    "mime-version: 1.0",
				                    "content-type: text/html"])

	# body_of_email can be plaintext or html!                    
	content = headers + "\r\n\r\n" + msg
	server = smtplib.SMTP('smtp.sendgrid.net', 587)
	server.starttls()
	#Next, log in to the server
	server.login("it@semusi.com", "pass@word1.")
	server.sendmail("it@semusi.com", Email_Id,content)


users=client.Admin_DB.Users.find()

for user in users:
	User_Id = user["User_Id"]
	db = client[User_Id]
	app_col=db['Apps']
	apps=app_col.find()
	if user.get('Pac_Start_Date'):
		exp = parser.parse(user.get('Pac_Start_Date'))+ relativedelta( months = +6 )
		today= datetime.datetime.now()	#.strftime('%Y-%m-%d %H:%M:%S')					
		if (exp-today).days == 1 :
			email(user['Email_Id'],'logs will be removed on package expiry i.e. tomorrow','package renew notification')

		elif (exp-today).days == grace :
			for app in apps:
				App_Id = app['App_Id']
				log_col='%s_Logs' % (App_Id,)
				file_col='%s_Files' % (App_Id,)
				tag_col='%s_Tags' % (App_Id,)
				db[log_col].drop()
				db[file_col].drop()
				db[tag_col].drop()
			app_col.remove({})
	
	for app in apps:
			App_Id = app['App_Id']
			log_col='%s_Logs' % (App_Id,)
			file_col='%s_Files' % (App_Id,)
			collection1=db[log_col]
			collection2=db[file_col]
			files=collection2.find()
			remove1=[]
			for file_info in files :
				if file_info.get('Time_Of_Arrival'):
					exp = parser.parse(file_info.get('Time_Of_Arrival'))+ relativedelta( months = +2 )
					today= datetime.datetime.now()	#.strftime('%Y-%m-%d %H:%M:%S')
					if (exp-today).days <= 0 :
						email(user['Email_Id'],'log file removed','log removal notification')

						remove1.append(file_info['_id'])

						S3_BUCKET_NAME='bucket_%s' % (User_Id,)
						conn = S3Connection(AWS_ACCESS_KEY, AWS_SECERET_KEY,calling_format=OrdinaryCallingFormat())
						b = Bucket(conn, S3_BUCKET_NAME)
						bucketListResultSet = b.list(prefix=App_Id)
						for i in b :
							if 'https://s3.amazonaws.com/'+S3_BUCKET_NAME+'/'+i.key == file_info['Name']:
								b.delete_key(i.key)
					else:
						if file_info['Status']=='unprocessed':
							connection = pika.BlockingConnection(pika.ConnectionParameters(host=host))
							channel = connection.channel()

							channel.queue_declare(queue='hello')

							channel.basic_publish(exchange='',
							                      routing_key='hello',
							                      body=json.dumps({"App_Id" : App_Id,"User_Id" : User_Id,"filename" :file_info['Name']}))
							connection.close()


			for ids in remove1 :
				collection2.remove({'_id':ids})

			logs = collection1.find()
			remove=[]
			for log in logs :
				if log.get('Time_Of_Arrival'):
					if type(log.get('Time_Of_Arrival')).__name__!='unicode':
						exp = parser.parse(log.get('Time_Of_Arrival').strftime('%Y-%m-%d %H:%M:%S'))+ relativedelta( days = +10 )
					else:
						exp = parser.parse(log.get('Time_Of_Arrival'))+ relativedelta( months = +2 )
					today= datetime.datetime.now()	#.strftime('%Y-%m-%d %H:%M:%S')					
					if (exp-today).days <= 0 :
						remove.append(log['_id'])
			for ids in remove :
				collection1.remove({'_id':ids})


						

