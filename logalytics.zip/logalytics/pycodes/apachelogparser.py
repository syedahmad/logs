import os, sys
    
class ApacheErrorLogParser():

        def __init__(self):

            self.log_type = "Error"
            self.date = None
            self.type = None
            self.description = None
            self.client_ip = None

        def __list_to_string__(self, list_line): 
                                                          #Converts a list to string, 
            return_str = str()                            #for example converts ['Sat', 'Aug', '12', '04:05:51', '2006']
            for i in list_line:                           #to 'Sat Aug 12 04:05:49 2006'
                return_str += " " + i
            return return_str

        def parse(self, line):

            if line[0:2] != '**':
                if line[0] == '[':
                    log_line = line.split()                   #splits a line of the file into items of a list based on spaces
                    self.date = self.__list_to_string__(log_line[0:5])[2:-1]
                    self.type = str(log_line[5])[1:-1]
                    self.description = self.__list_to_string__(log_line[6:])

                    if str(log_line[6])[1:] == "client":

                        self.client_ip = log_line[7][:-1]
                        self.description = self.__list_to_string__(log_line[8:])

                    else:

                        self.client_ip = None
                else:
                    self.client_ip = None
                    self.date = None
                    self.type = None
                    self.description = " " + line
            else:

                log_line = line.split()
                self.description = self.__list_to_string__(log_line[1:])
                self.date = None
                self.type = None
                self.client_ip = None