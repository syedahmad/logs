#!/usr/bin/python

import os, sys, zipfile, traceback, glob, time, requests, httplib
import threading
import time
from socket import error as SocketError


class myThread (threading.Thread):
	
	def __init__(self, PathToFolder):
		threading.Thread.__init__(self)
        
		self.PathToFolder = PathToFolder
		
	def run(self):
		
		threadLock.acquire()
		
		fetchFiles(self.PathToFolder)
		
		threadLock.release()
		
		return

path_files = []

def fetchFiles(PathToFolder):
	
	formats = ['.ar','.iso','.tar','.bz2',
			   '.gz','.rar','.zip','.apk',
			   '.tar.gz','.tar.bz2','tar.xz',
			   '.xz','.jar','.sda','.rk','.tlz',
			   '.tar.Z','.Z'
			  ]
	
	countr_1 = 0								#counters for counting number of unzipped and zipped files originally
	countr_2 = 0
	#global del_files
	FileNames = []
	
	
	#time.sleep(delay)
	
	for dirPath, dirNames, fileNames in os.walk(PathToFolder):
		
		for item in fileNames:    

			FilesPath = os.path.join(dirPath,item)
			#print item
			#print FilesPath
			fileName, fileExtension = os.path.splitext(FilesPath)
			#print fileExtension
			
			FileNames.append(item)
			path_files.append(FilesPath)
			
			r = open("input_log_details.conf","r")

			x = r.readlines()			

			
			# Now, Uploading all the zipped ones	
			App_file = x[7].split()

			User_file = x[10].split()

			contr = 0

			for app_files in App_file:
				contr += 1
				if app_files == "=" :
					break
	
			app_id = App_file[contr]
			#print "Application ID is : %s " % (app_id)

# lets post the app_id as a string

#requests.post('http://localhost/logalytics/index.php/upload_file', data ={'app' : app_id})

			count = 0

			for user_files in User_file :
				count += 1
				if user_files == "=" :
					break 

			user_id = User_file[count]
			#print "User ID is : %s " %(user_id)

		# Zipping the Unzipped files .
				
			if not (fileExtension in formats):
									
				file_zip = zipfile.ZipFile(os.path.join(dirPath,"%s.zip"% item), "w", zipfile.ZIP_DEFLATED)
				try:
					file_zip.write(os.path.join(dirPath,item), arcname= item)
				finally:
					file_zip.close()
					countr_1 += 1          # counting intial unzipped files
					
					
				
# lets post the user_id as a string

#requests.post('http://localhost/upload_file.php', data ={'user' : user_id})



				t = "%s.zip"% item  #Path to the Zipped files
				ZipFilesPath = os.path.join(dirPath,t)		
				
				try:
				
					#r = requests.post('http://logs.semusi.com/index.php/upload_file', files={'file': open(ZipFilesPath, 'rb')},data ={'app' : app_id,'user' : user_id}) #sending file to php 
					r = requests.post('http://localhost/logalytics/index.php/upload_file', files={'file': open(ZipFilesPath, 'rb')},data ={'app' : app_id,'user' : user_id}) #sending file to php 

				except httplib.HTTPException, e:
					print 'HTTPException'
				except Exception:
					import traceback
					print 'generic exception: ' + traceback.format_exc()
				except SocketError as e:
					if e.errno != errno.ECONNRESET:
						raise
					
								
			elif (fileExtension in formats):
				
				try:
					#r = requests.post('http://logs.semusi.com/index.php/upload_file', files={'file': open(FilesPath, 'rb')},data ={'app' : app_id,'user' : user_id})
					r = requests.post('http://localhost/logalytics/index.php/upload_file', files={'file': open(FilesPath, 'rb')},data ={'app' : app_id,'user' : user_id})
				
				except httplib.HTTPException, e:
					print 'HTTPException'
				except Exception:
					import traceback
					print 'generic exception: ' + traceback.format_exc()
				except SocketError as e:
					if e.errno != errno.ECONNRESET:
						raise
				
				countr_2 += 1               #counting intial zipped files
					#print r.text	
	
		#print '\n',len(FileNames), 'file(s) were found in searched folder %s' % PathToFolder, '\n'  #print FileNames,'\n'
		
		#print 'out of which Initially, %s were already zipped'% countr_2, 'and', '%s were not'% countr_1,'\n'
						
						

threadLock = threading.Lock()
#threads = []

	# Take input of all folders in a string separated by a comma each	


#folder_path = raw_input('Provide the path of the logs folders separated by comma : ')


#del_files = raw_input('You want to REMOVE the original files ? [yes OR no] : ')

r = open("input_log_details.conf","r")

x = r.readlines()
				
nw = []
				
new = x[1].split()

for word in new:
	
	nw.append(word)

	for letters in nw:
					
		if (word == 'yes'):
			print '\n','Alright then','\n',' You will have ur original files removed from ur system'
			break
		elif (word == 'no'):
			print '\n','Alright then',"\n",'  You will keep the original files with you'
			break

print "\n","Processing ......","\n"


# Now, for posting App_id and User_id as parameters to upload_file.php



""" User should provide the directories in a text file separated by comma from where
                      the script will read the individul folders accordingly and process eventually """


while True :
	
	folder_path = open("input_log_details.conf","r")

# Reading the text file as a string. 
	
	
	fodlerstring = folder_path.readlines()
	
	

#Also , .read() command shows a '\n' at the end of the string

	eachwords = fodlerstring[4].split()

# Remove the last element of the string using .pop() , In this case, we have to remove the last '\n'  

	"""temp = Individual_folders.pop()

	flag = temp[:len(temp)-1]

	Individual_folders.append(flag)"""
	
	counter = 0
	
	for words in eachwords :
		counter += 1
		if words == "=" :
			
			break
			
	Individual_folders = eachwords[counter].split(',')
	
	

# Create new threads


#while True :
	
	time.sleep(15)
	
	for each in Individual_folders :
	
		thread1 = myThread(each)
	
		
	#Start new Threads
		thread1.start()

			
	folder_path.close()
