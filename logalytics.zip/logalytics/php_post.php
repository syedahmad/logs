<?php

$data = array("user" => "A2337F02-904D-ECED-5B44-C1372514A230", "app" => "151ef552-6007-4438-94e9-cd493c280d5f", "X-API-KEY" => "e6507576-144c-460f-8dc9-8235357a6844", "content" => json_encode(array('exampleexamplecom'=>'p','examplplecom'=>'q')));   
$postdata =http_build_query($data);
$result = file_get_contents('http://localhost/logalytics/index.php/endpoint', null, stream_context_create(array(
'http' => array(
'method' => 'POST',
'header' => array('Content-Type: application/x-www-form-urlencoded'."\r\n"
. 'Content-Length: ' . strlen($postdata) . "\r\n"),
'content' => $postdata)
)
));

echo $result;
?>
